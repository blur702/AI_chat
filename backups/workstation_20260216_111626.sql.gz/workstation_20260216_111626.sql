--
-- PostgreSQL database dump
--

\restrict eRLCd1EaOF7es2g5UifNikCzaZMPiploJeuxXUfb2UMb0roLVlD8D5lkQMOhfa9

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg12+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: set_system_prompts_updated_at(); Type: FUNCTION; Schema: public; Owner: workstation_user
--

CREATE FUNCTION public.set_system_prompts_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
        BEGIN
            NEW.updated_at = now();
            RETURN NEW;
        END;
        $$;


ALTER FUNCTION public.set_system_prompts_updated_at() OWNER TO workstation_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO workstation_user;

--
-- Name: archives; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.archives (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    project_id uuid NOT NULL,
    base_url text NOT NULL,
    archive_path text NOT NULL,
    manifest jsonb,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL
);


ALTER TABLE public.archives OWNER TO workstation_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid,
    action character varying(100) NOT NULL,
    resource character varying(255),
    ip_address character varying(45),
    user_agent text,
    status character varying(50) NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO workstation_user;

--
-- Name: automation_actions; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.automation_actions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    project_id uuid NOT NULL,
    action_type character varying(100) NOT NULL,
    action_data jsonb,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    result jsonb,
    completed_at timestamp with time zone,
    user_approved boolean DEFAULT false NOT NULL,
    executed_at timestamp with time zone
);


ALTER TABLE public.automation_actions OWNER TO workstation_user;

--
-- Name: chats; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.chats (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    project_id uuid NOT NULL,
    title character varying(500) NOT NULL,
    is_pinned boolean DEFAULT false NOT NULL,
    is_archived boolean DEFAULT false NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    system_prompt_id uuid,
    chat_instructions text
);


ALTER TABLE public.chats OWNER TO workstation_user;

--
-- Name: context_compactions; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.context_compactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    chat_id uuid NOT NULL,
    original_message_count integer NOT NULL,
    compacted_message_count integer NOT NULL,
    summary text NOT NULL,
    status character varying(50) DEFAULT 'completed'::character varying NOT NULL
);


ALTER TABLE public.context_compactions OWNER TO workstation_user;

--
-- Name: context_snippets; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.context_snippets (
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    content text NOT NULL,
    description text,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.context_snippets OWNER TO workstation_user;

--
-- Name: drupal_sites; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.drupal_sites (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    project_id uuid NOT NULL,
    site_url character varying(2048) NOT NULL,
    api_key_encrypted text NOT NULL,
    site_name character varying(255),
    last_sync_at timestamp with time zone,
    sync_config jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.drupal_sites OWNER TO workstation_user;

--
-- Name: events; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    event_type character varying(100) NOT NULL,
    event_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    severity character varying(50) DEFAULT 'info'::character varying NOT NULL,
    source character varying(100) NOT NULL,
    user_id uuid,
    chat_id uuid,
    resource_id character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.events OWNER TO workstation_user;

--
-- Name: help_topics; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.help_topics (
    slug character varying(255) NOT NULL,
    section_id character varying(255) NOT NULL,
    title character varying(500) NOT NULL,
    body text NOT NULL,
    tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    embedding public.vector(1024),
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.help_topics OWNER TO workstation_user;

--
-- Name: image_generations; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.image_generations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    project_id uuid,
    workflow_type character varying(50) NOT NULL,
    prompt text NOT NULL,
    negative_prompt text,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    workflow_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    result_images jsonb DEFAULT '[]'::jsonb NOT NULL,
    error_message text,
    comfyui_job_id character varying(255),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.image_generations OWNER TO workstation_user;

--
-- Name: kb_chunks; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.kb_chunks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    source_id uuid NOT NULL,
    project_id uuid NOT NULL,
    content text NOT NULL,
    embedding public.vector(1024),
    metadata jsonb,
    chunk_index integer NOT NULL
);


ALTER TABLE public.kb_chunks OWNER TO workstation_user;

--
-- Name: kb_sources; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.kb_sources (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    project_id uuid NOT NULL,
    source_type character varying(50) NOT NULL,
    source_path character varying(1000) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    chunk_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.kb_sources OWNER TO workstation_user;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.messages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    chat_id uuid NOT NULL,
    role character varying(50) NOT NULL,
    content text NOT NULL,
    metadata jsonb,
    is_pinned boolean DEFAULT false NOT NULL,
    is_excluded boolean DEFAULT false NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL
);


ALTER TABLE public.messages OWNER TO workstation_user;

--
-- Name: project_imports; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.project_imports (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    project_id uuid NOT NULL,
    import_type character varying(20) NOT NULL,
    source_url text,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    detected_type character varying(50),
    detected_template_id character varying(100),
    progress_message text,
    error_message text,
    import_options jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_imports OWNER TO workstation_user;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.projects (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    path text NOT NULL,
    type character varying(50),
    settings jsonb,
    custom_context text,
    important_files text[],
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    template_id character varying(100),
    system_prompt_id uuid
);


ALTER TABLE public.projects OWNER TO workstation_user;

--
-- Name: resources; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.resources (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    resource_id character varying(255) NOT NULL,
    resource_type character varying(100) NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying NOT NULL,
    location text,
    priority integer DEFAULT 0 NOT NULL,
    auto_unload boolean DEFAULT true NOT NULL,
    last_used_at timestamp with time zone,
    user_locked boolean DEFAULT false NOT NULL,
    user_id uuid,
    vram_mb integer,
    base_priority integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.resources OWNER TO workstation_user;

--
-- Name: system_prompts; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.system_prompts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    content text NOT NULL,
    description text,
    is_default boolean DEFAULT false NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone
);


ALTER TABLE public.system_prompts OWNER TO workstation_user;

--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.user_preferences (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    custom_system_prompt text,
    coding_principles jsonb,
    response_style jsonb,
    default_model character varying(100),
    default_temperature double precision DEFAULT '0.7'::double precision,
    email_notifications boolean DEFAULT true NOT NULL,
    in_app_notifications boolean DEFAULT true NOT NULL,
    imggen_default_workflow character varying(50) DEFAULT 'text-to-image'::character varying,
    imggen_default_width integer DEFAULT 512,
    imggen_default_height integer DEFAULT 512,
    imggen_default_steps integer DEFAULT 20,
    imggen_default_cfg_scale double precision DEFAULT '7'::double precision,
    imggen_default_negative_prompt text,
    imggen_completion_notification boolean DEFAULT true NOT NULL,
    imggen_desktop_notification boolean DEFAULT false NOT NULL,
    imggen_sound_notification boolean DEFAULT false NOT NULL,
    imggen_notification_sound character varying(100) DEFAULT 'default'::character varying,
    imggen_auto_delete_days integer,
    imggen_max_generations integer,
    comfyui_base_url character varying(500)
);


ALTER TABLE public.user_preferences OWNER TO workstation_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    username character varying(100) NOT NULL,
    email character varying(255),
    hashed_password character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    screen_name character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    email_verification_token character varying(255),
    password_reset_token character varying(255),
    password_reset_expires timestamp with time zone,
    failed_login_attempts integer DEFAULT 0 NOT NULL,
    locked_until timestamp with time zone,
    last_login_at timestamp with time zone,
    last_password_change timestamp with time zone,
    must_change_password boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO workstation_user;

--
-- Name: yolo_edits; Type: TABLE; Schema: public; Owner: workstation_user
--

CREATE TABLE public.yolo_edits (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    project_id uuid NOT NULL,
    chat_id uuid,
    files_modified text[] NOT NULL,
    undo_performed boolean DEFAULT false NOT NULL,
    undo_data jsonb
);


ALTER TABLE public.yolo_edits OWNER TO workstation_user;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.alembic_version (version_num) FROM stdin;
a1b2c3d4e5f7
\.


--
-- Data for Name: archives; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.archives (id, created_at, updated_at, project_id, base_url, archive_path, manifest, status) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.audit_logs (id, user_id, action, resource, ip_address, user_agent, status, details, created_at, updated_at) FROM stdin;
426f8769-c339-4dc2-b646-837d9ad75c7e	\N	login_failed	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	failure	{"reason": "user_not_found", "identifier": "kevin"}	2026-02-08 21:06:03.285371+00	2026-02-08 21:06:03.285371+00
f8eee492-9d7c-407d-a99a-8c963281a4c9	\N	login_failed	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	failure	{"reason": "user_not_found", "identifier": "kevin"}	2026-02-08 21:12:26.057132+00	2026-02-08 21:12:26.057132+00
5c81ace1-f4f9-4036-8301-bbad6122aaf7	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-08 21:18:33.555716+00	2026-02-08 21:18:33.555716+00
cf512752-a741-419b-8b9e-e9854f71677f	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.9	curl/8.17.0	success	{}	2026-02-08 21:19:03.950202+00	2026-02-08 21:19:03.950202+00
07fd03eb-a63f-4f68-ab11-c5882a12a0f1	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-08 21:34:20.238831+00	2026-02-08 21:34:20.238831+00
f9c00e0d-9418-4d5c-b06b-fa8658f7a64f	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.9	Mozilla/5.0 (iPhone; CPU iPhone OS 26_2_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) EdgiOS/144.0.3719.103 Version/26.0 Mobile/15E148 Safari/604.1	success	{}	2026-02-10 03:20:41.032405+00	2026-02-10 03:20:41.032405+00
e09ecd6a-74cc-48ff-87dd-b0ed24228bc5	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-10 15:51:33.16745+00	2026-02-10 15:51:33.16745+00
38adf817-44ba-451f-add2-8b5ba1c9837a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:07:33.723078+00	2026-02-11 01:07:33.723078+00
b120821d-a121-4ebd-a611-82c5ecd62df7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:08:30.09775+00	2026-02-11 01:08:30.09775+00
94492099-2191-4fe9-8d31-d7ed52c719be	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:12:45.342859+00	2026-02-11 01:12:45.342859+00
fcd6cf2f-d4cc-4846-8362-ede934a7765c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:13:35.986201+00	2026-02-11 01:13:35.986201+00
164082b0-63af-40b8-8c03-11ba16e43000	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:14:03.815346+00	2026-02-11 01:14:03.815346+00
88d216da-af79-4832-8f5a-f632e852c70b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:22:59.418626+00	2026-02-11 01:22:59.418626+00
37e6420f-2337-470e-963a-0cce6afad2d1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:23:45.34067+00	2026-02-11 01:23:45.34067+00
4d390aaa-eec5-4cbb-bdc4-b5a4a2e22097	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	node	success	{}	2026-02-11 01:30:39.79084+00	2026-02-11 01:30:39.79084+00
b2663beb-f0eb-4b48-9c85-7e9c8e468717	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:41:33.654991+00	2026-02-11 01:41:33.654991+00
3284264d-caea-4474-8e48-d0e1aa4315a4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:42:18.895388+00	2026-02-11 01:42:18.895388+00
574a44a7-a447-4dc0-92c4-2bb60071787c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:43:02.79148+00	2026-02-11 01:43:02.79148+00
beb62d5a-1c06-45c7-b36b-0038319c64dc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:44:07.872786+00	2026-02-11 01:44:07.872786+00
cd65bf30-dc9b-4ea4-bdba-4bbdff439b59	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:46:45.142636+00	2026-02-11 01:46:45.142636+00
b98cc7e3-bb0e-4e56-af9e-67cd77fca5f1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:56:37.627626+00	2026-02-11 01:56:37.627626+00
6e2ea64a-eb35-4eea-89b8-7f743a2d14fb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:58:35.098643+00	2026-02-11 01:58:35.098643+00
f3264daf-9ed3-45d1-8e10-5cf6f0b1abea	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 01:59:21.614226+00	2026-02-11 01:59:21.614226+00
26c265c7-c990-4e2b-8342-8ce9b073defa	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 02:05:04.35227+00	2026-02-11 02:05:04.35227+00
bc520c4a-f71a-4a25-bc0a-10ca47b13a0a	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 02:46:50.425224+00	2026-02-11 02:46:50.425224+00
51073900-b6bd-4931-9eaa-86fe8a9edafd	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-11 03:09:02.92416+00	2026-02-11 03:09:02.92416+00
eab66a2f-19a0-49dc-8bd6-972cb3cd4954	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-12 15:35:25.906126+00	2026-02-12 15:35:25.906126+00
8eedeca2-3283-4c08-8270-7e623838865d	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 15:42:26.091414+00	2026-02-12 15:42:26.091414+00
d7091971-4692-4e45-8783-0aadacc24afe	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-12 15:46:56.911412+00	2026-02-12 15:46:56.911412+00
a4c6684a-673a-420c-8bb9-22940bef821e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-12 15:53:50.050239+00	2026-02-12 15:53:50.050239+00
c3e8106c-7e07-4f1d-a173-1921a3534cc9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-12 15:56:01.691808+00	2026-02-12 15:56:01.691808+00
7b979681-d268-4dc6-9459-6ef61f58aa35	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 16:04:44.519431+00	2026-02-12 16:04:44.519431+00
2eb699d0-0f70-439b-8c56-5071b7f3f3f7	eb8f2199-7903-409d-8999-1e450e3c90b8	profile_updated	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 16:10:11.49478+00	2026-02-12 16:10:11.49478+00
a09139f1-1035-4639-9354-9f77a8dd7f75	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 17:50:40.397368+00	2026-02-12 17:50:40.397368+00
a9ed4262-0afc-4498-9a32-6bb90c51e4cb	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 18:42:05.335976+00	2026-02-12 18:42:05.335976+00
aa5717e3-62b3-4e12-b837-063ca5a9b604	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 18:42:46.37255+00	2026-02-12 18:42:46.37255+00
5f10ecba-c795-4a1b-a2e8-8bace02d6d38	eb8f2199-7903-409d-8999-1e450e3c90b8	profile_updated	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 18:42:50.735888+00	2026-02-12 18:42:50.735888+00
910b85c9-3b1c-4950-8a63-fc6eb75d78b6	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 19:53:22.41747+00	2026-02-12 19:53:22.41747+00
1177adb1-6c88-42c3-8364-d66500d1fd96	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 19:55:24.822334+00	2026-02-12 19:55:24.822334+00
f7073a60-27ab-4dd6-b9cb-88d78fb118f3	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 19:58:18.507566+00	2026-02-12 19:58:18.507566+00
1de17fba-e07e-4273-96e3-9e9b0f7e13e8	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 19:58:30.763774+00	2026-02-12 19:58:30.763774+00
bf79adad-2337-4c20-bcd3-26742db91283	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-12 20:00:44.434756+00	2026-02-12 20:00:44.434756+00
c07e959f-6bae-477d-8a65-dc1224eda925	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 22:03:18.608576+00	2026-02-12 22:03:18.608576+00
aa3db73d-14e0-4455-b9ab-76790a9d7528	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-12 22:26:02.687084+00	2026-02-12 22:26:02.687084+00
b74b1e07-67dd-4a09-b5a4-009e7fabb154	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-12 22:28:02.29379+00	2026-02-12 22:28:02.29379+00
f9216cad-3503-4501-9dfb-f795e101139b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-12 22:33:10.756431+00	2026-02-12 22:33:10.756431+00
70e2ddd2-806a-427c-ab71-860284b87c34	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.6	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-12 22:33:34.930188+00	2026-02-12 22:33:34.930188+00
c0e06fd1-0666-47e7-ba91-98f24cc7bbba	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.9	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-12 22:35:20.019995+00	2026-02-12 22:35:20.019995+00
13bd3cdb-d088-4dc4-b2df-39e6d7fdf8f6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	127.0.0.1	python-requests/2.32.5	success	{}	2026-02-12 22:39:13.440209+00	2026-02-12 22:39:13.440209+00
2de81da1-6a78-4d75-ab86-6ac1d1b681f0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-12 22:39:41.586811+00	2026-02-12 22:39:41.586811+00
0ea58943-e612-4166-a1cc-2de03959af49	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:06:18.016167+00	2026-02-13 00:06:18.016167+00
dee46563-5c7e-4a13-a8f4-42b3c5e9b8a2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:06:49.276999+00	2026-02-13 00:06:49.276999+00
5393349c-3cb1-4cfd-88fa-b1b41cbd3f6e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:06:50.360606+00	2026-02-13 00:06:50.360606+00
41fcd315-9115-4fcb-8ac7-443256e39e61	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:06:51.443485+00	2026-02-13 00:06:51.443485+00
2d78fe42-d80d-4839-9b91-c573b14ebc64	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:06:55.275925+00	2026-02-13 00:06:55.275925+00
4cc81a0e-e858-4979-9030-e68f330dd620	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:08:51.991479+00	2026-02-13 00:08:51.991479+00
88409798-1c51-4a41-bfed-1e8267aa6fa2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:08:53.06144+00	2026-02-13 00:08:53.06144+00
cd6dfa24-5b80-40b4-8f8a-a8bf8e958389	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:08:54.154195+00	2026-02-13 00:08:54.154195+00
670baff2-502a-4276-bafa-da9912d979ac	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-13 00:13:06.455278+00	2026-02-13 00:13:06.455278+00
a10d7c89-b603-43ee-9c77-60d59eef5c2d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	curl/8.17.0	success	{}	2026-02-13 00:13:12.122057+00	2026-02-13 00:13:12.122057+00
4ffe2756-e775-427e-b6fd-b1fcd49883d1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:14:35.479163+00	2026-02-13 00:14:35.479163+00
6f9121e9-b475-4ca6-92c4-62d1a6878e57	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:15:31.919116+00	2026-02-13 00:15:31.919116+00
b865cce4-4ca3-43e9-a777-305762d6178c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:32.106096+00	2026-02-13 00:15:32.106096+00
5143c745-119d-4514-80db-41e1cc7dab2e	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:15:32.294252+00	2026-02-13 00:15:32.294252+00
22a3e94f-ee5a-4b47-afd4-813f7bf0c11d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:15:32.32202+00	2026-02-13 00:15:32.32202+00
ee6feb62-2593-4039-9e3d-00ae697489c3	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:15:32.506396+00	2026-02-13 00:15:32.506396+00
757a93cd-179a-479b-bfd5-e8123e5feda5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:34.140702+00	2026-02-13 00:15:34.140702+00
f25fbfd9-94e0-4150-84b0-4800a6e5c4a4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:34.32711+00	2026-02-13 00:15:34.32711+00
57aa72b3-58e8-4b6a-896d-f26b27b45509	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:34.511594+00	2026-02-13 00:15:34.511594+00
fe8bc23d-79e4-42a0-913b-744974cac9f4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:34.694457+00	2026-02-13 00:15:34.694457+00
04cdc6bc-7d8a-47b5-9981-0184f9270d58	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:15:34.882333+00	2026-02-13 00:15:34.882333+00
b9909710-2e32-4af4-8d8c-f6923a33dbfd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:50.998756+00	2026-02-13 00:26:50.998756+00
f2532082-4160-4065-becd-c61713ffb89a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:36.553102+00	2026-02-13 00:15:36.553102+00
45cbce4f-f52b-48f6-b39a-2b13b2379342	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:39.970412+00	2026-02-13 00:15:39.970412+00
f89f8a5b-399d-4879-a3b3-620ded958c25	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:15:41.981265+00	2026-02-13 00:15:41.981265+00
51debe8a-c8f6-43f9-b657-7513c088e71b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:42.337615+00	2026-02-13 00:15:42.337615+00
cd213fff-28ba-42af-bc2d-fc57cd26e499	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:15:42.685994+00	2026-02-13 00:15:42.685994+00
38f26deb-3f23-462d-b894-8cd924b91751	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:44.483283+00	2026-02-13 00:15:44.483283+00
d0af7dd2-bb0e-4bbb-9d52-9c2a4de896e1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:44.851554+00	2026-02-13 00:15:44.851554+00
11e86378-3e7b-4393-9494-689b2642a7cd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:45.218195+00	2026-02-13 00:15:45.218195+00
d6b0e8a0-11d4-467d-8a24-1bc914d72d8d	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:15:47.314533+00	2026-02-13 00:15:47.314533+00
853c223d-8e8c-4c86-9e59-276a45aeced6	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:15:50.377784+00	2026-02-13 00:15:50.377784+00
04df8cb2-389e-425f-817a-58da1afff9f5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:15:53.374098+00	2026-02-13 00:15:53.374098+00
a0eab2ff-905b-4608-8b84-ca6202a5547a	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:15:53.551186+00	2026-02-13 00:15:53.551186+00
28f31788-2b93-4340-99fc-368e7f5c2bea	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:15:55.244551+00	2026-02-13 00:15:55.244551+00
6e27707d-6d1b-4d82-8938-3f1e11b045cc	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:15:56.896174+00	2026-02-13 00:15:56.896174+00
6e7fe5af-5ea0-4c80-b43f-5dfc40c64b5d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:15:58.385786+00	2026-02-13 00:15:58.385786+00
7369a6e0-022b-44c5-8b07-845586a65961	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:16:00.041973+00	2026-02-13 00:16:00.041973+00
bc9f26b8-77e5-4b80-9be8-b5c989c35e62	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-13 03:24:50.663832+00	2026-02-13 03:24:50.663832+00
de31e973-898f-435b-97fc-1487e53a1c10	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-13 03:46:56.980297+00	2026-02-13 03:46:56.980297+00
090cb40c-d2ba-4d8d-8763-589fa304797f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-13 03:56:42.92009+00	2026-02-13 03:56:42.92009+00
66da249b-d221-4378-89a7-7d5e95854db1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-13 03:57:13.463773+00	2026-02-13 03:57:13.463773+00
9407ead3-300d-4485-a431-92a1b499ef80	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-14 14:03:40.434099+00	2026-02-14 14:03:40.434099+00
fda5268d-6256-4a34-9b1e-79242e85aca0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:36.728872+00	2026-02-13 00:15:36.728872+00
4238340b-6914-47c8-89bb-ba6ac05bede6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:37.874589+00	2026-02-13 00:15:37.874589+00
2e5d0484-db4f-4bfc-8add-7368f96f29be	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:15:40.145731+00	2026-02-13 00:15:40.145731+00
41aee28d-6e77-45d2-b575-dffb6c30f452	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:42.167784+00	2026-02-13 00:15:42.167784+00
ff5e3ef7-20c9-4a11-b656-4ef007a5c1f3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:42.508213+00	2026-02-13 00:15:42.508213+00
3081b6e4-552a-4622-a1c4-8053d1239d9c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:15:44.669698+00	2026-02-13 00:15:44.669698+00
3668adbd-b627-4c2c-9b82-cf7d5c4ee44f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:15:45.032422+00	2026-02-13 00:15:45.032422+00
a077b4fc-8473-4f86-b2e8-928a490205ef	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:15:46.628543+00	2026-02-13 00:15:46.628543+00
4a6b3590-ca15-4cd5-b138-b12071a22794	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:15:47.137082+00	2026-02-13 00:15:47.137082+00
9f984ac4-1a82-4a03-a010-a128f20f1c8c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:15:48.752083+00	2026-02-13 00:15:48.752083+00
800f8d2e-9c18-4596-b56c-412576035a43	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:15:48.930664+00	2026-02-13 00:15:48.930664+00
7e6af30f-a843-421a-9752-1d674f3f2c64	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:15:51.85771+00	2026-02-13 00:15:51.85771+00
a405ea96-a06e-4172-b97f-15ef041568ce	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:15:55.069318+00	2026-02-13 00:15:55.069318+00
7c314dd9-1430-4d2d-a58a-a393d68cca61	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:15:56.719597+00	2026-02-13 00:15:56.719597+00
4d981c44-2fc8-4cdb-9bfb-ba2556789ab1	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:15:58.560971+00	2026-02-13 00:15:58.560971+00
55f59ffe-2d3e-476a-b4dd-fe0739bab4cc	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:16:01.548548+00	2026-02-13 00:16:01.548548+00
51fe7330-04a5-4951-a239-561f707b94f9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:03.537515+00	2026-02-13 00:16:03.537515+00
c9649b7b-2769-4bdd-a12b-9cb1e733048d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:04.484967+00	2026-02-13 00:16:04.484967+00
1058490c-4c35-4562-a0a3-19ee37ce6dc9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:06.278196+00	2026-02-13 00:16:06.278196+00
474497e5-cf59-4f6f-9221-304b4a724e7f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:07.698814+00	2026-02-13 00:16:07.698814+00
6942ff91-8ea8-487c-b2ff-819a908b476e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:08.210157+00	2026-02-13 00:16:08.210157+00
d1a45357-2eb5-4a5a-b9ca-a430f632e689	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:09.651115+00	2026-02-13 00:16:09.651115+00
218b8cda-c0d5-4269-b705-3f5777e1d536	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:10.857823+00	2026-02-13 00:16:10.857823+00
c32ad4e0-126f-4916-ac54-bcbd3d4833a6	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:16:12.972919+00	2026-02-13 00:16:12.972919+00
dd4eeaee-672f-49a8-ade2-6aaea4b69b42	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:12.998202+00	2026-02-13 00:16:12.998202+00
62e493c1-d8dc-4808-81c6-54597513876c	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:16:13.189115+00	2026-02-13 00:16:13.189115+00
6887f066-0c02-404e-b0a1-4eeb485ff924	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:14.803338+00	2026-02-13 00:16:14.803338+00
2152fa54-534d-420a-aaac-905554bbe4ad	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:14.97531+00	2026-02-13 00:16:14.97531+00
583db946-1e6e-4081-9046-c7784e63745f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:15.147341+00	2026-02-13 00:16:15.147341+00
d2918014-1a1a-44b4-979e-a7877be0e320	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:15.319631+00	2026-02-13 00:16:15.319631+00
ac67bdbc-9297-4773-bf4c-690fd57e00b9	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:16:15.489695+00	2026-02-13 00:16:15.489695+00
dabc947c-9ea3-4c56-8391-e7793709248b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:17.154265+00	2026-02-13 00:16:17.154265+00
fe54d258-bfb9-4241-a5ac-b7e72ecf4c0a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:17.328215+00	2026-02-13 00:16:17.328215+00
698c859f-bf5e-4a70-a168-618da3e738b5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:17.495017+00	2026-02-13 00:16:17.495017+00
b0e1bf56-1698-407e-bdbf-ae03b7c19858	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:17.664646+00	2026-02-13 00:16:17.664646+00
903f5fba-bc0e-4ef3-bd4b-909b635255c2	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:16:17.834609+00	2026-02-13 00:16:17.834609+00
a1e37254-40f2-4547-a912-e28371bedda7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:19.687776+00	2026-02-13 00:16:19.687776+00
d39baac4-72d6-4a21-9eba-b6edc32f728b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:19.876072+00	2026-02-13 00:16:19.876072+00
383bb313-5362-4fd0-b83d-ba19177a47b8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:20.044168+00	2026-02-13 00:16:20.044168+00
d4f4d818-de7f-4756-8b46-ab5cf8059b72	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:20.212771+00	2026-02-13 00:16:20.212771+00
25a36c83-5ac2-4d30-95fa-de0a8c73ad5f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:20.38256+00	2026-02-13 00:16:20.38256+00
06723d3a-c1e4-425f-9b3a-bcfe333a2de9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:22.191565+00	2026-02-13 00:16:22.191565+00
445a030e-8bc3-4c42-8c64-c1d38cc6e241	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:22.535946+00	2026-02-13 00:16:22.535946+00
dede51c8-0d3c-427f-a94c-3e34afceece4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:22.879929+00	2026-02-13 00:16:22.879929+00
e23d196a-fa16-458c-a8af-cfa0b59d5d50	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:24.272561+00	2026-02-13 00:16:24.272561+00
98015df4-481e-41fa-97e8-f8da5121943a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:24.804517+00	2026-02-13 00:16:24.804517+00
1739ae2e-0dc9-46fc-8012-d1abbd6358b4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:26.474875+00	2026-02-13 00:16:26.474875+00
1d37aa9e-8a33-4c4e-a47e-253ceebd3cd3	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:16:29.781751+00	2026-02-13 00:16:29.781751+00
642c3c4c-b7af-491c-a49f-5c92ff26f394	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:16:31.454318+00	2026-02-13 00:16:31.454318+00
544141b9-3705-476c-9991-10c1166d3b73	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:32.962808+00	2026-02-13 00:16:32.962808+00
6351788a-7b16-49e6-a4aa-47d54e17cca1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:34.628547+00	2026-02-13 00:16:34.628547+00
ae450cf8-3342-4792-89ba-b9cc0478b7b3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:36.352551+00	2026-02-13 00:16:36.352551+00
af730731-fb37-4842-a6c5-5b8e97239f15	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:39.771221+00	2026-02-13 00:16:39.771221+00
7b9d078e-ef0d-4d28-9706-e72a8e086217	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:42.65947+00	2026-02-13 00:16:42.65947+00
27014a48-7119-4786-97fc-6ab8893f8c84	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:48.971613+00	2026-02-13 00:16:48.971613+00
9eddbf94-831b-49ee-9fab-3d3570abd046	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:49.434824+00	2026-02-13 00:16:49.434824+00
bf89dce2-735f-4edb-b13b-75d459cdedfd	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:18:19.230216+00	2026-02-13 00:18:19.230216+00
247f6d1c-8759-4b72-b5a1-934ca9091df9	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:18:20.951756+00	2026-02-13 00:18:20.951756+00
1500032f-e348-4b78-8ebe-333198e4a9a9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:38.221045+00	2026-02-13 00:18:38.221045+00
53022169-d245-4180-854f-bdec1b044106	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:38.776648+00	2026-02-13 00:18:38.776648+00
17c6385c-a937-487a-ac9b-95e9c8165286	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:18:39.561323+00	2026-02-13 00:18:39.561323+00
22b5537a-59b5-44ae-adb5-0219e240cf5b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:18:39.904054+00	2026-02-13 00:18:39.904054+00
9f974f60-3b2b-4cf9-9bcd-86ef599471dc	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:18:40.353956+00	2026-02-13 00:18:40.353956+00
3890bd4f-2577-43a9-ac1f-a4c9e6220b9c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:18:40.657985+00	2026-02-13 00:18:40.657985+00
660546dc-d2b4-474e-860e-68dfda84c663	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-13 00:18:41.389768+00	2026-02-13 00:18:41.389768+00
5e0e22a5-15a1-42bc-b56d-6edbfcd15ebb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:18:41.728186+00	2026-02-13 00:18:41.728186+00
b4f0cd90-752b-49cb-952f-7d86b04fd20d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:42.178773+00	2026-02-13 00:18:42.178773+00
07bd60d1-2b90-49f8-afa6-320afeffd205	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:18:42.518517+00	2026-02-13 00:18:42.518517+00
9225cff7-ffc2-460c-93a1-ff9d8ea2452a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:42.970841+00	2026-02-13 00:18:42.970841+00
d8a03c0f-863f-4284-83a1-80867f35e6ba	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:43.413849+00	2026-02-13 00:18:43.413849+00
7ea0e686-0cc8-4218-a264-224b8458e2c8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:44.039855+00	2026-02-13 00:18:44.039855+00
7647b7a2-a3c3-4de2-bc3c-1665e1778fe8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:46.198557+00	2026-02-13 00:18:46.198557+00
db78fd31-4b77-49b0-9074-10982a753e6c	\N	user_creation_failed	\N	172.23.0.1	curl/8.17.0	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:18:48.342558+00	2026-02-13 00:18:48.342558+00
c6e27849-7efe-4067-8d9f-3a8627422e27	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:51.760269+00	2026-02-13 00:18:51.760269+00
8f3b9b63-e4ec-47c4-8021-fc2a32ba5bfc	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:18:53.868777+00	2026-02-13 00:18:53.868777+00
48769075-93ef-4c7c-99c2-71f13b8c86ac	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:18:58.76231+00	2026-02-13 00:18:58.76231+00
c57076b6-9605-424b-a318-a2bd30589eac	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:19:00.622974+00	2026-02-13 00:19:00.622974+00
004035fc-1330-4f72-8384-07d116882d13	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:19:02.511311+00	2026-02-13 00:19:02.511311+00
be389789-bd9e-4a84-b482-f2c8be2b85ca	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-13 03:40:34.245468+00	2026-02-13 03:40:34.245468+00
d1f39d0e-d35f-4665-9660-2e58210bc32d	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 14:09:45.295428+00	2026-02-14 14:09:45.295428+00
6fd54e9a-05ff-4d1b-8d41-28498a472808	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:16:22.36628+00	2026-02-13 00:16:22.36628+00
1ea579e8-6c78-4388-b484-69c640ed063d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:22.704907+00	2026-02-13 00:16:22.704907+00
060e15ce-9161-45fd-95f8-80698124947e	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:16:24.976621+00	2026-02-13 00:16:24.976621+00
d3f3c4dc-6163-44af-9e08-9d8e0334e54a	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:16:26.65276+00	2026-02-13 00:16:26.65276+00
aa350a10-84ff-4710-a0a7-e9913cad515f	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:16:28.192656+00	2026-02-13 00:16:28.192656+00
6ac79211-921c-49d2-9801-daf17e9ba130	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:31.278448+00	2026-02-13 00:16:31.278448+00
4f6fe169-ebd7-4275-b7f4-eaf06f85a434	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:16:33.144942+00	2026-02-13 00:16:33.144942+00
93d03cff-cb4c-4426-9c25-648cb305c39a	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:16:34.803534+00	2026-02-13 00:16:34.803534+00
b40df371-7d84-4fc5-94a0-61f118853adb	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:16:36.542366+00	2026-02-13 00:16:36.542366+00
98180e9a-c930-4014-b53e-14bd590b5af7	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:16:38.256096+00	2026-02-13 00:16:38.256096+00
91af74eb-aeeb-4c53-88d4-d9a4f0d642a6	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:16:39.939413+00	2026-02-13 00:16:39.939413+00
39ef9dfd-61fa-4994-a3b1-52a62f3f0633	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:41.895291+00	2026-02-13 00:16:41.895291+00
2b7c534f-028d-4c92-b095-f688c938023d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:16:47.572089+00	2026-02-13 00:16:47.572089+00
16de352f-9741-41f6-8e88-48e745cfc6de	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:19.049648+00	2026-02-13 00:18:19.049648+00
66408883-3423-4c59-abaa-6007aa50c6bc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:20.767756+00	2026-02-13 00:18:20.767756+00
586a289a-d89e-46d5-a8a5-155dcf10541f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:18:38.416948+00	2026-02-13 00:18:38.416948+00
c1b4d8e1-1725-4beb-afba-a6668fd4bf4f	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:18:38.606652+00	2026-02-13 00:18:38.606652+00
8252a48c-bfdb-44a9-8e1a-8e8334212546	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:18:38.963071+00	2026-02-13 00:18:38.963071+00
f405e2b4-a85f-4d90-a957-e04bbe49ec27	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:18:39.730427+00	2026-02-13 00:18:39.730427+00
25bf35bb-6d51-4538-a97f-71ebe8d0c93e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:18:40.074772+00	2026-02-13 00:18:40.074772+00
05308749-4968-4c9c-afd8-3084e6475ce5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:18:40.650911+00	2026-02-13 00:18:40.650911+00
a17d2135-0478-4c24-ad74-04e352e6325c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:40.936398+00	2026-02-13 00:18:40.936398+00
6a3219ba-4740-43a2-9a3c-f226d5dc13db	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:18:41.558384+00	2026-02-13 00:18:41.558384+00
1e3a6612-8c4a-4c9a-bfa5-e910df6a58cc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:18:41.90022+00	2026-02-13 00:18:41.90022+00
1b5f96c5-60e5-4954-9e50-3b135ed75560	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:18:42.34988+00	2026-02-13 00:18:42.34988+00
d0eef33e-99f4-4ce5-bafe-209f50f2a248	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:18:42.686652+00	2026-02-13 00:18:42.686652+00
f4666cae-f2f2-4528-9ddc-79a8af3b1ff6	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:18:44.212868+00	2026-02-13 00:18:44.212868+00
e3954f5c-5c75-4128-a696-76ec9a7e4887	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:18:46.375874+00	2026-02-13 00:18:46.375874+00
5f4f751b-a413-4d08-bf3d-0ae8b62a4a99	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:18:48.169315+00	2026-02-13 00:18:48.169315+00
ba31b3f0-7e96-4807-a14e-e1bb8a20aa46	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:18:49.99689+00	2026-02-13 00:18:49.99689+00
fda13eab-cd20-4d77-aefa-f89b6283e011	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:18:51.937291+00	2026-02-13 00:18:51.937291+00
5225c5cd-7e43-4234-a2a9-90955f392f24	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:53.692687+00	2026-02-13 00:18:53.692687+00
544cd397-a9cf-4eab-9c0f-b13237f11e00	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:18:58.573427+00	2026-02-13 00:18:58.573427+00
82c33741-3152-4ca8-9ebe-71059f7d744f	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "weak_password", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:19:00.798672+00	2026-02-13 00:19:00.798672+00
08d69653-405d-4f57-b61a-a3a79aaaa36a	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:19:04.248932+00	2026-02-13 00:19:04.248932+00
40240af6-ae3b-4757-81a9-b5b33dd8ff56	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:19:06.353823+00	2026-02-13 00:19:06.353823+00
9153904a-3120-491d-a77e-9ad1bc3e7d6e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:19:07.188115+00	2026-02-13 00:19:07.188115+00
fc7c5d99-797d-4be3-bbd4-155fdbb9c282	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:19:07.89936+00	2026-02-13 00:19:07.89936+00
c1066c6a-deae-44db-97b9-df346904a315	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:19:55.023941+00	2026-02-13 00:19:55.023941+00
c06c1a9b-e9e4-4a88-99c4-ea8c14544003	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:19:55.213946+00	2026-02-13 00:19:55.213946+00
fbbebc0c-3d5e-4e2c-8e5c-bcb6f0bc4f4a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:19:55.565631+00	2026-02-13 00:19:55.565631+00
9274b3ae-551b-4e66-b21c-913b316a927d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:19:56.33295+00	2026-02-13 00:19:56.33295+00
468bed37-9333-456d-8d01-02bec9fe4c7b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:19:56.673779+00	2026-02-13 00:19:56.673779+00
353eb137-7bd8-4dde-85b0-1015aa1e6e1e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:19:57.467152+00	2026-02-13 00:19:57.467152+00
a40ff0b2-d4f6-4d4c-b3ba-d54099df559c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:19:57.775054+00	2026-02-13 00:19:57.775054+00
f1e66238-7379-4001-b0b0-a64a1e7d04ab	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:19:58.394244+00	2026-02-13 00:19:58.394244+00
29ff029f-1a2e-47ad-9bb5-87ebe187e36a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:19:58.850496+00	2026-02-13 00:19:58.850496+00
1115c970-f1ae-4629-b9d8-ed5b7ff50d13	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:19:59.196003+00	2026-02-13 00:19:59.196003+00
6b940faf-6bd0-4b57-8a81-0b3e19474f40	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:19:59.683588+00	2026-02-13 00:19:59.683588+00
e835ec51-d36e-434a-8345-0fcedd73707e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-13 03:46:18.166359+00	2026-02-13 03:46:18.166359+00
ea4521a7-45a2-4109-9218-0dcdec8e99e0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-13 03:58:11.560246+00	2026-02-13 03:58:11.560246+00
af8a6ef3-974e-4f20-bc6b-33655a66989c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:04.655205+00	2026-02-13 00:20:04.655205+00
6a0308ac-f902-479f-8435-469d678d4720	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:04.985461+00	2026-02-13 00:20:04.985461+00
5bc49260-1541-47d1-8725-dfb7079ad57c	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 14:10:20.792744+00	2026-02-14 14:10:20.792744+00
8b44a123-e921-49c0-8103-49920c1585c2	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:04.322162+00	2026-02-13 00:20:04.322162+00
9933cd75-013f-46e4-923a-1c5a299788fc	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:05.30134+00	2026-02-13 00:20:05.30134+00
03fb521c-8cf2-4c86-a354-0d9d32e5d4f1	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:20:04.010405+00	2026-02-13 00:20:04.010405+00
cb3fadd2-695a-47d1-8170-ed132ca0dccf	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:06.746293+00	2026-02-13 00:20:06.746293+00
f3a4c97e-dd76-4502-acdd-a7561a60b0fd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:20:16.85281+00	2026-02-13 00:20:16.85281+00
9ed39bd8-9185-492c-82b4-d8f35d6acdd0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:17.164793+00	2026-02-13 00:20:17.164793+00
df0fde67-22c5-4935-a3ad-bb125a16ab2a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:20:17.944427+00	2026-02-13 00:20:17.944427+00
ae3d6bfc-7ea5-4a37-ae32-c1e8e38117ef	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:20:18.278061+00	2026-02-13 00:20:18.278061+00
064212df-a841-4f29-b379-5a8c0dc21d56	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:20:18.473219+00	2026-02-13 00:20:18.473219+00
037560b8-5606-407a-af7d-7dc1a0e92e63	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:20:18.953019+00	2026-02-13 00:20:18.953019+00
7a34f493-8655-4761-ae87-d193ef6c2a5c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:20:19.256801+00	2026-02-13 00:20:19.256801+00
68971413-4350-4d55-a602-ce6ed64fa30b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:20:19.990718+00	2026-02-13 00:20:19.990718+00
5cce186d-c655-42c9-8e01-9f2881cfe38e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:20:20.329581+00	2026-02-13 00:20:20.329581+00
c20642f2-d07d-4581-ad4c-7ceb6cd7a720	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:20:20.782609+00	2026-02-13 00:20:20.782609+00
157c482c-87e3-427d-a629-1e80b7aaa9ea	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:20:21.129262+00	2026-02-13 00:20:21.129262+00
54e4be1d-e831-4f5e-907d-1bca332f7626	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:21.883319+00	2026-02-13 00:20:21.883319+00
d8153057-dad6-4c4e-ac5d-9dfbcf94d1a8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:22.53419+00	2026-02-13 00:20:22.53419+00
2c5c1eab-158e-47b0-a718-7fd3cd191496	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-14 14:12:12.896113+00	2026-02-14 14:12:12.896113+00
30188e07-3396-4054-ba65-2c0291c6e26a	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:20:23.485101+00	2026-02-13 00:20:23.485101+00
3c8d4c48-d4ee-4f06-8df8-e85257d344ea	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:20:23.792173+00	2026-02-13 00:20:23.792173+00
f136a9de-e829-4272-8f92-c9778ddf41fc	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:23.020937+00	2026-02-13 00:20:23.020937+00
f2a664fb-3657-4153-934d-0d14b59f320e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:24.573187+00	2026-02-13 00:20:24.573187+00
b20ac1df-76d6-436e-8f0e-ca94d4b41cab	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:26.050109+00	2026-02-13 00:20:26.050109+00
23e7cdc7-862b-4caf-8d4e-a4b143f5c919	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:19:55.397621+00	2026-02-13 00:19:55.397621+00
1c482165-f434-41a1-aae6-178d4ea190f7	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:19:55.745339+00	2026-02-13 00:19:55.745339+00
cb157291-8ae8-4e90-8226-42bdffae08fe	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:19:56.505674+00	2026-02-13 00:19:56.505674+00
c4864d2a-9ae2-46a2-baa7-8065b34da642	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:19:56.84394+00	2026-02-13 00:19:56.84394+00
46cb005f-a412-4c28-9838-3c66e4d770be	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:19:57.189138+00	2026-02-13 00:19:57.189138+00
43783719-e842-4b24-9f19-6ccda3d44bfc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:19:57.475406+00	2026-02-13 00:19:57.475406+00
d29a3119-3c7e-4be6-9359-22bf6b9a4a08	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:19:58.21979+00	2026-02-13 00:19:58.21979+00
03027eab-2b05-44b0-9beb-b9949ecee72b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:19:58.566804+00	2026-02-13 00:19:58.566804+00
7babfeff-ab12-4279-8e09-181c0dcd6ef3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:19:59.021017+00	2026-02-13 00:19:59.021017+00
b2e7d5ad-a445-40ce-94af-7b6f7ec72c52	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:19:59.374568+00	2026-02-13 00:19:59.374568+00
aae0732b-6d5e-4a2c-b091-adae8e66dac2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:00.183134+00	2026-02-13 00:20:00.183134+00
2072ba57-9439-4f9f-bf83-5b24f1a31b96	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:03.827266+00	2026-02-13 00:20:03.827266+00
6df48be8-5940-4ffd-b728-60688665f753	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:20:04.834026+00	2026-02-13 00:20:04.834026+00
f4235f0d-71b4-4ec7-ba14-742468468323	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:20:05.166864+00	2026-02-13 00:20:05.166864+00
5681b525-0257-413f-b084-8e11d62b1c62	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:05.975742+00	2026-02-13 00:20:05.975742+00
9b3b23c6-821f-4a6a-9091-a8b4fbc15b68	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:07.474904+00	2026-02-13 00:20:07.474904+00
322e523c-2cbf-4706-92cf-cfd786f957bb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	curl/8.17.0	success	{}	2026-02-13 00:20:10.741173+00	2026-02-13 00:20:10.741173+00
3e6e804b-2105-4626-9a69-0b68c5032846	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:16.664668+00	2026-02-13 00:20:16.664668+00
6b2025c1-8578-4bcd-8344-f8441318c3d7	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:20:17.031163+00	2026-02-13 00:20:17.031163+00
040b07c2-d685-4501-92f5-12352f6b831b	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:20:17.347686+00	2026-02-13 00:20:17.347686+00
052d0d45-0c15-418e-a115-d9cbb5a4b868	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-13 03:57:45.585757+00	2026-02-13 03:57:45.585757+00
d8f2935c-b157-4bdb-b83c-e876f4d0fa7b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:20:18.655991+00	2026-02-13 00:20:18.655991+00
fc75ede9-34e7-4601-a686-f4a3190859ef	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:20:19.247896+00	2026-02-13 00:20:19.247896+00
ee035ba9-f36d-40d1-bdf7-c57d2f27df40	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:19.5484+00	2026-02-13 00:20:19.5484+00
5ca886b6-4e98-4c70-9976-a4fa23714ace	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:20:20.160947+00	2026-02-13 00:20:20.160947+00
9491b6d7-2549-44cb-8e3c-3192c378a959	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:20.614614+00	2026-02-13 00:20:20.614614+00
bac30efa-9d5a-49bc-9451-30bab358f88c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:20:20.958187+00	2026-02-13 00:20:20.958187+00
99e99105-1612-4308-ba54-11ac6d574d38	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:21.432315+00	2026-02-13 00:20:21.432315+00
06e9f561-93ca-4806-b1fa-8155316b4ea5	\N	user_created	\N	172.23.0.8	curl/8.17.0	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_test999"}	2026-02-13 00:20:18.11235+00	2026-02-13 00:20:18.11235+00
9e35b829-805d-4038-9900-04317f25a335	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-13 04:00:53.214491+00	2026-02-13 04:00:53.214491+00
258cf99d-2403-4bc7-a082-20f35af384dd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:23.315133+00	2026-02-13 00:20:23.315133+00
e00ada93-687d-4c65-abf4-147daeaaa653	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:23.623396+00	2026-02-13 00:20:23.623396+00
7837215e-f408-4acb-819c-5bf3f8ad76a9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-13 04:01:42.228877+00	2026-02-13 04:01:42.228877+00
20952e65-2391-4b02-8264-b75cb37bc0a1	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:23.928168+00	2026-02-13 00:20:23.928168+00
e0dda8f9-47a1-41a1-9af1-8684ca48eab5	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:20:22.707124+00	2026-02-13 00:20:22.707124+00
9531b7bd-bc78-4e00-ace8-ec74a81e965b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:25.33481+00	2026-02-13 00:20:25.33481+00
a5615954-f61c-4c32-ac40-f2d2cc183d0f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:20:31.997164+00	2026-02-13 00:20:31.997164+00
8e5b495e-b892-49b0-af14-9169eb565068	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:20:33.245803+00	2026-02-13 00:20:33.245803+00
03f144d4-2b6b-4ab5-97b6-6c4e1fd8d255	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:20:43.618614+00	2026-02-13 00:20:43.618614+00
a015cbcb-944d-4b0d-ae0e-ae0fa59d9377	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:20:50.368763+00	2026-02-13 00:20:50.368763+00
961e6d30-cf1c-4ebf-8228-b26d3b26010a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:20:51.622777+00	2026-02-13 00:20:51.622777+00
cb82108b-3368-4ff9-95aa-5cc83cf3e2c7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:53.923344+00	2026-02-13 00:20:53.923344+00
a10af9f7-4791-4d0f-aa4e-189953d43fd6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-13 05:16:01.168196+00	2026-02-13 05:16:01.168196+00
47f2116d-f6fa-4f29-a450-c9f77faf84de	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:20:54.889264+00	2026-02-13 00:20:54.889264+00
0e989241-d393-440c-9ce4-e2e8dfc5c0ce	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:55.023469+00	2026-02-13 00:20:55.023469+00
1ca3a695-c366-4992-b63e-7f07dab4fd61	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-14 16:20:32.966795+00	2026-02-14 16:20:32.966795+00
693132d2-6479-4b1c-99bb-87ee81da1614	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:54.424384+00	2026-02-13 00:20:54.424384+00
724fb67a-452a-4c98-99f7-50b275dcacba	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:55.322489+00	2026-02-13 00:20:55.322489+00
d9c7e0c1-a609-4e59-b0b9-db10a954b9cb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:26.7328+00	2026-02-13 00:21:26.7328+00
27e890bc-ed99-49d0-876e-4cf5cc02ead9	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:21:27.110019+00	2026-02-13 00:21:27.110019+00
592913d9-4a52-4dfc-a9b6-746326308810	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:27.273613+00	2026-02-13 00:21:27.273613+00
ba94127b-b3b2-4026-8425-44bf782c901b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:28.028109+00	2026-02-13 00:21:28.028109+00
481191b6-bf33-4067-8822-047555903c96	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:28.377123+00	2026-02-13 00:21:28.377123+00
a1971409-7ffd-4c9e-8532-0be118760bd5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:28.550924+00	2026-02-13 00:21:28.550924+00
0900f447-93ce-4f64-a6b7-5cb295f9be5b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:21:29.143152+00	2026-02-13 00:21:29.143152+00
654b0f45-b6ab-4c1a-b796-ca89f4755295	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:21:29.154104+00	2026-02-13 00:21:29.154104+00
9e76e0df-a604-4a4a-9741-1e212baf98e6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:21:29.621717+00	2026-02-13 00:21:29.621717+00
bd56bf97-8cc0-413a-b214-32ebf0928c81	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:29.940005+00	2026-02-13 00:21:29.940005+00
04c048a5-aadf-4b5b-848a-0458efa44721	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:30.290188+00	2026-02-13 00:21:30.290188+00
11f0fa04-753d-4e10-92ce-c55b96615282	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:30.584966+00	2026-02-13 00:21:30.584966+00
2fe57fe3-e696-400d-88e9-8cdca3d4052c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:30.929227+00	2026-02-13 00:21:30.929227+00
51ab6949-c2c1-4262-af94-e9e4e07a28a8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:31.100778+00	2026-02-13 00:21:31.100778+00
6dfefb5a-0b00-4bf5-bcd3-bc5496ddb666	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:31.870533+00	2026-02-13 00:21:31.870533+00
07b51d0c-71af-4161-9d6a-14294fe6089a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:32.543322+00	2026-02-13 00:21:32.543322+00
d0c8a7d5-15d3-4544-a61e-f135c5cfed14	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:33.334763+00	2026-02-13 00:21:33.334763+00
7082647c-8e2a-4ea3-891a-b57021c67b3e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:33.670515+00	2026-02-13 00:21:33.670515+00
81e9ebdf-8891-4ca5-89fa-52a76730b614	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:21:33.844008+00	2026-02-13 00:21:33.844008+00
d24755f8-7431-4c60-8deb-faff2532bab5	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:21:32.721233+00	2026-02-13 00:21:32.721233+00
12095289-b680-43d7-be10-05d904146194	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:33.036326+00	2026-02-13 00:21:33.036326+00
c5c052d3-98a2-4a87-b2a3-35724a3210b6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:21:36.202455+00	2026-02-13 00:21:36.202455+00
29cd6aec-c0b4-4fe7-a4a5-16d6de7b20a1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:21:38.626776+00	2026-02-13 00:21:38.626776+00
2ebf3038-bbde-4a6b-8dfd-596fd630ce55	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:21:42.970831+00	2026-02-13 00:21:42.970831+00
d997bfd9-1e8a-49b9-bbd2-ebc76ec007e8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:21:44.195599+00	2026-02-13 00:21:44.195599+00
150c5107-ad87-4aef-bb26-f5ab194b5031	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:46.463306+00	2026-02-13 00:21:46.463306+00
4b751789-477c-4b44-a6ba-d545ce6c7505	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:21:46.651115+00	2026-02-13 00:21:46.651115+00
39f5d960-eccf-4871-876e-b2d98137b286	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:21:46.981814+00	2026-02-13 00:21:46.981814+00
6caa7eed-0a64-4dfd-86ad-3846f7052508	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:20:52.842308+00	2026-02-13 00:20:52.842308+00
f98c9c25-9bfd-46fe-adae-6325a20140e8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.1	python-requests/2.32.5	failure	{"reason": "invalid_password"}	2026-02-13 05:19:59.10426+00	2026-02-13 05:19:59.10426+00
12711210-c85c-48c5-9e79-d5d579bcf607	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:20:54.716376+00	2026-02-13 00:20:54.716376+00
69f72ca7-fbaf-4d32-a4c2-e20fe984fe1a	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:20:55.193703+00	2026-02-13 00:20:55.193703+00
c21ee4a8-b856-4bad-842f-2d67d7a0cede	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:20:54.100777+00	2026-02-13 00:20:54.100777+00
d9fdba8f-cd7d-4040-a76c-4c184b3074ad	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:26.927447+00	2026-02-13 00:21:26.927447+00
bba3c4c8-b128-4bfa-bd87-86bb18ba834c	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:21:27.455893+00	2026-02-13 00:21:27.455893+00
04449806-48c2-4b2b-b20c-62e8040e509e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:28.20209+00	2026-02-13 00:21:28.20209+00
66ca39a0-f8be-48fa-8852-e74feca2486e	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:21:28.841359+00	2026-02-13 00:21:28.841359+00
90d31977-5069-41bc-bfa8-61797f94ea0e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:29.451307+00	2026-02-13 00:21:29.451307+00
d9bb42c9-9a4f-416c-91fb-7ffbd09d88dc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:30.113746+00	2026-02-13 00:21:30.113746+00
7afd679a-bc7a-45d2-8bd5-d3185656caac	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:30.756929+00	2026-02-13 00:21:30.756929+00
b3e9eb0c-c3b6-471c-8603-85ac5cfd5bbe	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:31.401061+00	2026-02-13 00:21:31.401061+00
d8b46a66-92bd-4c6c-a0cd-6ed354a29fda	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:21:33.511373+00	2026-02-13 00:21:33.511373+00
d3ba35cc-25c7-4a98-8162-78cf37dbca79	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:33.978493+00	2026-02-13 00:21:33.978493+00
d33e9721-0ee8-4478-a274-177333b8439e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:46.262017+00	2026-02-13 00:21:46.262017+00
31f6a289-c187-4272-b29e-504b51ff2d93	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:46.797044+00	2026-02-13 00:21:46.797044+00
7cf09ffa-41dc-4b08-8181-4cae588c75b7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:47.733195+00	2026-02-13 00:21:47.733195+00
9cc9d18f-245f-43ec-8f5f-de32aa5614bd	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:21:48.381666+00	2026-02-13 00:21:48.381666+00
89812e7b-3542-42c7-988d-825a8883ee47	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:48.942712+00	2026-02-13 00:21:48.942712+00
3ada22af-4475-405b-84e0-ffec5c73ff02	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:49.554088+00	2026-02-13 00:21:49.554088+00
17b4838a-f869-44ec-ab94-95ae72cd7682	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:50.188648+00	2026-02-13 00:21:50.188648+00
11f09d9c-ab50-4aca-88f6-3f15ce7f88d3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:50.81448+00	2026-02-13 00:21:50.81448+00
7d5870d6-dfc2-4bbd-a594-bf7e92322d9f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:51.93664+00	2026-02-13 00:21:51.93664+00
2f0d3400-f860-4689-8809-b659e2fb390e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:53.056923+00	2026-02-13 00:21:53.056923+00
1b268c4a-36c7-4579-bf9e-f459ed15d684	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:52.413095+00	2026-02-13 00:21:52.413095+00
c452afbc-5997-4f24-a113-b30eb351a59d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:55.470102+00	2026-02-13 00:21:55.470102+00
984a8e94-4e43-40a7-bae8-12896c4deed5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:22:03.964345+00	2026-02-13 00:22:03.964345+00
48a299de-92f7-4628-8112-f017e8ad5f4e	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:22:04.470743+00	2026-02-13 00:22:04.470743+00
58f89a38-9644-45be-acde-e188079d0510	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:22:05.434574+00	2026-02-13 00:22:05.434574+00
cb8fcd21-a910-4b47-951f-6c0402336b7e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:22:06.204815+00	2026-02-13 00:22:06.204815+00
4b92e5ca-ee97-4bba-b6d1-1b693e46c5a6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:22:06.978975+00	2026-02-13 00:22:06.978975+00
d12d7734-799f-44dd-9c35-6c941263c72f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:22:08.003658+00	2026-02-13 00:22:08.003658+00
7232f1d6-4f96-4acb-9ae7-deddb08cffc6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:08.92988+00	2026-02-13 00:22:08.92988+00
36176f2f-8e15-4ab8-a1a8-dddf0aa06c47	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:10.373947+00	2026-02-13 00:22:10.373947+00
a24dbc66-efb4-4ebf-865d-61a22a3a69ea	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:22:10.870468+00	2026-02-13 00:22:10.870468+00
81af7523-04c5-4378-906c-dcde4843f126	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:22:09.737673+00	2026-02-13 00:22:09.737673+00
6e8e6a5f-cd39-4315-bf34-491f20ca4b1e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:15.236427+00	2026-02-13 00:22:15.236427+00
78111fd8-0518-4fe2-ab67-effa6b77c0d3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:29.125407+00	2026-02-13 00:22:29.125407+00
40c6907e-3086-4200-b8a6-2825ed72edd5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:51.449377+00	2026-02-13 00:26:51.449377+00
25948753-afc8-4726-a10d-43a619a96e1d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:47.555881+00	2026-02-13 00:21:47.555881+00
261e83c7-e555-460d-a2aa-1ecb93036d82	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:48.079932+00	2026-02-13 00:21:48.079932+00
1ca8c467-df28-479d-bb80-1557dcea9591	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:21:48.684507+00	2026-02-13 00:21:48.684507+00
b75e40a2-d061-496e-bcdc-7f2f7810fe48	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:49.381619+00	2026-02-13 00:21:49.381619+00
590a7555-17a6-4f00-a046-b1eea7d4d828	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:50.019489+00	2026-02-13 00:21:50.019489+00
b6ab6fd4-5408-4101-a90c-4d0a7db76ae4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:50.530721+00	2026-02-13 00:21:50.530721+00
9bae99db-73b2-4840-9ba9-24dc1710a24b	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:21:52.905896+00	2026-02-13 00:21:52.905896+00
a89b18e8-156e-42f1-ae85-f17521c10477	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 05:20:11.019466+00	2026-02-13 05:20:11.019466+00
674bd1d4-e119-4508-87bb-2eca6f637a77	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:53.365878+00	2026-02-13 00:21:53.365878+00
3a3e44af-2920-48bd-9ab5-b1029900603e	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:22:04.149798+00	2026-02-13 00:22:04.149798+00
6e26a7d3-2778-4ccf-b029-fec6ffe05aa8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:22:05.083818+00	2026-02-13 00:22:05.083818+00
566ff00b-f000-4cec-80ee-9d8d1541b868	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:22:05.608397+00	2026-02-13 00:22:05.608397+00
53d1955e-8f39-462f-a54f-40e64be38a01	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:22:06.214315+00	2026-02-13 00:22:06.214315+00
8d784710-c4a4-467b-82a7-8cadb95884e9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:22:07.155449+00	2026-02-13 00:22:07.155449+00
77c1b243-341f-4dc2-ae4e-67a13501ee8d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:07.652952+00	2026-02-13 00:22:07.652952+00
ae92577a-9f37-48c1-a0de-a4c71a1965dc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:22:08.179592+00	2026-02-13 00:22:08.179592+00
893aad0c-4a1f-489a-b027-a3f8b8184796	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:22:10.548434+00	2026-02-13 00:22:10.548434+00
d2b3ec57-9983-4ac0-b8ce-04430aee2fd9	eb8f2199-7903-409d-8999-1e450e3c90b8	login_failed	\N	172.24.0.1	curl/8.17.0	failure	{"reason": "invalid_password"}	2026-02-14 20:58:21.383043+00	2026-02-14 20:58:21.383043+00
8a7ae1aa-0b57-4b41-8e65-033bf4f75c45	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:11.013167+00	2026-02-13 00:22:11.013167+00
6a1cd890-6a1d-4d00-adbc-762de47854e8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:21.658033+00	2026-02-13 00:22:21.658033+00
90b6ec99-21f3-412b-9b6b-195ff49c86c0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:22:22.86506+00	2026-02-13 00:22:22.86506+00
8f69e249-4d0d-4ce0-9fa2-d826bbef4a34	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:32.266014+00	2026-02-13 00:22:32.266014+00
29b34243-981d-45bc-b395-a480ae338231	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:22:39.694968+00	2026-02-13 00:22:39.694968+00
403f3c27-c88b-4161-a47b-8f06e25b88b7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:43.574727+00	2026-02-13 00:22:43.574727+00
c5c3b8b7-f403-48df-908a-303c9555091b	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.24.0.1	curl/8.17.0	success	{}	2026-02-14 20:58:40.232842+00	2026-02-14 20:58:40.232842+00
0fb964b7-4c44-450d-b3c6-07bba258758c	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.24.0.1	curl/8.17.0	success	{}	2026-02-14 21:00:39.987705+00	2026-02-14 21:00:39.987705+00
bc10840b-aec7-48c5-ac89-53e1b0f67116	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.24.0.1	curl/8.17.0	success	{}	2026-02-14 21:02:13.323968+00	2026-02-14 21:02:13.323968+00
f75d0f02-164a-4294-a1fd-419111c1437e	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	curl/8.17.0	success	{}	2026-02-14 21:20:57.536+00	2026-02-14 21:20:57.536+00
a9ef82c0-1a9f-4bc0-a474-81e901b8c711	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 21:21:21.291036+00	2026-02-14 21:21:21.291036+00
631f8859-8182-404f-bc14-78081ab72dec	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.24.0.1	curl/8.17.0	success	{}	2026-02-14 21:21:45.729372+00	2026-02-14 21:21:45.729372+00
df5c6b0f-8668-4f60-afec-2f4f17dd3643	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:47.907158+00	2026-02-13 00:21:47.907158+00
41b4069c-f437-46f7-9df9-ef63320401ce	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:21:48.676519+00	2026-02-13 00:21:48.676519+00
b532ccfc-6151-44ed-a56c-bc24d6ec3298	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:49.725913+00	2026-02-13 00:21:49.725913+00
2a4b3ea3-951e-48bc-9040-42fd9315b749	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:21:50.358622+00	2026-02-13 00:21:50.358622+00
950fcacd-a997-4831-956f-55330fabe05a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:51.281083+00	2026-02-13 00:21:51.281083+00
74153f70-f903-4fd3-8b12-dade7431ec22	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-13 05:27:44.837407+00	2026-02-13 05:27:44.837407+00
363d69da-49ac-4b5c-bba2-8eef51754b4a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:52.732372+00	2026-02-13 00:21:52.732372+00
0b4231e2-0b06-43d6-bb61-d9134847b492	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:21:53.229282+00	2026-02-13 00:21:53.229282+00
ecd43be9-fc56-4fea-b2de-c4e78ddb8111	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:21:52.112059+00	2026-02-13 00:21:52.112059+00
6f81dc36-ae21-4fca-86b9-8fc1ae752a44	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:54.017965+00	2026-02-13 00:21:54.017965+00
55752948-18a6-440d-9e88-c2af9ccfb056	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:21:54.751508+00	2026-02-13 00:21:54.751508+00
ed6a2afc-f4c7-4713-92ec-50de64e5f53f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:03.770535+00	2026-02-13 00:22:03.770535+00
92c712a8-34fe-4a17-a2bb-1f4f4163d92e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:04.282804+00	2026-02-13 00:22:04.282804+00
7327569b-0986-4254-b622-767ad82eed5a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:22:05.259705+00	2026-02-13 00:22:05.259705+00
7a174b3e-6f56-4dec-8364-f5e9fc4a88f0	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:22:05.912435+00	2026-02-13 00:22:05.912435+00
95e0556e-892d-440e-a47f-b197c6433a99	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:06.49312+00	2026-02-13 00:22:06.49312+00
25a3e8bf-1048-4ac9-a080-be21956f36e4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:22:07.329976+00	2026-02-13 00:22:07.329976+00
f8fbec9d-5087-4824-b4a2-d2b4e7f603ca	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:22:07.831086+00	2026-02-13 00:22:07.831086+00
6d0a621e-15a3-4901-9da3-46acba7a9abc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:08.446968+00	2026-02-13 00:22:08.446968+00
39e3d941-bb5c-4e92-b00c-9208c875d1b2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:09.560725+00	2026-02-13 00:22:09.560725+00
7f6dea06-e084-4886-8215-4648a8d16f8d	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.24.0.1	curl/8.17.0	success	{}	2026-02-14 21:21:36.806718+00	2026-02-14 21:21:36.806718+00
89ba26fa-a0aa-4a9b-b401-6b40c2fab58e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:10.693888+00	2026-02-13 00:22:10.693888+00
119927ab-69ae-4be1-a6a9-b021e695661b	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:10.050384+00	2026-02-13 00:22:10.050384+00
390e88f0-1c45-4d80-b762-048d71c21927	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:11.677067+00	2026-02-13 00:22:11.677067+00
0dc8d19f-7881-42f1-bf39-8309d3f877f8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:22:15.943076+00	2026-02-13 00:22:15.943076+00
bfdbef27-a336-4835-bc65-b0008e7acb6d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:22.477656+00	2026-02-13 00:22:22.477656+00
bc8871db-c89a-4ca3-841d-2f0faf1fdb5c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:25.840058+00	2026-02-13 00:22:25.840058+00
9572328c-60b8-4ee2-b75a-d0990457a18b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:22:29.762278+00	2026-02-13 00:22:29.762278+00
35ca2878-f4c1-4f15-8779-85a3d1835173	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:37.022781+00	2026-02-13 00:22:37.022781+00
19a566d9-96e1-4777-955c-db65b7aab380	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:41.974665+00	2026-02-13 00:22:41.974665+00
4dbfcc4d-7c06-4087-b9a7-e257ddc9c28b	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.24.0.1	curl/8.17.0	success	{}	2026-02-14 21:21:49.874464+00	2026-02-14 21:21:49.874464+00
17a9af98-bafd-4648-82aa-274a8583f807	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 21:22:15.690487+00	2026-02-14 21:22:15.690487+00
dfd05bba-c532-4c36-bcfc-daf7ad7a1167	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:35.639024+00	2026-02-13 00:22:35.639024+00
7d8f739a-3368-4bb0-8368-34b7c7edf2c8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:38.193937+00	2026-02-13 00:22:38.193937+00
b0443d4c-1f16-43cc-95bc-bc275a1b967e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:38.892895+00	2026-02-13 00:22:38.892895+00
c4465d0a-7281-44d4-be3b-4874d77b3147	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:22:49.708036+00	2026-02-13 00:22:49.708036+00
233d1499-d1b5-4cd1-b301-ede3daf26cba	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:56.521769+00	2026-02-13 00:22:56.521769+00
246756c8-fd8b-46fa-bf8d-6352ca147e7e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:22:58.51182+00	2026-02-13 00:22:58.51182+00
52be124e-dff7-469d-9a50-8886c3c7eb31	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:23:00.157344+00	2026-02-13 00:23:00.157344+00
47ec6179-b1e1-4d16-9d24-8060ca162889	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:23:01.238113+00	2026-02-13 00:23:01.238113+00
d081d156-1a37-419a-be3f-d01f448a0f8b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:23:09.933949+00	2026-02-13 00:23:09.933949+00
1528c414-4b8e-4e42-8b77-69489d553681	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:23:13.170949+00	2026-02-13 00:23:13.170949+00
037d5635-f0cc-4734-9db2-d52a04fda189	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:23:16.427223+00	2026-02-13 00:23:16.427223+00
174e16c5-aeb4-4634-95d6-593b1f6598ce	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:23:22.343999+00	2026-02-13 00:23:22.343999+00
46539e9d-119a-4d8a-af3b-01a39a6886fe	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:23:25.694108+00	2026-02-13 00:23:25.694108+00
6e88c226-dfac-4846-99fb-c15dd95feff7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:23:28.708895+00	2026-02-13 00:23:28.708895+00
2fae7592-4ba4-420d-8363-6ec79588cb61	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:23:32.079026+00	2026-02-13 00:23:32.079026+00
c190ce82-37c7-47cd-ac19-6396725fa9d7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:23:33.647949+00	2026-02-13 00:23:33.647949+00
6367b294-0519-47b3-b2aa-00bf43d70c5e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:46.338861+00	2026-02-13 00:26:46.338861+00
817b7372-896c-49e9-8b15-e34c960e7b62	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:26:46.542459+00	2026-02-13 00:26:46.542459+00
f275ff7d-e4f3-41da-8634-71c665c08685	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:26:46.740454+00	2026-02-13 00:26:46.740454+00
0839dc5c-80c9-48ac-b49e-afdff503aa43	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:46.906627+00	2026-02-13 00:26:46.906627+00
76c849d7-8017-4229-ac48-e7a4088bb9a7	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:26:47.101193+00	2026-02-13 00:26:47.101193+00
7f5f6241-9fd8-4fa8-a024-07beb15020ec	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:26:47.682158+00	2026-02-13 00:26:47.682158+00
ba71c31a-3a8d-4a62-9dcd-0fafd7ecc008	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:26:47.859161+00	2026-02-13 00:26:47.859161+00
5a7c10a4-1305-4fe0-b824-163da99d7089	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:26:48.035443+00	2026-02-13 00:26:48.035443+00
eef394f8-a001-4964-be39-3b871617647e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:26:48.209489+00	2026-02-13 00:26:48.209489+00
39356e65-5a68-4856-bd99-757bc64c2bfd	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:26:48.505713+00	2026-02-13 00:26:48.505713+00
fc8fd350-3e92-4457-8d04-a69878a3b1e4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:26:48.803741+00	2026-02-13 00:26:48.803741+00
ace70815-c632-45be-a079-cbe54ef46668	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:26:48.813615+00	2026-02-13 00:26:48.813615+00
3c1c8024-1529-4e31-8f96-3c96a75fe4b1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:49.086937+00	2026-02-13 00:26:49.086937+00
360361e1-8bb6-4e46-8727-f0886bbaed85	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:26:49.531729+00	2026-02-13 00:26:49.531729+00
35814f9b-cc4f-45b8-9289-b8cf663e4170	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:26:49.714705+00	2026-02-13 00:26:49.714705+00
6bb373c2-5554-43d2-b744-102a3f0e9b90	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:26:49.890839+00	2026-02-13 00:26:49.890839+00
90d02cec-b79e-40de-b9bb-49be2776d5e2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:50.178648+00	2026-02-13 00:26:50.178648+00
02f6f421-bc7e-44d2-841d-71571a12e767	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:26:50.355349+00	2026-02-13 00:26:50.355349+00
a24c9ae3-3917-415f-8dd1-9f6947d8df7f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:26:50.528184+00	2026-02-13 00:26:50.528184+00
1150a21c-7e71-43a5-a7f8-71d87a21484d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:26:50.702274+00	2026-02-13 00:26:50.702274+00
eb0029c2-abd0-46be-b0e2-082997e7c02d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:52.108729+00	2026-02-13 00:26:52.108729+00
ef53abfb-4055-43f1-9726-4df4da63dc07	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 05:32:14.064771+00	2026-02-13 05:32:14.064771+00
1007e1de-0ba7-4cf1-9c6f-cf86c03e5dc7	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.24.0.1	curl/8.17.0	success	{}	2026-02-14 21:21:41.150933+00	2026-02-14 21:21:41.150933+00
66baee83-d6a3-4963-ad41-92b3cadec5db	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:52.577028+00	2026-02-13 00:26:52.577028+00
283e9a1c-d9e5-4676-86de-2bbdef4f0675	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:53.535194+00	2026-02-13 00:26:53.535194+00
a4f30f81-bed8-47b7-a3a6-2c2cea3abaf1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:55.583847+00	2026-02-13 00:26:55.583847+00
1cd1e6a9-1acb-476d-8623-990a683ca1ef	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:27:02.336276+00	2026-02-13 00:27:02.336276+00
2eaaa39a-b32f-422f-b755-b1ca5efe281b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:27:10.212643+00	2026-02-13 00:27:10.212643+00
4a2846ec-fe43-43d3-ba0c-c6540c8c2cad	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:27:10.721158+00	2026-02-13 00:27:10.721158+00
fa8798a1-7d29-4957-afcd-7b3d9ddc0cfc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:27:11.636203+00	2026-02-13 00:27:11.636203+00
cf2d299c-127e-4de4-bbd6-624f405983e4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:27:12.397638+00	2026-02-13 00:27:12.397638+00
03216831-e71a-4d4b-b2a9-8b8f22ce0c42	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:27:13.136604+00	2026-02-13 00:27:13.136604+00
3bb6a117-8046-494e-9372-7839d1cbfd13	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:13.787238+00	2026-02-13 00:27:13.787238+00
5dfaf2b1-a9b6-4992-8e4a-e4167c0fb3ec	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:15.052999+00	2026-02-13 00:27:15.052999+00
8cb7f40a-fe16-4fbf-bf39-0fe115b62a9f	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.24.0.1	curl/8.17.0	success	{}	2026-02-14 21:21:54.335696+00	2026-02-14 21:21:54.335696+00
fa26cfeb-bcfd-49be-80fa-632b8d0f0f2b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:16.495524+00	2026-02-13 00:27:16.495524+00
894ab191-f4f2-42c4-a20b-3ffde9d88591	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:27:16.973622+00	2026-02-13 00:27:16.973622+00
da9f9052-6add-4eaf-988a-865ab0cfcb5d	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:27:15.858307+00	2026-02-13 00:27:15.858307+00
58087671-818a-40f4-b3c4-6d6686410b9a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:19.210978+00	2026-02-13 00:27:19.210978+00
80977842-c4cb-47a9-94bb-18479e472a84	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:27:42.220195+00	2026-02-13 00:27:42.220195+00
84309153-fa41-4ecc-82b1-844a1011e213	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:27:50.614102+00	2026-02-13 00:27:50.614102+00
dd2987a4-5f80-4f35-b019-6152d7acee75	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:27:53.03368+00	2026-02-13 00:27:53.03368+00
7beb0ee7-9853-45e4-9ab5-d33b15742ff2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:27:58.811221+00	2026-02-13 00:27:58.811221+00
bdc5deca-0fed-428a-9132-a129464da7d6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:09.814171+00	2026-02-13 00:28:09.814171+00
1c645b93-851c-4806-bcdd-7f7dc1c90c11	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 21:23:22.499021+00	2026-02-14 21:23:22.499021+00
4224d80a-a508-42fb-8af3-29d218d90c67	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 05:34:40.676557+00	2026-02-13 05:34:40.676557+00
7b7ca882-165c-4de9-bd8e-0ae186ad0913	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:52.878288+00	2026-02-13 00:26:52.878288+00
5a7f38b8-2ecc-4aed-91a0-b8beb4a31cf8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:53.228389+00	2026-02-13 00:26:53.228389+00
93edd6c6-a84a-4831-a178-2ee7d8d22ef4	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:26:52.285205+00	2026-02-13 00:26:52.285205+00
8ca02eef-399c-419e-883f-a6dfe0b1639c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:54.144888+00	2026-02-13 00:26:54.144888+00
a7407bff-1534-495e-8b00-f105126011aa	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:26:54.88024+00	2026-02-13 00:26:54.88024+00
7aa24a76-8c68-474e-b18f-e4453f07cd03	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:27:10.393706+00	2026-02-13 00:27:10.393706+00
968b9023-366f-4d64-a701-dd809bcb4483	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:27:11.28724+00	2026-02-13 00:27:11.28724+00
773bcf83-9ddd-47d8-8c86-93151853a021	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:27:11.813605+00	2026-02-13 00:27:11.813605+00
ba18176c-e66a-4b45-82fc-da8133de95c8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:27:12.4048+00	2026-02-13 00:27:12.4048+00
c9083052-238b-467a-b723-d72606fb22e5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:27:13.310265+00	2026-02-13 00:27:13.310265+00
5c501ad7-b3f8-4417-84f4-49bb879423b9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:27:13.960382+00	2026-02-13 00:27:13.960382+00
c57f87fd-6322-472e-a849-75647960610d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:27:14.305968+00	2026-02-13 00:27:14.305968+00
9f1046b6-9152-415d-b84b-d550a75b63ef	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:27:16.670216+00	2026-02-13 00:27:16.670216+00
7114af79-4a5e-4767-bcc6-fc2291d4998b	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 21:35:01.202208+00	2026-02-14 21:35:01.202208+00
9c64fe20-f10c-4264-8a95-3df8f2672874	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:17.118135+00	2026-02-13 00:27:17.118135+00
9ff4c754-acc9-4e4a-aeb9-cd960ec21d04	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:27:45.518655+00	2026-02-13 00:27:45.518655+00
92497424-6b48-4db6-9a88-43017f71d7a9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:27:51.949019+00	2026-02-13 00:27:51.949019+00
7dcf3c61-6b94-4110-b32d-39e04e1670ab	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:03.906797+00	2026-02-13 00:28:03.906797+00
9843a8f7-695f-420b-a6a7-52c1d034e4f5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:05.251834+00	2026-02-13 00:28:05.251834+00
c9b20356-2e6c-4ed3-b5d9-991fb53f433a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:05.739399+00	2026-02-13 00:28:05.739399+00
c0c71c7e-3e9c-4f96-9c52-bb0cb9083c3d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:10.921789+00	2026-02-13 00:28:10.921789+00
f5a67c12-0b2f-4662-a1a1-00276c57a8ce	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:26:53.068088+00	2026-02-13 00:26:53.068088+00
8d8dde8f-7bac-4517-a932-6c31d1001135	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:26:53.402704+00	2026-02-13 00:26:53.402704+00
3b22f668-1cab-4519-b127-ae8c678b99a1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:27:01.084281+00	2026-02-13 00:27:01.084281+00
916a05aa-f193-4940-b3c6-dfdc3d2a56ae	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:10.021527+00	2026-02-13 00:27:10.021527+00
c51db271-02f0-4ed2-af7d-17a573485dc3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:10.537848+00	2026-02-13 00:27:10.537848+00
157d21ca-3c85-49c3-a4cd-0fc878baecd0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:27:11.461198+00	2026-02-13 00:27:11.461198+00
58c76902-c823-49c7-b5b2-f0de4f038ddf	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:27:12.105656+00	2026-02-13 00:27:12.105656+00
81d49d00-c681-403b-b2a5-f1942886afd7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:12.690748+00	2026-02-13 00:27:12.690748+00
b51a7e11-6a94-476f-b3ce-6e95349145f5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:27:13.481474+00	2026-02-13 00:27:13.481474+00
127d4feb-10cf-4eb3-893e-ea89e6859d90	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:27:14.132127+00	2026-02-13 00:27:14.132127+00
a4f05fb2-cbb9-4776-82bf-58af906a9a01	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:14.602337+00	2026-02-13 00:27:14.602337+00
7896dcc6-2e5f-48cc-86d1-84728de3d614	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:15.678694+00	2026-02-13 00:27:15.678694+00
a451a1b6-5cdc-4345-b269-5920d8d6fb62	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 05:35:48.539777+00	2026-02-13 05:35:48.539777+00
7961e308-ced0-4f87-8d4a-6b1cb6c1384e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:16.799502+00	2026-02-13 00:27:16.799502+00
3837f21d-89c8-4237-b78e-f20c3aaab716	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:16.178688+00	2026-02-13 00:27:16.178688+00
bce94f3e-eae9-4228-bcbe-8ec613db6f8e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:17.766393+00	2026-02-13 00:27:17.766393+00
495e50bd-62ab-4127-9258-74f4005c9038	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:27:18.517822+00	2026-02-13 00:27:18.517822+00
e490a688-9601-4af5-9edc-5a9bac1f775f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:27:24.417383+00	2026-02-13 00:27:24.417383+00
278519c1-0f6c-4b2b-8a2b-08e2a9269907	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:27:25.611258+00	2026-02-13 00:27:25.611258+00
d30dab85-5942-4b18-819d-2c88e5c7c7dc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:27:33.351485+00	2026-02-13 00:27:33.351485+00
8b67b09e-0952-4b4f-bc22-a69f390e0dd7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:27:43.015532+00	2026-02-13 00:27:43.015532+00
67f28e65-1120-4b1d-806b-5adc25d42c78	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:27:44.238179+00	2026-02-13 00:27:44.238179+00
cd5a510c-5ae4-43f2-a132-2eb23ef38791	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:27:49.365913+00	2026-02-13 00:27:49.365913+00
0fe06809-e86f-4d23-a273-6dd770e66410	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:27:59.91019+00	2026-02-13 00:27:59.91019+00
8a28e061-8f55-42a7-b06c-98c0c2351f29	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:02.254546+00	2026-02-13 00:28:02.254546+00
b0628110-3407-45bd-b949-2d0ccc051107	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:08.06384+00	2026-02-13 00:28:08.06384+00
96bb7174-2d2d-4fcf-8af3-3abd38eb0215	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:09.25457+00	2026-02-13 00:28:09.25457+00
a13608c5-175c-46fc-a624-f57c45db925e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:11.349102+00	2026-02-13 00:28:11.349102+00
4b8fdcdb-05bc-422c-802b-7addeae230af	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:16.66311+00	2026-02-13 00:28:16.66311+00
24a34631-0411-4f1f-bd1d-fe537bb9caf0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:18.11934+00	2026-02-13 00:28:18.11934+00
31e7f2d6-104b-4d2f-892f-82b1273bd51c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:19.866875+00	2026-02-13 00:28:19.866875+00
34bd298e-69cb-48e8-9f2e-78eebf9df4a1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:20.717336+00	2026-02-13 00:28:20.717336+00
ea52a613-e4f8-4d9e-9abe-c4f0de6698bc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:22.554784+00	2026-02-13 00:28:22.554784+00
9910fbe0-d6da-4bc2-b208-c6c93c295057	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:22.939398+00	2026-02-13 00:28:22.939398+00
dfdbf756-0bfe-4b83-8b3c-b9792f0bb60e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:26.803885+00	2026-02-13 00:28:26.803885+00
459c7bf5-d4bc-4da4-a586-61e41c0f0ef7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:28:28.689906+00	2026-02-13 00:28:28.689906+00
67786516-b8da-49ae-80ea-ccdb24130d7a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:44.53857+00	2026-02-13 00:29:44.53857+00
1e5dae17-184e-4f9b-a0f8-2e6758f7e520	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:29:45.245845+00	2026-02-13 00:29:45.245845+00
90c32494-8c36-4655-8061-fe73c00ec2b0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:29:46.367631+00	2026-02-13 00:29:46.367631+00
5e10f787-584a-4a2a-9bd0-65f49cca8a97	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:47.289792+00	2026-02-13 00:29:47.289792+00
dace5a58-6776-44de-aa65-3c778d9d79c0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:29:48.119058+00	2026-02-13 00:29:48.119058+00
98cf0654-769b-4a59-87b7-9797b138e041	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:29:48.975925+00	2026-02-13 00:29:48.975925+00
8f328c3a-07f5-4e8e-b389-b1b664ab099f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:52.816556+00	2026-02-13 00:29:52.816556+00
2b628ea1-e13f-402e-9d37-7bdaa1f39040	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:53.637797+00	2026-02-13 00:29:53.637797+00
6a00efdc-5fb4-4b0f-91c4-8444d054b211	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 05:39:37.823689+00	2026-02-13 05:39:37.823689+00
ea43ac04-cc7b-4537-86d9-0060b7dd5cb9	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:54.277298+00	2026-02-13 00:29:54.277298+00
f0266d68-dc1b-4724-b285-1a226acc09b1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:30:12.795605+00	2026-02-13 00:30:12.795605+00
5c7f6784-f8b7-4a4a-9954-59f2ef0cfb5a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:30:13.881206+00	2026-02-13 00:30:13.881206+00
3b1a9b3f-b080-4e6c-830e-f95832c65849	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:30:14.69049+00	2026-02-13 00:30:14.69049+00
93ab897b-a96b-4816-bbba-258642e733b6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:30:15.72174+00	2026-02-13 00:30:15.72174+00
3ca268a9-e8f2-4df2-9325-7674ffadbcb4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:30:16.521767+00	2026-02-13 00:30:16.521767+00
07d08bc6-3054-4a22-93ef-d620a2388460	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:17.156238+00	2026-02-13 00:30:17.156238+00
66697dd6-b040-4b8a-b17d-f72b13b0914a	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-14 22:06:00.72651+00	2026-02-14 22:06:00.72651+00
88d2384c-05da-4b34-8658-d933463e2833	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:30:19.19181+00	2026-02-13 00:30:19.19181+00
e4fc9260-36c6-47d5-9335-606a1b0ede39	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:30:18.425416+00	2026-02-13 00:30:18.425416+00
0184e73c-9243-49e2-a44b-6bb0118e3f96	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:20.324425+00	2026-02-13 00:30:20.324425+00
89f8827a-392e-42c9-99fa-4d3c5cbc8bf7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:30:36.609933+00	2026-02-13 00:30:36.609933+00
4efeba37-ec33-4692-8fec-d036eb66cc71	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:30:47.577307+00	2026-02-13 00:30:47.577307+00
0e8b7e3e-f850-4127-9cd7-9d608370f00d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:31:08.270607+00	2026-02-13 00:31:08.270607+00
c5d2ee5f-3e12-49a7-a978-0c7858814a5c	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:34:31.430223+00	2026-02-13 00:34:31.430223+00
f3d4d9c2-43b1-476c-a270-2c83418a9b10	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:34:32.547109+00	2026-02-13 00:34:32.547109+00
366e1c43-1408-4faf-8b38-17300876a0bf	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:34:33.189403+00	2026-02-13 00:34:33.189403+00
e55801fa-7d10-45b5-bf19-d7997b9cf246	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:34:34.264941+00	2026-02-13 00:34:34.264941+00
169653a1-6c8f-4fe0-ba12-de81d567cafd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:34:35.071704+00	2026-02-13 00:34:35.071704+00
d8c56a42-2272-420a-a462-1c36245eadb9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:36.152572+00	2026-02-13 00:34:36.152572+00
62572a5b-af15-419a-9143-18b5584bb948	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:34:37.756755+00	2026-02-13 00:34:37.756755+00
71be36d8-038b-46bc-99d5-1b84e753f6d0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:38.833328+00	2026-02-13 00:34:38.833328+00
20661114-e90b-4a12-a469-cd5865ea800b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:29:44.727824+00	2026-02-13 00:29:44.727824+00
6d8dd109-e3bd-4c2c-b464-01e16fc7c546	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:29:45.828568+00	2026-02-13 00:29:45.828568+00
fc96c80f-153d-4525-bfb5-f2f9a05a589c	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:29:46.671565+00	2026-02-13 00:29:46.671565+00
558a81bb-b551-4f8b-955b-d1f5e53a3e35	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:48.428807+00	2026-02-13 00:29:48.428807+00
7daeaafb-ebc5-473d-8cba-b90e2b2e1bf2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:49.273212+00	2026-02-13 00:29:49.273212+00
27afaa68-567a-4abe-a3f9-f905299374b1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 05:43:37.108085+00	2026-02-13 05:43:37.108085+00
1dba339c-f427-4731-bd48-e1249ac44012	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:29:53.817229+00	2026-02-13 00:29:53.817229+00
80018262-4f0f-4d26-aed5-1d3fad9de8ef	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:29:53.001879+00	2026-02-13 00:29:53.001879+00
a4341422-8030-4c74-b01d-e1c446b1ad7e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:55.677139+00	2026-02-13 00:29:55.677139+00
77e2e393-2287-4dc0-bab5-c5e479000059	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:30:02.978325+00	2026-02-13 00:30:02.978325+00
0e6ed991-e041-4bc3-9a17-44e52395e3e9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:12.608779+00	2026-02-13 00:30:12.608779+00
74288d1c-29a8-4326-b5cf-851bbd7c6463	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:30:13.290755+00	2026-02-13 00:30:13.290755+00
cc9c502f-5c81-4a71-9076-7d544fcd976f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:30:14.40324+00	2026-02-13 00:30:14.40324+00
e029fd2b-f5c5-4960-91fc-faf4e55b1adc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:15.26951+00	2026-02-13 00:30:15.26951+00
0eacb6f7-81cf-4eec-a92d-8b88ffc2e5d7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:16.348353+00	2026-02-13 00:30:16.348353+00
2686271a-562a-4cc1-b317-d5524278fb48	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:18.251364+00	2026-02-13 00:30:18.251364+00
dbbdfe96-2aaf-4181-8973-4382fdf18c95	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:19.024638+00	2026-02-13 00:30:19.024638+00
2c7ccd9e-a0df-4e84-836f-86554f637fe4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:44.380039+00	2026-02-14 23:05:44.380039+00
09c95a28-3111-46db-84bb-644ad609795e	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:19.663778+00	2026-02-13 00:30:19.663778+00
8cb79fc1-27ee-40da-98ea-7da412171d57	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:21.135038+00	2026-02-13 00:30:21.135038+00
4fa1b9be-c5d9-4023-ad36-c0585481b72f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:21.876104+00	2026-02-13 00:30:21.876104+00
c2fc3d67-17ad-4b09-88af-cb0c3663b082	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:30:50.471962+00	2026-02-13 00:30:50.471962+00
d1efc57f-ad26-4019-a769-9b73f32c9917	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:31:01.071524+00	2026-02-13 00:31:01.071524+00
dd7bdf0f-d5bf-41f7-894a-07c9786340c8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:34:31.252673+00	2026-02-13 00:34:31.252673+00
472756f2-cf6f-4640-8faf-d96a863a298c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:34:32.378155+00	2026-02-13 00:34:32.378155+00
6237813a-89e0-4722-9c2b-35a2db3411cd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:33.788848+00	2026-02-13 00:34:33.788848+00
811e7d91-61be-4fd3-9e18-01e9882279ec	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:34.903485+00	2026-02-13 00:34:34.903485+00
82b24b53-72fe-4cd5-9189-c6e8ea362bb9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:35.707773+00	2026-02-13 00:34:35.707773+00
6b579560-988c-454f-a98d-39eab1a37ac1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-14 23:05:44.595159+00	2026-02-14 23:05:44.595159+00
dce71a3c-24c8-4451-ace7-b9dfab27a325	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:37.585145+00	2026-02-13 00:34:37.585145+00
bd9eaa99-dae2-470d-9b93-42c81dfc9557	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-14 23:05:44.776426+00	2026-02-14 23:05:44.776426+00
c599db79-ccd1-4ac1-9064-05f5c06b6426	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:38.220424+00	2026-02-13 00:34:38.220424+00
c933161e-5283-436b-9007-91bd4e76c60f	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:34:36.966925+00	2026-02-13 00:34:36.966925+00
fac8a7cb-f405-4f28-9931-4be15a74a33d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:39.593388+00	2026-02-13 00:34:39.593388+00
1446dc80-9e29-40c8-92de-47f3419c7fc2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:44.938422+00	2026-02-14 23:05:44.938422+00
4f4b334b-a924-45c0-9048-e9ed9f4e36a5	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-14 23:05:45.119371+00	2026-02-14 23:05:45.119371+00
cd1de6cc-78be-4279-81c8-e393d3aac0d5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-14 23:05:45.946839+00	2026-02-14 23:05:45.946839+00
b3eb7302-a74a-4cd8-a505-a4b9860d2c86	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-14 23:05:46.250381+00	2026-02-14 23:05:46.250381+00
64bed559-7847-4283-a88a-cc2615a5be5b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-14 23:05:46.857503+00	2026-02-14 23:05:46.857503+00
10f41551-a89f-444b-84ad-557224638cd0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-14 23:05:47.485422+00	2026-02-14 23:05:47.485422+00
8dc9ad1e-2a18-4b07-a5a8-33fbad24d64f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:48.065601+00	2026-02-14 23:05:48.065601+00
bcbae782-6172-4900-960e-0b9607a7ac28	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:29:44.906933+00	2026-02-13 00:29:44.906933+00
7a357eb3-247b-497d-9df8-e67868c293e2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:29:46.007083+00	2026-02-13 00:29:46.007083+00
96704e86-4b24-4acc-8f99-0e2dd7af3277	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:29:46.977122+00	2026-02-13 00:29:46.977122+00
4a09be8c-20d3-4c86-8f79-288835ea94bd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:29:47.763552+00	2026-02-13 00:29:47.763552+00
73d47644-8da5-4408-a475-8d54fbc64317	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:29:48.612839+00	2026-02-13 00:29:48.612839+00
0f035423-d617-4db0-a888-4bcbb3545af8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:49.751379+00	2026-02-13 00:29:49.751379+00
619252ed-de22-4d44-9efb-932dbdf90756	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:53.948569+00	2026-02-13 00:29:53.948569+00
1db8a25a-8d62-4112-85f2-aa2f43f6bd70	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:54.93371+00	2026-02-13 00:29:54.93371+00
01e85b7f-631a-4971-a0cd-bff63d3a2db9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:13.110845+00	2026-02-13 00:30:13.110845+00
ac8a9526-19df-4328-883d-3d0ee59acf0d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:30:14.230628+00	2026-02-13 00:30:14.230628+00
53acaab0-bfa7-4db8-a565-c37652e2d57f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:30:14.997606+00	2026-02-13 00:30:14.997606+00
cd1441c4-80b4-4b8e-a59b-40ec9302ccd3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:30:16.064798+00	2026-02-13 00:30:16.064798+00
c339002f-f599-4907-8698-16aaa2c932d8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:30:16.865413+00	2026-02-13 00:30:16.865413+00
b012c141-39df-440e-aa4a-2a0da6e375c5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 05:47:13.052177+00	2026-02-13 05:47:13.052177+00
2ea11c2d-afea-44ff-b76b-898df6867034	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:30:19.497888+00	2026-02-13 00:30:19.497888+00
90aac5cf-b844-48f6-824b-334aa696be0f	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:18.732387+00	2026-02-13 00:30:18.732387+00
d1c7f42f-61bd-4c81-9b35-6353505ee779	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:30:43.901022+00	2026-02-13 00:30:43.901022+00
954517d0-692a-498a-be8e-ee84b0ade5a7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:30:48.756498+00	2026-02-13 00:30:48.756498+00
6a2d7689-2b3d-4dbd-9812-e0784bcec841	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:31.58432+00	2026-02-13 00:34:31.58432+00
cf666286-eb7a-42b1-9f86-9e24ac53f250	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:34:32.719561+00	2026-02-13 00:34:32.719561+00
21b16d10-7d8b-4ada-be15-78652aeb68ca	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:34:33.503582+00	2026-02-13 00:34:33.503582+00
774fe06c-0ec2-478f-807e-d19a93fb8f07	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:34:34.436262+00	2026-02-13 00:34:34.436262+00
87df12a5-f081-46d7-a40e-2eac4aa2ba43	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:34:35.240102+00	2026-02-13 00:34:35.240102+00
5c95baa0-b43b-4ab8-a18c-4cdf9e053829	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-14 23:05:46.542456+00	2026-02-14 23:05:46.542456+00
c34a4c1f-43d0-449e-8f64-f0498c130cea	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:37.904213+00	2026-02-13 00:34:37.904213+00
0f86625a-ed4a-4bca-b8ac-040ba97b6917	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:37.272764+00	2026-02-13 00:34:37.272764+00
a388b562-2c3e-492c-a733-2c660ece4a21	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:40.299822+00	2026-02-13 00:34:40.299822+00
c60c95e5-bf4d-4cd7-91fa-9beb7a32ddfc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:34:48.615683+00	2026-02-13 00:34:48.615683+00
1ec5308d-c9e9-42a5-897a-14a434c881e1	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-14 23:05:47.172202+00	2026-02-14 23:05:47.172202+00
6206d607-3894-4e98-b970-ff262c8f45f3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-14 23:05:47.637844+00	2026-02-14 23:05:47.637844+00
282a270e-0be2-425c-b7d2-49ea0c2506cb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-14 23:05:48.654011+00	2026-02-14 23:05:48.654011+00
55a20cef-2a43-4f83-b74a-1627a2069be6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-14 23:05:48.992398+00	2026-02-14 23:05:48.992398+00
c63d24e5-dc36-4177-8ad9-443beae7fe45	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-14 23:05:49.50027+00	2026-02-14 23:05:49.50027+00
6f6f08fc-8d27-4a55-b202-c54e76bf253b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-14 23:05:49.846849+00	2026-02-14 23:05:49.846849+00
b9c42c46-2afb-4b2a-986e-308967821696	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-14 23:05:52.691567+00	2026-02-14 23:05:52.691567+00
5e255a21-c451-41f0-b884-80ce15525150	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-14 23:05:53.132529+00	2026-02-14 23:05:53.132529+00
c01f4846-9ff7-4c28-80b4-5f858addbd42	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-14 23:05:51.681628+00	2026-02-14 23:05:51.681628+00
3d68af57-635d-4b0d-96c4-e924b6506de5	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:52.082662+00	2026-02-14 23:05:52.082662+00
d8aae363-96d4-4114-978e-86ce2ecabda5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:45.054589+00	2026-02-13 00:29:45.054589+00
745eb5b6-e7ec-4c69-a047-07d3ae9397a6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:29:46.184433+00	2026-02-13 00:29:46.184433+00
4e65aaa7-369f-4343-92e3-e69c5ac49bc7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:29:46.985465+00	2026-02-13 00:29:46.985465+00
7a1a31f0-d2ce-41b2-b409-9153fa8c70b0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:29:47.942406+00	2026-02-13 00:29:47.942406+00
bb079d23-7ef1-466b-9bea-932072980e6b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:29:48.792402+00	2026-02-13 00:29:48.792402+00
28d6144a-f667-4330-87ab-b15c08dba944	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 05:50:29.830824+00	2026-02-13 05:50:29.830824+00
bbc6457c-ecdd-4ca0-82cd-0faeaacdc4db	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:29:54.128664+00	2026-02-13 00:29:54.128664+00
48378919-bab8-4df2-b547-9be7fe7b2080	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:53.31868+00	2026-02-13 00:29:53.31868+00
d8221886-67c3-4e1e-b7e7-619baf599494	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:29:56.388053+00	2026-02-13 00:29:56.388053+00
d0701bfe-dc1a-496b-868a-bfebb2ca5e45	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:30:01.67615+00	2026-02-13 00:30:01.67615+00
31966dd5-a8d2-4b0c-b14d-320b95789faf	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:30:10.209635+00	2026-02-13 00:30:10.209635+00
64f1bff8-b802-4980-a2b8-13252c55acd8	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:30:12.975053+00	2026-02-13 00:30:12.975053+00
53b44a93-8a88-4292-b2f6-7cd807f0fe76	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:30:14.056741+00	2026-02-13 00:30:14.056741+00
70628c62-3b4b-4569-a56a-1558c5921a5f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:30:14.988885+00	2026-02-13 00:30:14.988885+00
db629550-2b0d-4110-9f29-e53f4d2af279	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:30:15.890451+00	2026-02-13 00:30:15.890451+00
04ee5442-bda4-4e55-8275-3d9628f26286	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:30:16.690086+00	2026-02-13 00:30:16.690086+00
cf6390e3-9d5f-41bf-b8ca-636eea0a7b05	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:17.609414+00	2026-02-13 00:30:17.609414+00
67a0b028-ba60-4f3a-99b9-fcc7692a7d98	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:30:19.312655+00	2026-02-13 00:30:19.312655+00
259c2c09-c2d4-473b-ad00-d2a3183382f7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:30:29.139586+00	2026-02-13 00:30:29.139586+00
26c30d2a-518d-4112-84b5-b4b7cf701861	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:30:51.295537+00	2026-02-13 00:30:51.295537+00
c55c533d-e3c3-48f3-a204-1267c2c72080	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:31.060377+00	2026-02-13 00:34:31.060377+00
0230f027-dba2-41cc-bb35-b6f3e2519db4	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:34:31.763437+00	2026-02-13 00:34:31.763437+00
9e9e565b-ebac-4703-b6b0-ec7d735e1ad2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:34:32.889763+00	2026-02-13 00:34:32.889763+00
d1b0e17e-0d2f-4c0d-b7ad-37ed20d18f35	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:34:33.51284+00	2026-02-13 00:34:33.51284+00
a1541f5b-cf45-4771-ad74-8145e982e1c0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:34:34.605912+00	2026-02-13 00:34:34.605912+00
4afebf9f-5956-478f-8ad9-e2a2b6a1d5a9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:34:35.409533+00	2026-02-13 00:34:35.409533+00
8c6ae0d1-ea49-4eea-bbe9-183d3c9dba22	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:34:36.793936+00	2026-02-13 00:34:36.793936+00
047a116d-68c9-4069-9d25-bd17bb003ed8	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:34:38.072565+00	2026-02-13 00:34:38.072565+00
60ec9ea0-510f-4796-ac11-bd767a502014	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:34:50.427085+00	2026-02-13 00:34:50.427085+00
9225d8ff-a3da-4376-a7e7-cb22a589bc5f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:34:51.783511+00	2026-02-13 00:34:51.783511+00
b711bd8c-793f-47c0-9a10-3ca4817253aa	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:34:53.067638+00	2026-02-13 00:34:53.067638+00
d5179906-83ee-489d-ba07-496d45a661b2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:34:54.876374+00	2026-02-13 00:34:54.876374+00
a63a502c-44fb-4d85-9d1b-a4142a9e0c37	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:34:56.482056+00	2026-02-13 00:34:56.482056+00
0a9ac356-df7d-49c6-b0ae-88e24e48fe89	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:00.046952+00	2026-02-13 00:35:00.046952+00
fda004b0-fbd1-493b-834b-3f60a3902bd3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:00.240773+00	2026-02-13 00:35:00.240773+00
66a35a2d-0c86-4c40-8893-c30e777a725e	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:35:00.421149+00	2026-02-13 00:35:00.421149+00
d9741c22-f27b-4a70-b555-b92e1799c933	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:00.651299+00	2026-02-13 00:35:00.651299+00
70312120-cd66-4c3d-9a05-93fcc877234a	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:35:00.831057+00	2026-02-13 00:35:00.831057+00
e9fe2ed3-0595-4a65-af5f-b2412c01ee19	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:01.426972+00	2026-02-13 00:35:01.426972+00
b101bca4-773a-4988-acd7-25a5646f8cb4	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:35:02.2624+00	2026-02-13 00:35:02.2624+00
9407395e-e74b-44d8-bb6b-12eb7ec8188f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:03.965237+00	2026-02-13 00:35:03.965237+00
ef94df4c-0432-49fe-91be-d258329a1575	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:04.758412+00	2026-02-13 00:35:04.758412+00
8913d408-6b1b-4eb6-b9f8-3cba518b76b8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:05.390256+00	2026-02-13 00:35:05.390256+00
c98e43b8-fd6a-414a-b801-886711aedea5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:06.365514+00	2026-02-13 00:35:06.365514+00
6fb7863e-7967-4963-bf30-abe4232be76b	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:35:07.217154+00	2026-02-13 00:35:07.217154+00
83d1b462-ecf6-44eb-9788-934e42d26fd6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:35:07.836081+00	2026-02-13 00:35:07.836081+00
1b5b2d2b-1d6f-4360-b3d8-8f3e53c83d5a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:08.732683+00	2026-02-13 00:35:08.732683+00
420476a9-b88a-4e77-92f4-d86c47790b64	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:09.602797+00	2026-02-13 00:35:09.602797+00
26c6b484-c126-4bb5-9cf3-9ad022a5be44	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:35:11.479436+00	2026-02-13 00:35:11.479436+00
a610711c-5cb7-4efa-b850-34b7a02b2e70	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:35:16.086211+00	2026-02-13 00:35:16.086211+00
3eb44217-60e9-45ae-a7ee-05da727243c1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:22.071696+00	2026-02-13 00:35:22.071696+00
1aff5b4b-756f-4d09-9bc7-dc33bf554024	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 05:53:03.661391+00	2026-02-13 05:53:03.661391+00
a5b2b3f2-a741-4d31-83d4-90e2b97529c6	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_another"}	2026-02-13 00:35:22.790865+00	2026-02-13 00:35:22.790865+00
16785e63-ec2e-4a0e-8786-153352b90930	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:31.18892+00	2026-02-13 00:35:31.18892+00
18a4fe1a-4176-43e2-91dc-7dc94ee170ef	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:36:32.433705+00	2026-02-13 00:36:32.433705+00
35c9fa9f-33a1-4e60-82dc-26face7863ac	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:36:33.603248+00	2026-02-13 00:36:33.603248+00
543dbbde-d2ad-498f-8fbe-d5f3a57809ff	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:36:34.117206+00	2026-02-13 00:36:34.117206+00
25a463c9-85ea-494a-acd8-13ba1949bdb0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:36:34.953228+00	2026-02-13 00:36:34.953228+00
c82b851e-2be4-4ea1-9159-f595bb8d0eb8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:36:36.026266+00	2026-02-13 00:36:36.026266+00
dfc373a3-0784-4631-ab90-2ccebd32ce69	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:36:36.811+00	2026-02-13 00:36:36.811+00
7e2c44ca-268f-4478-b269-bde56e3f26c5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-14 23:05:48.824764+00	2026-02-14 23:05:48.824764+00
fd227f6a-a6d3-46e9-9b1b-c71ce21653bc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:36:38.668616+00	2026-02-13 00:36:38.668616+00
8b4c32d9-4ed3-46cf-97eb-e6766003ac94	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:49.325525+00	2026-02-14 23:05:49.325525+00
ce03b285-cd87-4c02-892c-70f3146b073c	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:36:38.066358+00	2026-02-13 00:36:38.066358+00
92c27dca-305b-49c6-837e-b7114aa03bac	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:36:39.275564+00	2026-02-13 00:36:39.275564+00
e9ecfa22-e40d-4b9e-ab89-a77cea2d4fb3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-14 23:05:49.674371+00	2026-02-14 23:05:49.674371+00
5ff1d65d-3013-4a8e-8355-6866d90e8d2a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:50.141479+00	2026-02-14 23:05:50.141479+00
c1a0a7eb-6022-40a0-ab8b-40ed114173b0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:50.600273+00	2026-02-14 23:05:50.600273+00
001029cb-aa09-415d-b882-db49abc36c9d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:51.4971+00	2026-02-14 23:05:51.4971+00
32980617-3597-4edb-a0b7-53b6d3ce2d57	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:52.513095+00	2026-02-14 23:05:52.513095+00
55f9b99b-dec9-4bdf-b990-cd43aaf413a6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:52.96052+00	2026-02-14 23:05:52.96052+00
b7979271-acc6-492e-8d04-ed2827bc5e8a	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:53.421648+00	2026-02-14 23:05:53.421648+00
afa51aa5-5cad-4170-847f-b2498dc158d8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-14 23:06:07.413231+00	2026-02-14 23:06:07.413231+00
5bb160e3-04d0-4bb0-b054-8641eba1fc61	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-14 23:06:09.054457+00	2026-02-14 23:06:09.054457+00
90091e8c-3433-4ced-94c0-611550eb58d3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-14 23:06:17.082321+00	2026-02-14 23:06:17.082321+00
529665c5-c042-4c6d-8cae-aa32ff99664c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-14 23:06:18.822411+00	2026-02-14 23:06:18.822411+00
f0f48785-5ec6-4576-962b-866f69469d6a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-14 23:06:20.186598+00	2026-02-14 23:06:20.186598+00
992dc8eb-d128-40e5-867d-7fe9dda20f94	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:01.600924+00	2026-02-13 00:35:01.600924+00
35d9a67d-862b-42d5-acee-bafb4e084942	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:35:02.56651+00	2026-02-13 00:35:02.56651+00
b169c34a-cac5-49c8-adc0-61fd1060f0e6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:03.323709+00	2026-02-13 00:35:03.323709+00
2339834f-348a-4843-bc4c-c73fe1730668	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:04.139206+00	2026-02-13 00:35:04.139206+00
6a62b5d1-680e-48c1-b7fa-bc0c100699a0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:04.929566+00	2026-02-13 00:35:04.929566+00
1172327b-a76f-453d-9a83-74d502b46ecd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:05.555784+00	2026-02-13 00:35:05.555784+00
cb593522-0029-470e-864e-7b4afefc39d5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:06.555874+00	2026-02-13 00:35:06.555874+00
b9d2cae2-289c-4eec-8091-61077141d899	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:35:07.539986+00	2026-02-13 00:35:07.539986+00
42ce63a7-4ecd-4515-bcba-5a4c6ab74f39	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:07.859804+00	2026-02-13 00:35:07.859804+00
ad218a1f-73a1-4f49-8a1b-7aadca9f11a0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:09.066585+00	2026-02-13 00:35:09.066585+00
73f012ec-ab03-4cd4-a48a-5e108489f851	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:35:09.771977+00	2026-02-13 00:35:09.771977+00
8a506e40-533d-4fb2-8474-1f7213b599c5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:11.01321+00	2026-02-13 00:35:11.01321+00
5fdb2dd1-294c-4db4-9739-96c289e4dd5f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:11.65343+00	2026-02-13 00:35:11.65343+00
62733026-b535-45e8-aaa3-f0847c7151c5	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:35:13.307349+00	2026-02-13 00:35:13.307349+00
f6467fef-0876-431e-a27e-dd83417652b5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:15.290387+00	2026-02-13 00:35:15.290387+00
5dba1efc-0a57-4a3f-9476-bffa551047db	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:21.219716+00	2026-02-13 00:35:21.219716+00
f4918c95-c2b5-45b4-94c2-cbb18163a385	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:22.963002+00	2026-02-13 00:35:22.963002+00
839bb99b-0997-4f02-815d-11469338ca70	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:25.088871+00	2026-02-13 00:35:25.088871+00
8770c053-5f88-4d89-98bd-2b11f5cec37a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 05:54:15.325963+00	2026-02-13 05:54:15.325963+00
3ef8aa4b-7fe9-471a-97bd-aa5d061a3bb5	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:36:18.521124+00	2026-02-13 00:36:18.521124+00
1d2db44b-8865-465e-8488-f90f5fbbf0a8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:36:32.240161+00	2026-02-13 00:36:32.240161+00
efbdcd0a-a5c4-4acc-a79e-433031344b26	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:36:32.963018+00	2026-02-13 00:36:32.963018+00
437db0ec-343a-4c06-8aab-ab231272b956	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:36:34.683671+00	2026-02-13 00:36:34.683671+00
ecde0d38-cf29-4bee-891a-cdb321cf1c6f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:36:35.742353+00	2026-02-13 00:36:35.742353+00
8c9dcf63-3895-4716-b0ff-88842b63c373	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:36:36.538183+00	2026-02-13 00:36:36.538183+00
c0c12332-1551-434a-9e8c-64615c5afa24	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:36:37.888809+00	2026-02-13 00:36:37.888809+00
72804f95-24c8-4921-9e55-4354a5a40205	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:36:39.154139+00	2026-02-13 00:36:39.154139+00
5a091934-dffb-4770-90a1-26f410c1b1cf	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:54.222442+00	2026-02-14 23:05:54.222442+00
9bcec4c4-c3a0-45c5-a040-7f7bcc2015c3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:57.540704+00	2026-02-14 23:05:57.540704+00
df1d73a1-7a76-4740-b047-df786ebf9375	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-14 23:05:59.704114+00	2026-02-14 23:05:59.704114+00
4b2367bb-f5e9-4e2c-bd32-e673e71bf61b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-14 23:06:11.625908+00	2026-02-14 23:06:11.625908+00
f419dfed-84e5-4afd-b240-17bbe70d309c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-14 23:06:13.242603+00	2026-02-14 23:06:13.242603+00
6ffe155e-f484-4cb4-b4f7-f809313e222b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-14 23:06:29.282141+00	2026-02-14 23:06:29.282141+00
cd08caac-cffc-4e2d-9573-bd516aaa8a53	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:01.774046+00	2026-02-13 00:35:01.774046+00
8495a5aa-8031-4b8c-8765-d08691ff9494	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:35:02.577804+00	2026-02-13 00:35:02.577804+00
e5dfba8d-ae21-40a4-bc97-f5d6009a284b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:03.496035+00	2026-02-13 00:35:03.496035+00
e687d66f-b7ba-49c9-a121-ff906d63efe4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:04.311448+00	2026-02-13 00:35:04.311448+00
3cec6c35-0fff-4030-8830-c862abb78752	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:05.112831+00	2026-02-13 00:35:05.112831+00
e3baa423-cd37-4124-825f-237dc80f907b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:06.73132+00	2026-02-13 00:35:06.73132+00
7a1790ed-f5d4-40f7-b7aa-013d2b3220cf	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:35:07.551934+00	2026-02-13 00:35:07.551934+00
44a51ac2-41ae-4ee2-8ff0-049e588f7af6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:08.363468+00	2026-02-13 00:35:08.363468+00
f341b05e-ae8a-4612-b076-efec1d5e837b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:09.244735+00	2026-02-13 00:35:09.244735+00
04ead09b-f2d0-42e4-9d4f-a54cd16732df	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:09.892152+00	2026-02-13 00:35:09.892152+00
65c5a21e-3213-43b6-8ee0-0dbc113660b0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 05:57:17.724638+00	2026-02-13 05:57:17.724638+00
458a3cb8-e629-4bd7-ae19-23852300624e	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:35:11.195443+00	2026-02-13 00:35:11.195443+00
ab063c25-ac87-4358-a91c-80facf3e3841	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 05:58:36.794218+00	2026-02-13 05:58:36.794218+00
5abbcda1-0e61-4ad6-818a-0a0967d6dc41	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:35:11.844776+00	2026-02-13 00:35:11.844776+00
ff106fe8-3465-4058-a1f7-149ae045b244	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:13.783918+00	2026-02-13 00:35:13.783918+00
2ca68657-8a5e-404c-a5b1-7f44d988f591	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-14 23:06:10.364321+00	2026-02-14 23:06:10.364321+00
2fce774b-8ed5-4e6a-822b-7b3c7dbd8800	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:35:15.481262+00	2026-02-13 00:35:15.481262+00
16a6736e-91e0-4a5a-9d6a-246ad059b1ba	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:17.608112+00	2026-02-13 00:35:17.608112+00
6537c257-24a5-4eeb-a51e-13fda187c98f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:22.606016+00	2026-02-13 00:35:22.606016+00
327d9c7b-59b3-4b1b-9c64-3cccefa0f61e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-14 23:06:14.82521+00	2026-02-14 23:06:14.82521+00
14329047-68b8-4805-90b3-95207d9926f3	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_another"}	2026-02-13 00:35:25.276548+00	2026-02-13 00:35:25.276548+00
d642160f-873a-4040-8343-a2ad9b6ab4d4	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:35:29.081286+00	2026-02-13 00:35:29.081286+00
f1e925b7-40ad-4aca-b51c-f47fcf2ef75a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:32.001638+00	2026-02-13 00:35:32.001638+00
7f149d48-7dc9-405d-aea5-5ec6427c9ea8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:36:18.329317+00	2026-02-13 00:36:18.329317+00
3febd28e-e389-406f-beaf-c928e82f835c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:36:32.780399+00	2026-02-13 00:36:32.780399+00
efc5754b-e9ad-4fa2-bc50-fa23cf8b64db	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:36:33.946891+00	2026-02-13 00:36:33.946891+00
39013521-7427-43e8-98f4-39afd2c4bec6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:36:34.673534+00	2026-02-13 00:36:34.673534+00
2fa03e96-1d05-46ff-bf07-eb1ba8af8df8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:36:35.5719+00	2026-02-13 00:36:35.5719+00
cc018b3b-b87c-4aa5-813f-ac68b542448e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:36:36.367329+00	2026-02-13 00:36:36.367329+00
6be5a162-809e-46d0-ba1e-eaddebb20205	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-14 23:06:24.001158+00	2026-02-14 23:06:24.001158+00
260e986d-2817-498a-a60f-4a9ea41fe18c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:36:38.979923+00	2026-02-13 00:36:38.979923+00
e7424a0d-8880-418c-878f-a7043d355a7c	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:36:38.359587+00	2026-02-13 00:36:38.359587+00
9b7b71a1-eeee-4f97-a379-fc6c28927776	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-14 23:06:27.084618+00	2026-02-14 23:06:27.084618+00
6ffe48d0-bfed-400a-b7b2-e8e456c044bd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:01.947389+00	2026-02-13 00:35:01.947389+00
114710cc-254d-450d-9976-d2ae66ed5946	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:02.869163+00	2026-02-13 00:35:02.869163+00
a5e8b18a-6cd3-4ba7-ab7c-40a82e4fa7d4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:03.667496+00	2026-02-13 00:35:03.667496+00
11ba9325-07f1-445e-9529-90b057d69957	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:04.482085+00	2026-02-13 00:35:04.482085+00
2ed1bb90-2050-4d28-8e9e-ba70f068afe6	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:35:05.298028+00	2026-02-13 00:35:05.298028+00
59a88188-062a-4174-8e2b-82ebd4d67948	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:35:05.741356+00	2026-02-13 00:35:05.741356+00
0f804c8e-0ba1-4ac6-acf4-486f9ef78c00	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:06.912129+00	2026-02-13 00:35:06.912129+00
72d9b4c7-5f9b-411b-8e43-1c5580e34819	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:08.549605+00	2026-02-13 00:35:08.549605+00
039f0c21-c324-4760-a2df-462e9cb0cfb3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:35:09.424879+00	2026-02-13 00:35:09.424879+00
1f93f62c-8c7b-4625-8cda-63ba8dc9ae06	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:10.39517+00	2026-02-13 00:35:10.39517+00
5237a589-fcf3-4e5d-b009-7f87a2303777	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	python-requests/2.32.5	success	{}	2026-02-13 06:00:35.801187+00	2026-02-13 06:00:35.801187+00
d4c66ed9-93a7-4730-bd52-25af4ac457a3	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_another"}	2026-02-13 00:35:13.963451+00	2026-02-13 00:35:13.963451+00
6555fc32-f81c-4e04-a122-750da4953591	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-14 23:06:25.687441+00	2026-02-14 23:06:25.687441+00
824b82ea-b491-4a7a-af85-fa1678f2f632	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:35:17.794692+00	2026-02-13 00:35:17.794692+00
1d4a4514-52b3-4a7d-966d-271b2a5bf872	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "4719409e8cf1cb18"}	2026-02-13 00:35:27.306548+00	2026-02-13 00:35:27.306548+00
c8dc73a1-eb61-41e6-900d-14d1c7668602	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:35:32.692841+00	2026-02-13 00:35:32.692841+00
df9ba6aa-deb2-4c60-bf15-1bac1fabec43	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:36:32.613189+00	2026-02-13 00:36:32.613189+00
3bb5ab72-4ab8-4d8e-983e-ec511d5298f0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:36:33.775478+00	2026-02-13 00:36:33.775478+00
68650759-08da-4b10-8862-d0100db3ed73	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:36:34.408817+00	2026-02-13 00:36:34.408817+00
0065a1c8-8ce9-4574-9f29-e4b22a833903	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:36:35.402254+00	2026-02-13 00:36:35.402254+00
4919a7d0-1095-4fd1-ae0d-56e312aa184a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:36:36.19628+00	2026-02-13 00:36:36.19628+00
efb7bf25-b2e2-4bf7-bd09-2c4ca1a8eb51	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:36:37.250057+00	2026-02-13 00:36:37.250057+00
d97583ff-d287-44e8-b5d9-875ce4b44680	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:36:38.838622+00	2026-02-13 00:36:38.838622+00
971d7435-853d-41d3-823e-c8039620548b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:33.510613+00	2026-02-13 00:37:33.510613+00
499fde9d-a338-4ad1-a3a9-e97ed80cb8b4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:33.704905+00	2026-02-13 00:37:33.704905+00
3986021d-7492-42e0-be0a-e1055e8e068a	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:37:33.890995+00	2026-02-13 00:37:33.890995+00
9998b795-42ce-42ad-9ad8-f22f1989bf49	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:34.032563+00	2026-02-13 00:37:34.032563+00
1356cb40-1eba-4e4b-ac02-2e508502e529	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:37:34.215047+00	2026-02-13 00:37:34.215047+00
ed8e49d9-cf39-4d7f-88f2-3caf6c7c8d49	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:34.79527+00	2026-02-13 00:37:34.79527+00
4ea4d7b4-9d0c-4e9f-9d0a-76fb9f51f56e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:34.976606+00	2026-02-13 00:37:34.976606+00
9e8882a1-d95e-43e4-b275-1ee1f90e5c2f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:35.160825+00	2026-02-13 00:37:35.160825+00
6fc789fb-5919-4ea3-8478-6a70fec6b92d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:35.347869+00	2026-02-13 00:37:35.347869+00
46292c4b-43ba-4026-b784-085a57153c49	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:37:35.653626+00	2026-02-13 00:37:35.653626+00
595efd48-0ffb-42e2-9287-e997653c245c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:37:35.970084+00	2026-02-13 00:37:35.970084+00
81ef352a-2002-4674-84d2-a4340416b5df	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:37:35.978882+00	2026-02-13 00:37:35.978882+00
0d202632-c87b-4ced-9b66-aeb477eeda03	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:36.29295+00	2026-02-13 00:37:36.29295+00
98edd070-6a50-4647-a33e-c3c6d64a9f11	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:36.755379+00	2026-02-13 00:37:36.755379+00
6c44bd0a-d93c-4084-a5ee-390db72babd2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:36.933317+00	2026-02-13 00:37:36.933317+00
dd9d02ca-1269-4803-ab0c-580cd2edcf5b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:37.451039+00	2026-02-13 00:37:37.451039+00
142a4682-d59d-4a6a-8445-52c95a277f75	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:37.116713+00	2026-02-13 00:37:37.116713+00
d6703067-2fe0-4394-bb06-27d1e230ec24	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:38.000667+00	2026-02-13 00:37:38.000667+00
983882cf-9d17-4ec9-b951-2991a677a486	eb8f2199-7903-409d-8999-1e450e3c90b8	login_failed	\N	172.23.0.1	curl/8.17.0	failure	{"reason": "invalid_password"}	2026-02-13 23:21:33.416649+00	2026-02-13 23:21:33.416649+00
e3d8dfb4-08e1-451e-affe-9897b4487882	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:37:40.74786+00	2026-02-13 00:37:40.74786+00
e0c9206e-b253-42cb-9284-7dab7a81762d	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:39.948288+00	2026-02-13 00:37:39.948288+00
d4c25caf-e13c-4a21-869e-4d708bcbb46e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:44.54353+00	2026-02-13 00:37:44.54353+00
c5adb984-db62-4e5a-8556-95a06e2e7141	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:45.659517+00	2026-02-13 00:37:45.659517+00
ee2f1c5f-a7b0-4d6c-8709-b285a99f8042	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:37:46.46809+00	2026-02-13 00:37:46.46809+00
d07fd158-32bd-4248-aba1-4fbde8604cc1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:47.500666+00	2026-02-13 00:37:47.500666+00
7247dabe-95f4-4e7e-8c29-606b4753941b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:48.949889+00	2026-02-13 00:37:48.949889+00
f11e1148-e8d3-4c0d-8cc7-665901d3a820	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-13 23:26:03.594817+00	2026-02-13 23:26:03.594817+00
9516e288-7310-4877-a9d8-f60a38fe1741	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:37:51.578055+00	2026-02-13 00:37:51.578055+00
9d0a8aad-c5a0-42dd-9ad8-546df3a183af	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:37:50.512055+00	2026-02-13 00:37:50.512055+00
c8fbc43f-4a63-4e91-b525-387154bd8246	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:53.841275+00	2026-02-13 00:37:53.841275+00
256e5f31-7250-4fed-ac54-321cac44818a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:06.075593+00	2026-02-13 00:38:06.075593+00
03b3deb6-b6d0-4d48-bf13-02187554e51f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:15.243878+00	2026-02-13 00:38:15.243878+00
20b89b62-2d8b-4bf7-9bbc-3f55384abf22	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:16.212035+00	2026-02-13 00:38:16.212035+00
c0b72098-7210-48d4-9a97-f56229db8df5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:16.947884+00	2026-02-13 00:38:16.947884+00
ac18a5f5-1e4a-46f4-b10f-13913a23b54f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:17.831424+00	2026-02-13 00:38:17.831424+00
b9b64666-3543-4b19-9695-305d47d2b788	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:18.624387+00	2026-02-13 00:38:18.624387+00
906b273e-2526-47c0-8dd0-521eb6c97b50	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:19.45394+00	2026-02-13 00:38:19.45394+00
e2069b40-b156-4b15-91fc-2c90780e55d7	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-14 23:17:20.603634+00	2026-02-14 23:17:20.603634+00
77dfa525-4f90-4f44-aae4-5e892bf9d840	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:22.694454+00	2026-02-13 00:38:22.694454+00
292d12a9-200f-4a30-a572-f548c545b11d	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 23:18:55.599626+00	2026-02-14 23:18:55.599626+00
20da40bb-d807-4096-8c48-2b2b3e5eb59d	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:22.088247+00	2026-02-13 00:38:22.088247+00
7603c7dc-7662-4dd2-8b7f-2c0931e93326	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:23.574119+00	2026-02-13 00:38:23.574119+00
39da909a-8906-48cf-bf20-b07e8d56d00e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:25.240269+00	2026-02-13 00:38:25.240269+00
3e816004-bf4b-46ee-9b08-a5990282b276	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:26.136341+00	2026-02-13 00:38:26.136341+00
01c5f9fe-196a-4f6a-99c8-0e979c1ec19a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:29.289819+00	2026-02-13 00:38:29.289819+00
6685c904-3e61-4bfe-91cf-47f890caa293	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:38:40.422584+00	2026-02-13 00:38:40.422584+00
498effa5-23fb-4952-bfc4-4c2917c177c4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:45.898344+00	2026-02-13 00:38:45.898344+00
3fb52ac6-f48f-48e6-ae53-f8ddc1e588e7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:47.174504+00	2026-02-13 00:38:47.174504+00
1ad54daf-7a2a-44df-bf74-efee23b08ec7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:51.426856+00	2026-02-13 00:38:51.426856+00
ff7e33b7-e187-4feb-b7ad-3ccdfef2f7f4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:55.238135+00	2026-02-13 00:38:55.238135+00
0b073449-c358-45d1-8f3c-64c6f2165220	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:56.231632+00	2026-02-13 00:38:56.231632+00
db901f13-aaad-455f-bd61-3bd0780401d6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:57.415132+00	2026-02-13 00:38:57.415132+00
52095b51-c7c9-4feb-a472-28d6820af73a	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:39:00.028588+00	2026-02-13 00:39:00.028588+00
2091ad50-8ac0-4f48-ab2b-280c62c663c3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:39:02.928371+00	2026-02-13 00:39:02.928371+00
8d226ec1-9a73-4ece-bdba-725a0923e7f3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:37.641665+00	2026-02-13 00:37:37.641665+00
243673ca-44fb-4657-9eee-78b6950f83c4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:38.774979+00	2026-02-13 00:37:38.774979+00
626694c9-7456-4506-8c07-44f1cc7b7e22	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 23:29:50.588149+00	2026-02-13 23:29:50.588149+00
0dc35685-3bfa-4343-b449-fe2c3b8d3f6e	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:37:40.428571+00	2026-02-13 00:37:40.428571+00
5ad4e69e-7f67-455e-adcf-35f6514115bd	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:37:39.636715+00	2026-02-13 00:37:39.636715+00
3187f5aa-5389-4c7b-8884-ab05d8a0ea3c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:44.874738+00	2026-02-13 00:37:44.874738+00
44c83308-ca09-4ba8-bdde-8d1e197171f9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:46.00198+00	2026-02-13 00:37:46.00198+00
180b0e03-53a5-4520-a75f-62626334311d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:37:46.759524+00	2026-02-13 00:37:46.759524+00
33d29262-b8bb-43b8-a7c1-370711035ef5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:47.83789+00	2026-02-13 00:37:47.83789+00
401a97ea-c994-4498-b1be-4399a23e5b1c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:48.47541+00	2026-02-13 00:37:48.47541+00
40b36f64-7f10-44b3-80c4-3bf04bdf2627	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-13 23:31:59.25526+00	2026-02-13 23:31:59.25526+00
93111d4e-3bf0-4514-bbe8-dcb30956d311	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:37:52.005001+00	2026-02-13 00:37:52.005001+00
79cc10d4-3e02-44c6-82a7-2c6733236c15	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:50.961958+00	2026-02-13 00:37:50.961958+00
de047f7c-114f-4804-b95b-91fe161df3cd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:54.525391+00	2026-02-13 00:37:54.525391+00
9410adcd-e642-44f8-96de-56996ef25244	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:00.109171+00	2026-02-13 00:38:00.109171+00
f3f83bdc-cbfa-433f-aa88-0649303fb3f7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:07.384473+00	2026-02-13 00:38:07.384473+00
cc3c5de3-269e-41c1-b6f6-d008dacfa95c	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:38:15.435203+00	2026-02-13 00:38:15.435203+00
cdd4d90c-eb75-4d5e-a414-4f25bbfd2fcb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:16.381616+00	2026-02-13 00:38:16.381616+00
b2a44a72-0d73-4ce0-b094-b314f696f9b5	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:38:17.243736+00	2026-02-13 00:38:17.243736+00
5a90f3cc-7eb4-4190-9921-127bb1de584f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:18.282988+00	2026-02-13 00:38:18.282988+00
993bb34b-83ed-4d67-88fd-42c8e5094e7a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:19.098346+00	2026-02-13 00:38:19.098346+00
52b8e142-ce09-4fd9-ba6f-670d5db0edeb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:20.260324+00	2026-02-13 00:38:20.260324+00
f9336931-7d4b-4871-907f-59977fed051d	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-14 00:04:56.499571+00	2026-02-14 00:04:56.499571+00
8c537684-dd8d-4cf7-a3a1-575cb2dcdb9e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:23.131011+00	2026-02-13 00:38:23.131011+00
874f44ed-ba5b-4fce-9c77-07a15e7ba7f2	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:38:21.617481+00	2026-02-13 00:38:21.617481+00
9d9bb8d3-644c-4093-a552-40a4141f7e1e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:31.253561+00	2026-02-13 00:38:31.253561+00
ae17d8e8-622c-4d50-85d9-f6a24df54c80	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:45.709441+00	2026-02-13 00:38:45.709441+00
7975e4ad-aa82-45de-b580-e070fa279010	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:38:46.594708+00	2026-02-13 00:38:46.594708+00
fb64610a-6c45-453a-93a7-b4168641da48	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:48.469878+00	2026-02-13 00:38:48.469878+00
92591c8f-f924-4246-881c-d3fcb25a4e9e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:51.084123+00	2026-02-13 00:38:51.084123+00
46f18329-66ec-4264-8890-4e191ff9da49	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:55.584264+00	2026-02-13 00:38:55.584264+00
4c4fc8e4-c250-434a-bbc1-56b5e0948b3d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:56.565131+00	2026-02-13 00:38:56.565131+00
4403d1ca-fc36-4f20-bc85-7044fe74f004	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:59.426249+00	2026-02-13 00:38:59.426249+00
2e17e73a-cbc2-40cd-b5b7-41f81d264038	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-15 00:12:19.820615+00	2026-02-15 00:12:19.820615+00
476b43b5-5dee-4910-a53a-6d319be893a4	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:39:00.451769+00	2026-02-13 00:39:00.451769+00
b21cfedb-801b-4cac-ab5e-bcb5edcbf288	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:39:02.018494+00	2026-02-13 00:39:02.018494+00
f30e15f3-b938-4480-899e-bc0047dc944f	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-15 00:14:06.493925+00	2026-02-15 00:14:06.493925+00
1129b07f-5acb-4d0c-8192-227863f9eb59	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-15 00:17:04.565995+00	2026-02-15 00:17:04.565995+00
1ef665c1-0dfb-40f6-b372-9f84276e642c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:37.82132+00	2026-02-13 00:37:37.82132+00
a625fd02-e882-4d45-9695-5a876a8ad3ce	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:40.575058+00	2026-02-13 00:37:40.575058+00
658c14d3-c160-4bc4-93c2-d8ff9d5d9f98	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:44.350891+00	2026-02-13 00:37:44.350891+00
cae43f41-5cd3-4a05-bdc9-14f49b0bf7cf	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:37:45.054618+00	2026-02-13 00:37:45.054618+00
530d7b23-21a1-4e35-9499-c9c25b37bc1c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:46.17373+00	2026-02-13 00:37:46.17373+00
3e3f25ef-a6f5-4faa-a3a2-4b9bd4e918c0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:47.051025+00	2026-02-13 00:37:47.051025+00
5668f99d-fc14-4480-be3d-610f773bfd76	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:48.131905+00	2026-02-13 00:37:48.131905+00
9dca11d2-6007-471d-a54d-86f626c11c34	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:48.644944+00	2026-02-13 00:37:48.644944+00
5342b34b-ebad-45ed-8934-5fe762865728	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:50.335664+00	2026-02-13 00:37:50.335664+00
edb63c8c-b254-4139-a0ac-d4e3458aced9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:51.405839+00	2026-02-13 00:37:51.405839+00
84e65846-ad2c-4b82-a7d2-78bb6c66b0d1	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-14 00:59:45.066078+00	2026-02-14 00:59:45.066078+00
5d5c0d5c-b4d6-4578-8a28-a9174ffb19a1	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:52.280351+00	2026-02-13 00:37:52.280351+00
4b0c6637-a5aa-4bef-9e84-c0702f40dad6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:38:01.655188+00	2026-02-13 00:38:01.655188+00
94f42192-63e0-4c92-ba98-38c803582c9a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:38:09.116602+00	2026-02-13 00:38:09.116602+00
0fe25088-4cb9-4e64-ad42-287a2c3f4b92	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:13.076935+00	2026-02-13 00:38:13.076935+00
08ac6333-f555-4083-adee-2a570c1a6d0b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:15.039926+00	2026-02-13 00:38:15.039926+00
d9ccb1c6-e36a-459f-8e4a-802141e6edbf	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:38:15.767459+00	2026-02-13 00:38:15.767459+00
4d433e88-321a-4d74-83e3-ad94419aaef6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:16.7636+00	2026-02-13 00:38:16.7636+00
7f9fb671-0d7e-456a-88d8-138e6fe2d415	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:38:17.549542+00	2026-02-13 00:38:17.549542+00
50cfab8e-eae5-47b0-99f3-40f332a9739b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:18.455039+00	2026-02-13 00:38:18.455039+00
7114e430-00a8-4eae-ba2e-88187a967853	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:19.274733+00	2026-02-13 00:38:19.274733+00
fc465be7-8e32-4cc8-ba46-1fd37ffe0d2c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:20.426343+00	2026-02-13 00:38:20.426343+00
597ba8ad-3e52-46f9-8ce6-50b8cd4d8eb2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:21.437347+00	2026-02-13 00:38:21.437347+00
76e00e7f-db33-4466-9647-a2dda9581b3f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:22.253567+00	2026-02-13 00:38:22.253567+00
eb006c4d-ca86-4bcc-8b99-d6d0f8a9aadf	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:38:22.867311+00	2026-02-13 00:38:22.867311+00
6969c862-171f-4bbb-b3b5-cdb55b74bf09	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:24.323416+00	2026-02-13 00:38:24.323416+00
891446fc-a6f8-4b53-9da0-f78f4c203254	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:25.407849+00	2026-02-13 00:38:25.407849+00
d1b25993-f342-4cc3-9483-73c741cf25c2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:38:33.074857+00	2026-02-13 00:38:33.074857+00
60df7b2d-df44-4105-b2cc-eb76439850eb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:46.406835+00	2026-02-13 00:38:46.406835+00
138c0d4f-be03-4ee8-8d72-799b5f69625f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:47.684284+00	2026-02-13 00:38:47.684284+00
16540498-d8c1-4f42-844c-1ddb1ffeb3be	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:48.156558+00	2026-02-13 00:38:48.156558+00
22bc6183-8d66-4201-8cba-2475e67d7e31	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:50.913009+00	2026-02-13 00:38:50.913009+00
3c14289f-772b-45ca-984f-39f41b5d48aa	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:52.137753+00	2026-02-13 00:38:52.137753+00
5e100a19-50f5-470e-9a97-9a6022e3ce49	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:55.885851+00	2026-02-13 00:38:55.885851+00
63c940cb-cb35-4b82-b6bc-235338da0a37	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:58.337013+00	2026-02-13 00:38:58.337013+00
67e4a95d-3646-440c-82c7-4b480ded2e6f	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:38:59.604159+00	2026-02-13 00:38:59.604159+00
f9d87a41-3b54-482d-87cb-b87f9d7f172f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:39:01.262731+00	2026-02-13 00:39:01.262731+00
2f1e47d4-6e1c-4c4d-a6e2-a23bd1eabdb7	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-15 00:25:16.423039+00	2026-02-15 00:25:16.423039+00
b0d8fca9-065d-4224-99a4-f6c2b25bb9ae	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-15 00:25:17.567666+00	2026-02-15 00:25:17.567666+00
47c43f78-0a1e-498c-ba5d-414fe5dc79ae	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:38.30619+00	2026-02-13 00:37:38.30619+00
1816ce78-5f1f-41cd-bd53-4e0b0b92546b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:39.459514+00	2026-02-13 00:37:39.459514+00
363a8634-c57c-4075-94f3-4f5a57482970	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:40.253703+00	2026-02-13 00:37:40.253703+00
3d8f3035-a550-44a9-9834-dff832990c07	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:40.886904+00	2026-02-13 00:37:40.886904+00
0bdb0c72-60b8-493e-b2bb-fbba18cc5458	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:37:44.722549+00	2026-02-13 00:37:44.722549+00
61df860a-7b2f-4723-a984-031d452f6290	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:45.828862+00	2026-02-13 00:37:45.828862+00
2e988405-3c0a-4cfb-9879-7024aa5fc920	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:37:46.750975+00	2026-02-13 00:37:46.750975+00
610e9e08-5351-4e6a-8c5d-0039842b402d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:47.67058+00	2026-02-13 00:37:47.67058+00
a7b7b0ca-bb31-4e89-8af9-7ba93dcfd0af	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:37:48.306625+00	2026-02-13 00:37:48.306625+00
7dc77abb-683d-42dd-8340-f6075f54878c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:49.408169+00	2026-02-13 00:37:49.408169+00
bc4e3572-14a7-4792-863f-3ede595dcbe3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:51.833703+00	2026-02-13 00:37:51.833703+00
0949fedc-6e63-4a24-a0e2-cae7566b4516	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:37:53.067833+00	2026-02-13 00:37:53.067833+00
45b3eb1e-94cd-4992-a49d-55b468ca6516	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:10.750046+00	2026-02-13 00:38:10.750046+00
e6c9c9ee-8632-41d8-91d3-dd784d822449	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:14.770256+00	2026-02-13 00:38:14.770256+00
e7b2f286-e133-49a3-9c7a-065b83427d6e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:15.581843+00	2026-02-13 00:38:15.581843+00
996326ae-df8d-4d6c-8255-b89bd2ef67bd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:16.573306+00	2026-02-13 00:38:16.573306+00
74077b1f-c55a-4e45-9fd1-3bda50312d09	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:38:17.539384+00	2026-02-13 00:38:17.539384+00
e7690604-0215-4f23-b874-3c952c156bd4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:18.919098+00	2026-02-13 00:38:18.919098+00
eb57c2a6-c8e5-4471-9937-96cc67017d17	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:19.760523+00	2026-02-13 00:38:19.760523+00
73f0c802-56d8-42aa-a667-a414cad76e93	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:38:23.303204+00	2026-02-13 00:38:23.303204+00
e8346958-3ca5-4746-8d6e-820ee0d88c10	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:31.431496+00	2026-02-13 00:38:31.431496+00
8b521307-7798-4040-ab22-c7eea282a919	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:34.549597+00	2026-02-13 00:38:34.549597+00
59af5804-9467-46bf-81a2-30353834d5b3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:38.7656+00	2026-02-13 00:38:38.7656+00
f9f96144-c934-40b2-ade7-1a407e65ca24	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:42.02362+00	2026-02-13 00:38:42.02362+00
74124a27-24c5-4580-a33c-b8172dcf0dce	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:44.364812+00	2026-02-13 00:38:44.364812+00
a7cc627b-6938-4695-a8b9-28ae344393ae	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:46.069722+00	2026-02-13 00:38:46.069722+00
2909c5f7-e964-479a-a01d-c02173f02966	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:38:46.247443+00	2026-02-13 00:38:46.247443+00
67b119db-28ba-4857-ac37-4373ad01240c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:47.349208+00	2026-02-13 00:38:47.349208+00
7a179e43-fad3-40c5-88eb-39c83e3beefa	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:47.517801+00	2026-02-13 00:38:47.517801+00
5ed4f9d2-a74a-40f5-814a-89738565e498	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:47.865432+00	2026-02-13 00:38:47.865432+00
e97fc314-f985-46db-9d42-c35222caa52b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:48.642994+00	2026-02-13 00:38:48.642994+00
70daa9b2-f996-4238-af2b-d5a35bf796c8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:50.737674+00	2026-02-13 00:38:50.737674+00
5260c671-0a49-4e22-b755-9b4be7776edd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:51.260348+00	2026-02-13 00:38:51.260348+00
358690ae-d8a8-4ed5-9218-5825c68a7c85	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:51.596281+00	2026-02-13 00:38:51.596281+00
1f905f73-7a81-4e03-aeb4-2e4688768d9e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:51.940165+00	2026-02-13 00:38:51.940165+00
1e22f4c4-dea4-4999-932a-3c1b0facf72f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:53.275725+00	2026-02-13 00:38:53.275725+00
e8ba227a-8cff-46cc-b7a8-da2d7269234c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:54.752551+00	2026-02-13 00:38:54.752551+00
b1287ed7-6b43-4b2e-8020-9fda35cbc0b6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:55.411675+00	2026-02-13 00:38:55.411675+00
1f6f7d9a-5f4b-4499-b617-36c71adf55c2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:38:56.05997+00	2026-02-13 00:38:56.05997+00
f8e80ca7-7cc6-47d3-9b17-c64c44d8d6c6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:56.899082+00	2026-02-13 00:38:56.899082+00
3cd05eac-ec1f-43ba-a363-d27a262a6f40	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-14 01:31:35.831975+00	2026-02-14 01:31:35.831975+00
c528857f-deff-480f-be44-ecf57d290d04	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:59.854528+00	2026-02-13 00:38:59.854528+00
0712b6c2-1d4a-4601-897c-931a5bb55972	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:38:58.513843+00	2026-02-13 00:38:58.513843+00
e7c55e22-93aa-4d2f-9b74-87bf28006e01	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:39:02.445892+00	2026-02-13 00:39:02.445892+00
efeb66cc-2237-4292-9fc2-12800c692850	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 01:33:50.21175+00	2026-02-14 01:33:50.21175+00
acaadbd0-554f-44d8-84b5-21a08a5d9233	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-15 18:09:11.507217+00	2026-02-15 18:09:11.507217+00
f6e0651c-cd53-4cd2-97f9-b73e3c96115a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:38:56.398422+00	2026-02-13 00:38:56.398422+00
e9b6d285-842f-46d7-aa38-fe71c51c8c9d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.1	curl/8.17.0	failure	{"reason": "invalid_password"}	2026-02-14 01:31:53.417864+00	2026-02-14 01:31:53.417864+00
14bff849-7cf6-4fbb-9b73-e7b55c4e39e8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:39:00.282618+00	2026-02-13 00:39:00.282618+00
cec8eeb7-3123-499f-8d13-7d84b292874b	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:38:58.950897+00	2026-02-13 00:38:58.950897+00
27355d38-71e9-47c5-8c65-c957922e4a42	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:41:12.694566+00	2026-02-13 00:41:12.694566+00
b44c8d43-1593-4fb2-9b0c-2021f32d1787	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:41:12.866317+00	2026-02-13 00:41:12.866317+00
de6468f8-5bc8-4c8f-96ef-2076fa799aa5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:41:13.036192+00	2026-02-13 00:41:13.036192+00
0e66c048-f6e4-44c5-90c2-a0c401229472	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:41:13.209227+00	2026-02-13 00:41:13.209227+00
f96641f3-5ba7-44c2-b691-f5b5d14f23e8	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:41:13.506945+00	2026-02-13 00:41:13.506945+00
1ea2bfa3-16c3-42e8-ba4b-c58b3cdfa91d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:41:13.797311+00	2026-02-13 00:41:13.797311+00
3f3eb767-0916-4815-9573-9c909aa0550e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:41:13.805254+00	2026-02-13 00:41:13.805254+00
e951a597-1cbd-47e3-bc29-9491b5b39939	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:41:14.093779+00	2026-02-13 00:41:14.093779+00
1494df50-ad59-4af1-b0e1-715ba4f1aa9d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:41:14.548637+00	2026-02-13 00:41:14.548637+00
3ddd8c6d-4ce4-41b6-b262-7b440722cc7a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:41:14.718687+00	2026-02-13 00:41:14.718687+00
2b426eb3-aada-49c9-92f5-31b5cfe1f2a4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:41:14.885836+00	2026-02-13 00:41:14.885836+00
14d2e0f2-5042-41e5-8fd8-cb04abfc5cf0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:41:15.166784+00	2026-02-13 00:41:15.166784+00
0d729b7f-e2e1-46de-a0c1-75828b9e9e24	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:41:15.342315+00	2026-02-13 00:41:15.342315+00
ec82c2e3-da24-47f9-9002-1a73912cc712	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:41:15.509269+00	2026-02-13 00:41:15.509269+00
5c4f30ca-6c95-4084-8788-124f7e0e4336	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:41:15.67796+00	2026-02-13 00:41:15.67796+00
2209280d-54af-4be4-8f21-918a66693aa6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:41:15.970465+00	2026-02-13 00:41:15.970465+00
327aec61-e37f-440a-8ada-af6b767a7569	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:05.702356+00	2026-02-13 00:42:05.702356+00
0f86c1d9-f453-4881-bf07-d32e27102cdb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:42:05.891298+00	2026-02-13 00:42:05.891298+00
07bd9ae1-c155-4057-9878-6ec9b2ed62a3	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:42:06.070742+00	2026-02-13 00:42:06.070742+00
82fbc65e-c35f-4d42-a28e-62f3a2a13cbc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:06.216858+00	2026-02-13 00:42:06.216858+00
db765c8b-c9f6-4307-bd9a-d41078522126	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:42:06.39488+00	2026-02-13 00:42:06.39488+00
54c24af4-e131-4330-a450-22aab3f90e30	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:42:07.253639+00	2026-02-13 00:42:07.253639+00
19ced775-be83-4fb5-aa8b-2aab6376008f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:42:07.55326+00	2026-02-13 00:42:07.55326+00
e731532c-9315-4a7d-a9ba-ecd6ab77f23a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:42:07.836394+00	2026-02-13 00:42:07.836394+00
2ea8b185-0ede-4c58-9898-79d3c3837fd3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:42:08.133002+00	2026-02-13 00:42:08.133002+00
96131787-6b12-4aa3-9b25-99244e8d3d09	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:42:08.432512+00	2026-02-13 00:42:08.432512+00
239b7cbe-319f-428c-80e7-137a3dff090a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:42:08.727421+00	2026-02-13 00:42:08.727421+00
a1197478-3deb-4404-aa00-7e3f26f104bb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:42:08.847515+00	2026-02-13 00:42:08.847515+00
46a27634-f853-406f-b0c3-9043c0beb92a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:09.254944+00	2026-02-13 00:42:09.254944+00
7250046d-4a69-48a8-bf72-6e89da897940	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:42:09.816699+00	2026-02-13 00:42:09.816699+00
cac0fa9c-f735-4575-810d-08435a563cb7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:42:09.985716+00	2026-02-13 00:42:09.985716+00
e81d129d-3618-475b-abcf-84431baf68c2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:42:10.153495+00	2026-02-13 00:42:10.153495+00
cc6685f3-ecbe-473f-b8d5-d5baf2aabc01	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:10.453977+00	2026-02-13 00:42:10.453977+00
b4708b77-8feb-4b1d-a413-0c8599268358	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:42:10.629615+00	2026-02-13 00:42:10.629615+00
823d274a-2dab-4fd0-bd10-3625982907dc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:42:10.798746+00	2026-02-13 00:42:10.798746+00
1ace35f8-cbb0-4727-9677-4bf5c539c6a4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:42:10.966468+00	2026-02-13 00:42:10.966468+00
80377a11-cecb-4092-a0d7-3e40142bdbcc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:11.255272+00	2026-02-13 00:42:11.255272+00
9e4ee6dc-2786-474b-8482-46be67cdd00f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:14.095771+00	2026-02-13 00:42:14.095771+00
0947f9c8-e72f-4f85-b5ce-c2019a4369c0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:42:22.053571+00	2026-02-13 00:42:22.053571+00
63e26c96-f9ba-4fe2-9156-37484a64af8a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:42:30.599605+00	2026-02-13 00:42:30.599605+00
bb9b34cf-7bc5-4c0e-b7de-039794f274dd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:42:41.649556+00	2026-02-13 00:42:41.649556+00
d3c63683-6d2e-408d-96b3-7d6e0628b598	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:05.090517+00	2026-02-13 00:43:05.090517+00
82f9e88b-a449-40be-ab1a-f51184234fb5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:43:06.654093+00	2026-02-13 00:43:06.654093+00
23b6e88d-4db1-4564-a9ac-7ed3a76f05dd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:43:08.091598+00	2026-02-13 00:43:08.091598+00
ace86702-0336-4a4b-8264-3bdde95ffa93	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:43:09.350244+00	2026-02-13 00:43:09.350244+00
44e9e446-a2b7-4257-a0a9-70aa96f168bf	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:43:10.282355+00	2026-02-13 00:43:10.282355+00
c4e03050-060f-412b-b25b-c4f0c56d4e98	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 01:34:09.663337+00	2026-02-14 01:34:09.663337+00
084f564d-802c-4a51-a5c6-4a1739a9ccdc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:13.424544+00	2026-02-13 00:43:13.424544+00
596357a3-fdad-424d-99cf-fbd2317ac5b2	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:43:12.126203+00	2026-02-13 00:43:12.126203+00
3a7d4f60-af9b-4205-a912-ec08ca779d09	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:43:23.236608+00	2026-02-13 00:43:23.236608+00
b9d2be96-52c0-4c05-9b0d-e567cba1b92a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:43:34.191141+00	2026-02-13 00:43:34.191141+00
2473bac8-e1e0-46ed-86f4-ac314e45bbe1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:43:37.222966+00	2026-02-13 00:43:37.222966+00
d8eb22d6-1f3e-46d0-84a2-8e8ff9148449	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:47:41.109333+00	2026-02-13 00:47:41.109333+00
85c7fa01-be8b-4a08-83e6-2b8b596e88e9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:47:42.716621+00	2026-02-13 00:47:42.716621+00
153a913f-a39e-4337-a9aa-1bab0b77534f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:47:43.854129+00	2026-02-13 00:47:43.854129+00
4c1abdaf-0551-416d-85a5-18d04d47814c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:47:45.32039+00	2026-02-13 00:47:45.32039+00
bf808589-7252-4de2-844f-83ce5e984d1b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:46.432152+00	2026-02-13 00:47:46.432152+00
b36a5ef8-eede-4840-91dd-13a1bc85adef	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (iPhone; CPU iPhone OS 26_2_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) EdgiOS/144.0.3719.115 Version/26.0 Mobile/15E148 Safari/604.1	success	{}	2026-02-15 19:52:30.321556+00	2026-02-15 19:52:30.321556+00
90be6711-44e6-4624-8b7f-0baebae8846b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:49.259224+00	2026-02-13 00:47:49.259224+00
26496593-1320-4e53-82ae-4ff9e5d91969	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:47:47.96632+00	2026-02-13 00:47:47.96632+00
955f110d-399f-4d66-a4fa-11bcd95e217e	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-16 15:21:44.162975+00	2026-02-16 15:21:44.162975+00
79df5e56-1ea8-43de-bce9-ee9d1cbd32c5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:11.741796+00	2026-02-13 00:42:11.741796+00
3a4fbb44-c297-4ed1-bdf3-5808354e89bb	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:42:14.267732+00	2026-02-13 00:42:14.267732+00
faa68a9d-bcaa-4df1-88cd-807104c32627	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:15.995441+00	2026-02-13 00:42:15.995441+00
b909b293-f781-457f-8730-9ee2dc6875b8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:42:36.435321+00	2026-02-13 00:42:36.435321+00
2a92f779-4f00-47d4-a381-b962fbb54eb6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:42:43.287799+00	2026-02-13 00:42:43.287799+00
b3284e6e-6bed-49c3-b976-c97ee2f5095c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:43:05.280855+00	2026-02-13 00:43:05.280855+00
983e3f6c-a916-4618-a818-fe61f61b3a0e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:43:06.960046+00	2026-02-13 00:43:06.960046+00
ad026cba-b174-4d32-ac3f-ec9c5ca5ffc4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:43:08.214412+00	2026-02-13 00:43:08.214412+00
ff7ccef8-1019-46b0-9f73-6aba2ac40de5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:43:09.519584+00	2026-02-13 00:43:09.519584+00
0b680ccc-512c-4454-bd8a-cd95d285a184	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:10.559121+00	2026-02-13 00:43:10.559121+00
641d3a14-0471-47ca-9625-019b2927c316	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:43:21.638847+00	2026-02-13 00:43:21.638847+00
80eba7dc-d580-4fcb-b0e4-bd5ef30dd088	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:43:35.79856+00	2026-02-13 00:43:35.79856+00
2027dc16-dfd6-439f-b4ce-03afc9cdcf32	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:43:49.766495+00	2026-02-13 00:43:49.766495+00
af9be5d6-7532-40b5-bb78-0150c41e766d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:41.427967+00	2026-02-13 00:47:41.427967+00
33593fab-6e6a-41d2-8133-06ece0c97dfb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:47:43.02879+00	2026-02-13 00:47:43.02879+00
e932206c-b035-472a-8762-cbd8451ee5b9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:44.370475+00	2026-02-13 00:47:44.370475+00
aefa1077-4bc6-482e-9158-3228b02e647d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:47:45.797338+00	2026-02-13 00:47:45.797338+00
78de481f-6384-410b-86f3-0e43608fe24b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 01:38:05.676386+00	2026-02-14 01:38:05.676386+00
19431dc2-0d17-4c39-80a3-b92a5963268b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 01:45:13.629686+00	2026-02-14 01:45:13.629686+00
a8751ba4-da22-46cf-801a-3022f5d85e0c	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:48.380643+00	2026-02-13 00:47:48.380643+00
033a44b4-5154-49d3-968e-0cbb648e115c	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:49.702748+00	2026-02-13 00:47:49.702748+00
faaab317-ec54-4476-b740-4750da40afc7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:51.856356+00	2026-02-13 00:47:51.856356+00
cf7276e1-7879-4193-bb11-dab4fb39245f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:12.652551+00	2026-02-13 00:42:12.652551+00
791c9971-266d-48ce-8253-4fa4953ea7d6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:13.653519+00	2026-02-13 00:42:13.653519+00
6afc6679-70fd-46cb-b9e4-c0151e283048	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:15.268244+00	2026-02-13 00:42:15.268244+00
841b4645-e273-4c77-a3d3-8f30c2d8ad9d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:42:23.635961+00	2026-02-13 00:42:23.635961+00
2090273f-6e2c-43db-a2f2-16cf7a85a077	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:42:34.734563+00	2026-02-13 00:42:34.734563+00
e636f1f3-5027-4c35-90a1-ea1ccc7a72dd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:42:50.233887+00	2026-02-13 00:42:50.233887+00
f3ea924a-6217-4dc3-ae41-6e705a7021f1	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:43:05.472403+00	2026-02-13 00:43:05.472403+00
1f2f7933-cb21-4221-9b4f-6544da43cc0d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:43:07.243369+00	2026-02-13 00:43:07.243369+00
f9133b53-7190-49f5-b186-65766a731a3e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:08.629448+00	2026-02-13 00:43:08.629448+00
6482bc12-2e18-452c-84fe-a3354b5d3268	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:09.77536+00	2026-02-13 00:43:09.77536+00
ff805d29-f29c-43e1-99de-514d23f67736	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:11.010385+00	2026-02-13 00:43:11.010385+00
0ff5dd00-b3d5-456a-83ce-5410676b55c7	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-14 02:01:30.773484+00	2026-02-14 02:01:30.773484+00
409c5761-c636-43c8-9ab5-0b0279f9c4f7	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:43:13.597964+00	2026-02-13 00:43:13.597964+00
747bd115-505e-465b-8a57-dd23e75a6c13	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:12.564171+00	2026-02-13 00:43:12.564171+00
407b6b4a-e164-4bc3-a768-b988dd9dbe4e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:15.473064+00	2026-02-13 00:43:15.473064+00
663a9b36-99f6-47e0-a266-d978cc9ac5aa	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:43:27.43453+00	2026-02-13 00:43:27.43453+00
424413d2-a294-46c3-9896-ebc0d81ce601	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:43:41.247345+00	2026-02-13 00:43:41.247345+00
60d61e6c-0aaf-4a00-8ea6-67617d48989a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:40.915557+00	2026-02-13 00:47:40.915557+00
94d336b2-14dd-4b98-ac83-4ad94a2803a1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:47:42.419228+00	2026-02-13 00:47:42.419228+00
13dbbd15-c53e-4bc3-864c-ab0b396cfe04	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:47:43.569943+00	2026-02-13 00:47:43.569943+00
bb40825e-5b3d-4395-baca-5376028a2cf0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:47:45.148039+00	2026-02-13 00:47:45.148039+00
6f7a2653-60f0-4ec2-9bc7-d48db69ab945	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:47:46.138941+00	2026-02-13 00:47:46.138941+00
21c24228-37e9-46bb-8503-08a428965fa1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:47.795919+00	2026-02-13 00:47:47.795919+00
5dc8efd7-fbc6-41bd-bd22-b87f2fc457fb	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:47:48.994737+00	2026-02-13 00:47:48.994737+00
688f61c9-b875-48e7-baf8-d8f237141d88	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 03:47:39.21828+00	2026-02-14 03:47:39.21828+00
a4bb2cc2-4ef9-4d12-9452-fb54958a044c	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:42:13.832823+00	2026-02-13 00:42:13.832823+00
e087364c-5bc9-462e-8175-a1174aab0756	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:42:12.824086+00	2026-02-13 00:42:12.824086+00
903c9966-f970-43f5-9230-5b5a7aa121ae	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:42:24.982566+00	2026-02-13 00:42:24.982566+00
227ad816-c79f-4813-b1be-1b4569ad7bff	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:42:32.284927+00	2026-02-13 00:42:32.284927+00
14a3da77-013d-4c38-b8b4-d330629784ac	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:42:37.782009+00	2026-02-13 00:42:37.782009+00
f8df0e0f-58e7-4723-b707-f9b7d356f9df	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:05.622831+00	2026-02-13 00:43:05.622831+00
69727145-0ac7-4df0-bc47-1e8604eaa4a8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:43:07.524132+00	2026-02-13 00:43:07.524132+00
85b99d81-5585-4521-b7b6-cecdff0c4e09	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:43:09.94715+00	2026-02-13 00:43:09.94715+00
0aaad2fb-7536-4a57-b3c8-6c854a6c2e3f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:12.983818+00	2026-02-13 00:43:12.983818+00
a9ff40f5-ca21-42c4-bc21-bd62632d6473	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 03:49:46.191317+00	2026-02-14 03:49:46.191317+00
4c352cbb-7dba-451f-b1f1-2ff9ea9298b6	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:13.840952+00	2026-02-13 00:43:13.840952+00
6aea76ec-30b0-4a51-8797-c488f31ddd1b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:16.164731+00	2026-02-13 00:43:16.164731+00
e0c90ba1-6d8e-4b70-990c-ee99ba77dfeb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:43:25.925662+00	2026-02-13 00:43:25.925662+00
7c73db17-eadc-4a4c-a18d-1d21c3f9bee9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:43:42.866541+00	2026-02-13 00:43:42.866541+00
5c2dedb7-29d5-44b1-9db7-688b03441ff8	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 00:47:41.288508+00	2026-02-13 00:47:41.288508+00
e37dc2bb-3dca-434f-aaa4-abd7eb460921	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 00:47:43.973591+00	2026-02-13 00:47:43.973591+00
0cdbf273-a9e4-4938-b683-84e80a97f906	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:45.62723+00	2026-02-13 00:47:45.62723+00
2023b16c-a7e1-444b-aca3-49be186080d5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:46.909215+00	2026-02-13 00:47:46.909215+00
9c43ee61-6079-4ea0-84c1-e777dbf45557	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 00:47:49.431664+00	2026-02-13 00:47:49.431664+00
f20c3fa7-599e-43b9-b913-94e9fbbd84bb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:51.171594+00	2026-02-13 00:47:51.171594+00
15552775-8f59-461d-986a-c453d1d30789	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 03:55:32.849045+00	2026-02-14 03:55:32.849045+00
a1e6a9fd-de86-4081-8803-22e8fbbb052a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 03:50:36.26899+00	2026-02-14 03:50:36.26899+00
d29c64c7-3d48-4eea-9908-761bdbf08041	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:13.243872+00	2026-02-13 00:42:13.243872+00
cc50f343-faf6-4a3d-ae1c-eebdadacf3ef	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:14.503599+00	2026-02-13 00:42:14.503599+00
901274dd-8461-4248-b0d4-8a842bb6af53	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:42:16.683523+00	2026-02-13 00:42:16.683523+00
12db4b1a-48cd-4858-80e0-b3c7a0ebd9b7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:42:28.960954+00	2026-02-13 00:42:28.960954+00
8870268d-c73d-4dcd-a718-7bf9cdde02e8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:42:46.379393+00	2026-02-13 00:42:46.379393+00
5bc73b81-3145-4254-a3fc-91dbd2d01048	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:42:52.186172+00	2026-02-13 00:42:52.186172+00
4a63392d-7dee-4ae9-8241-3fac82a03e45	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:43:05.809637+00	2026-02-13 00:43:05.809637+00
a2c39520-85a8-46c4-9e12-f70f2f8389d5	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 00:43:07.806786+00	2026-02-13 00:43:07.806786+00
0a2b694a-50c4-455e-846c-42eb5f649a1e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:43:09.17968+00	2026-02-13 00:43:09.17968+00
450cb471-91d6-40f7-8e6f-219e66943571	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:43:10.115457+00	2026-02-13 00:43:10.115457+00
63cc52e5-305f-4e63-b282-87b461e4c7a7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:11.945368+00	2026-02-13 00:43:11.945368+00
c0a94af6-6559-4c9d-9cdd-c8cfb4f608ba	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 00:43:13.157839+00	2026-02-13 00:43:13.157839+00
6495b072-94ae-4f4d-ab17-e4c1a8d46ccd	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:43:14.740665+00	2026-02-13 00:43:14.740665+00
9f78ae6e-6215-4b5c-8ae0-08010a1e9965	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:43:24.621182+00	2026-02-13 00:43:24.621182+00
f4d40bb5-d08a-4dc9-a948-764de3ae84d8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:43:29.100131+00	2026-02-13 00:43:29.100131+00
b2c046ea-153d-4d42-ae50-d6b615309b87	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:43:45.848883+00	2026-02-13 00:43:45.848883+00
633ca8d7-7617-4b92-b524-2e0007b004f6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:43:51.582233+00	2026-02-13 00:43:51.582233+00
89c6ecef-4f1d-4677-9859-d22739bd4d9a	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 00:47:41.606611+00	2026-02-13 00:47:41.606611+00
b0aa220c-47f0-4c53-8dcd-f62bc035f8a0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:47:43.300079+00	2026-02-13 00:47:43.300079+00
8affeec3-3b46-4446-96fc-78391e6cd95e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:47:44.978422+00	2026-02-13 00:47:44.978422+00
0560bfb3-8591-4673-91dd-676cb0ad09ef	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 00:47:45.969956+00	2026-02-13 00:47:45.969956+00
07c2c325-7b15-496a-b55f-08d9a558cb13	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:48.822562+00	2026-02-13 00:47:48.822562+00
b1bf7e82-bab4-457b-a388-970e8a1847d1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 00:47:50.445604+00	2026-02-13 00:47:50.445604+00
bea5c550-96b2-41a1-8a29-795929072764	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:48:00.51691+00	2026-02-13 00:48:00.51691+00
80179db9-2a2f-4113-a037-df38752b1e0b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:48:02.161853+00	2026-02-13 00:48:02.161853+00
ca8a0d3d-380b-4e20-b12c-35ade4d8062a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:48:03.522938+00	2026-02-13 00:48:03.522938+00
f34fcfbb-0ebd-42af-8fa7-999bcdca44b1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:48:04.811826+00	2026-02-13 00:48:04.811826+00
cf9ae69b-1c02-4424-a0ec-9737c84fc43f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 00:48:06.376642+00	2026-02-13 00:48:06.376642+00
daeede2c-72de-4380-986b-ee579b73dd37	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:48:08.160381+00	2026-02-13 00:48:08.160381+00
6baee32b-87af-4571-99af-24dcb59ba56f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:48:10.636341+00	2026-02-13 00:48:10.636341+00
6d1143a6-e957-4e48-af2e-d9a2a3216b79	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:48:12.283989+00	2026-02-13 00:48:12.283989+00
c8ffcc9b-873a-47ac-8973-4f14b570e630	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:48:13.680509+00	2026-02-13 00:48:13.680509+00
ea310464-cdde-42aa-8473-30762213e829	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:48:17.695678+00	2026-02-13 00:48:17.695678+00
7584fb93-53a0-4f9c-b856-0979fde470db	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:48:19.182206+00	2026-02-13 00:48:19.182206+00
9831659b-2135-4656-8175-292a28218065	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:48:20.667758+00	2026-02-13 00:48:20.667758+00
75a6de01-2e05-479a-81fa-9c9cae731e0d	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 02:38:29.918229+00	2026-02-13 02:38:29.918229+00
e05a1777-5aaf-422c-b65c-7ce90e6fed92	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:38:31.595617+00	2026-02-13 02:38:31.595617+00
0d7b2d81-51b7-421e-95f9-cacc777baf51	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:33.035617+00	2026-02-13 02:38:33.035617+00
4960477b-dc43-4cc2-8855-de26dfc5b380	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:34.292037+00	2026-02-13 02:38:34.292037+00
71afdaf8-5b94-4182-aff2-04f07268f768	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:35.575607+00	2026-02-13 02:38:35.575607+00
08d8d8b1-5753-4ffe-ae55-ff67256d4326	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 03:51:32.429356+00	2026-02-14 03:51:32.429356+00
09a8cc61-5664-452d-a5c5-fa5411843c31	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:37.066866+00	2026-02-13 02:38:37.066866+00
cca0fbc1-e20b-44a0-a3cf-94d871c504d9	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:38.334312+00	2026-02-13 02:38:38.334312+00
96429077-5183-4129-8887-8c5f304444e2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:39.812571+00	2026-02-13 02:38:39.812571+00
7da7bf1b-8c1a-4820-8a78-f75dfdd39911	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 02:38:47.428777+00	2026-02-13 02:38:47.428777+00
dd7a8ae2-3ad3-4024-87de-8da65991b3b4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:38:53.788314+00	2026-02-13 02:38:53.788314+00
8f58bbfb-20d6-4153-95c9-3dd75a3179e1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:39:06.574081+00	2026-02-13 02:39:06.574081+00
bc9bf278-cfa5-45d6-967b-3abe00b2d984	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:44:37.11017+00	2026-02-13 02:44:37.11017+00
c6a6df7c-0d80-4c11-9039-81d281ff6764	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:44:38.763032+00	2026-02-13 02:44:38.763032+00
decc73e4-243b-480b-bea4-5ef807f64301	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 02:44:39.955399+00	2026-02-13 02:44:39.955399+00
5df0a396-7843-4f44-a915-2393dd88a50e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:44:41.400337+00	2026-02-13 02:44:41.400337+00
ab43583f-c3e4-49e8-8032-3910bb49a8d4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:42.5082+00	2026-02-13 02:44:42.5082+00
35491cc9-e999-4dd8-9e2a-b86de7d78c4f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:45.390482+00	2026-02-13 02:44:45.390482+00
44d99f1e-1341-4bc4-8a7f-6df9ae3341a2	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 02:44:44.031947+00	2026-02-13 02:44:44.031947+00
d093c933-a88a-4c2b-b3dc-b08262397324	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 02:44:59.71672+00	2026-02-13 02:44:59.71672+00
ce4d0b87-5054-477c-b4b9-8f847bce4229	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:45:10.01415+00	2026-02-13 02:45:10.01415+00
8ddff4c8-dad0-4a53-9887-1efedc27f9a7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:07.575094+00	2026-02-13 02:46:07.575094+00
e972661e-09cf-4b7a-9e2a-18b8d4a79046	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:09.481662+00	2026-02-13 02:46:09.481662+00
761301cb-4ca0-4f59-8bcb-e28ca2ecca39	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:14.528166+00	2026-02-13 02:46:14.528166+00
b18ea5fc-b4ec-4302-a117-18e57f9086c2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:15.307713+00	2026-02-13 02:46:15.307713+00
2eeb229a-2779-40e4-9506-2ec9de4cb1cf	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:18.277385+00	2026-02-13 02:46:18.277385+00
3edf1fba-6172-4385-ba04-00a3524099f4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:26.651369+00	2026-02-13 02:46:26.651369+00
8a97c1f3-fcfc-4e1b-8285-ae7fd2b7bbf1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:55.104703+00	2026-02-13 02:46:55.104703+00
0d0297a5-bb9d-4b25-9a2b-62416169f255	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:56.95835+00	2026-02-13 02:46:56.95835+00
68bea0c7-5601-4691-9740-79b40c5235c2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:59.445888+00	2026-02-13 02:46:59.445888+00
6a2b1a11-7f2e-4f4e-945c-fb1373a3593a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:47:02.395522+00	2026-02-13 02:47:02.395522+00
93903411-e54c-4c2b-a191-86b199aeb8b8	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:47:03.261462+00	2026-02-13 02:47:03.261462+00
2b2317ad-0f49-490d-b2c0-43790689c8ee	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:47:14.400858+00	2026-02-13 02:47:14.400858+00
62241381-3855-4335-892f-110716d68560	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 02:47:18.288285+00	2026-02-13 02:47:18.288285+00
5b692e20-c4ec-4948-b489-fb33d3246832	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 00:48:22.56348+00	2026-02-13 00:48:22.56348+00
9dd9879d-fd67-484e-8682-a23e233f9b40	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:29.550357+00	2026-02-13 02:38:29.550357+00
faeb97fb-9dfc-4e72-88ea-b1975f4e58db	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 02:38:30.236552+00	2026-02-13 02:38:30.236552+00
b10b450d-47a7-4974-9773-87509e9ba13b	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 02:38:32.189328+00	2026-02-13 02:38:32.189328+00
67d2ae6a-6dc5-42a4-ac50-ca9ac9bdeed2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:38:33.811529+00	2026-02-13 02:38:33.811529+00
8ee47373-ef00-437f-a342-3986019ef7dc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:38:34.644295+00	2026-02-13 02:38:34.644295+00
5d4bab70-4d26-4967-8cea-279959452785	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:36.474888+00	2026-02-13 02:38:36.474888+00
0a34bc63-fbc2-4b97-b5f0-43c4e5f15ef6	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 02:38:37.652896+00	2026-02-13 02:38:37.652896+00
16e7836a-7f36-4030-857a-a37807121ba4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:39.081017+00	2026-02-13 02:38:39.081017+00
8afeb858-4166-4ee1-b616-46e4584ffbea	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:38:48.717259+00	2026-02-13 02:38:48.717259+00
782b7769-8441-403c-b8bc-0abfaff51428	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 02:38:52.140754+00	2026-02-13 02:38:52.140754+00
0fa80f42-4c10-4f1f-875f-4308bfaa2070	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:39:08.240954+00	2026-02-13 02:39:08.240954+00
4910a909-1697-430f-8f73-b23e3deebffa	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 02:44:37.289138+00	2026-02-13 02:44:37.289138+00
ad8789af-5624-44eb-affd-ed10b5dbffd8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:44:39.069724+00	2026-02-13 02:44:39.069724+00
ee333141-95d2-4c5e-b79e-a3fdd40746bb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 02:44:40.08745+00	2026-02-13 02:44:40.08745+00
90c24edc-8271-4daa-b485-5acef16662bb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:41.703751+00	2026-02-13 02:44:41.703751+00
ff2db623-e566-4683-a166-ab7e57c5eb49	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:42.95654+00	2026-02-13 02:44:42.95654+00
ed05fd9a-320e-4ca8-8683-864af3032d0e	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 02:44:45.562041+00	2026-02-13 02:44:45.562041+00
e80a6668-e835-4361-8f06-5bfe372a4145	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:47.31013+00	2026-02-13 02:44:47.31013+00
571ce583-fa10-4b90-9e90-57fc683b1d29	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:44:53.4198+00	2026-02-13 02:44:53.4198+00
147ef31c-40bb-4159-9f7a-a98fbc0082db	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:45:13.883674+00	2026-02-13 02:45:13.883674+00
2449266d-3156-41ab-a253-ddc484bc88d1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:45:15.460892+00	2026-02-13 02:45:15.460892+00
9d4ee5b5-01ec-4abc-8c37-3bcf16c9e254	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:07.236117+00	2026-02-13 02:46:07.236117+00
fe138082-747d-4c3a-96d4-67eb88047c6d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:08.878557+00	2026-02-13 02:46:08.878557+00
de66c5a3-6e5a-4638-914c-ea32ba4e5466	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 02:46:10.185535+00	2026-02-13 02:46:10.185535+00
92d4f879-0b67-4729-80a1-e32433cb4c99	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:14.865791+00	2026-02-13 02:46:14.865791+00
b3469096-415e-45ec-9c88-e3bb246491ed	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:15.94168+00	2026-02-13 02:46:15.94168+00
dd1ae7d0-f42c-487c-9a26-95a022f25bb7	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 02:46:18.863892+00	2026-02-13 02:46:18.863892+00
9f1d03d4-7ed4-4bf6-ab31-51319ca39ce1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:23.956921+00	2026-02-13 02:46:23.956921+00
4023fcab-f23a-4da8-86cc-f1addfe281f6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:54.761018+00	2026-02-13 02:46:54.761018+00
98c87d0c-15f1-4acf-8419-030a601e9f11	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:56.389902+00	2026-02-13 02:46:56.389902+00
d3b0f33f-d7e2-42ed-bad8-215def3e6085	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 02:46:57.683345+00	2026-02-13 02:46:57.683345+00
9f8f1e02-a28f-4d02-9a1d-9cc166c1b414	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:58.995163+00	2026-02-13 02:46:58.995163+00
d37f7130-d433-4fba-9885-d4f619ab21f1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:47:00.078686+00	2026-02-13 02:47:00.078686+00
000452ad-355e-44e1-8d4b-b596200b7f10	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 02:47:02.986945+00	2026-02-13 02:47:02.986945+00
616f740a-3643-4a57-bb87-68501697b49a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:47:11.070494+00	2026-02-13 02:47:11.070494+00
792311c7-88bd-47de-a9f2-a626bd5ba482	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 03:56:31.435899+00	2026-02-14 03:56:31.435899+00
cb03d515-f5d2-4429-b503-a971753c9cea	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:38:29.739297+00	2026-02-13 02:38:29.739297+00
9e81a2b7-d58c-4527-aace-140c7b39f43d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:30.058938+00	2026-02-13 02:38:30.058938+00
966fe795-3867-471f-97c5-8f13491fc393	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:38:31.308851+00	2026-02-13 02:38:31.308851+00
c80799b1-bb66-4684-8f40-eacee69447a8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:38:31.893327+00	2026-02-13 02:38:31.893327+00
b2908672-2340-4392-92d7-a6df863a347a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 02:38:32.596912+00	2026-02-13 02:38:32.596912+00
c56280f4-ee3b-47ce-86fd-844ea24643ac	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:38:33.638872+00	2026-02-13 02:38:33.638872+00
fe4ab2d5-feb7-4c90-b7b1-81c86d9c92fa	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:38:34.469459+00	2026-02-13 02:38:34.469459+00
0acaa743-4cbb-4115-ab9f-78e153f0535e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:35.101965+00	2026-02-13 02:38:35.101965+00
8568d0fd-878c-4674-b4b5-6408b18df207	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:37.483798+00	2026-02-13 02:38:37.483798+00
c801bdfd-7480-40f3-ae90-d47732772e73	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 02:38:38.084141+00	2026-02-13 02:38:38.084141+00
e143e546-d760-4d27-9ca1-ae8dc780ac90	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:40.507079+00	2026-02-13 02:38:40.507079+00
0879e7fa-01b9-47f7-9e70-c9d72a7b40e9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:38:45.855128+00	2026-02-13 02:38:45.855128+00
0cfbbfe7-d97b-4ea1-8ec6-ff49cba149da	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:38:49.965543+00	2026-02-13 02:38:49.965543+00
ad878944-a0e5-4127-bd3d-cf368941479e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:39:01.268567+00	2026-02-13 02:39:01.268567+00
f222309b-14dd-4884-82dd-c26e4483cbaf	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:39:09.573548+00	2026-02-13 02:39:09.573548+00
fe42dc7a-2c37-4671-a771-1eb37abe3b22	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:39:11.387951+00	2026-02-13 02:39:11.387951+00
bb0079d5-a672-4ce3-974b-b71d22369bbb	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:36.920263+00	2026-02-13 02:44:36.920263+00
88a1ab95-fffa-490e-8614-38af5971b9c1	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:37.433838+00	2026-02-13 02:44:37.433838+00
40524524-ec68-4b2e-a8c7-823251eba430	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:44:38.466312+00	2026-02-13 02:44:38.466312+00
e8520f00-d861-427a-9206-452c1d3b3d21	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 02:44:39.664474+00	2026-02-13 02:44:39.664474+00
c9fc5f4c-c2b7-4bbe-871e-ba1f4d7d347d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:40.517459+00	2026-02-13 02:44:40.517459+00
2b28442b-fe93-4276-8c0b-335215ff031c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:44:41.230891+00	2026-02-13 02:44:41.230891+00
d359e0b6-d32c-49bf-a7fb-6ff392182317	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:44:41.876055+00	2026-02-13 02:44:41.876055+00
4eb9912e-e1e2-4e87-a7fa-3d7f42e41789	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:44:42.215495+00	2026-02-13 02:44:42.215495+00
23dde06e-0787-4683-8d77-6662890767ae	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:43.85329+00	2026-02-13 02:44:43.85329+00
47a4bd28-72c9-426c-b402-b56480f6e999	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 04:04:37.027033+00	2026-02-14 04:04:37.027033+00
945152aa-f129-413e-9838-d30a2e186ef3	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 02:44:45.112447+00	2026-02-13 02:44:45.112447+00
cac00ac8-1596-4312-ba48-99de527377d5	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:44.478103+00	2026-02-13 02:44:44.478103+00
084cbb73-55de-4532-9157-2dfc2c825758	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:45.821482+00	2026-02-13 02:44:45.821482+00
180741df-25d7-4d69-8e4e-7ceadc1a6d51	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:48.01117+00	2026-02-13 02:44:48.01117+00
1199cffe-20eb-41f8-b8a5-42546eea9f2a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:44:56.552673+00	2026-02-13 02:44:56.552673+00
d79472b6-9423-4acc-8353-d1224b58c77c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:44:58.079281+00	2026-02-13 02:44:58.079281+00
4c694c21-6539-42cc-abc4-8de106a3dbfc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:45:01.311385+00	2026-02-13 02:45:01.311385+00
9e46ede1-7963-4c33-bc7a-7f528d84ff53	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:45:04.901192+00	2026-02-13 02:45:04.901192+00
f77d27e0-8bf3-4338-857b-880a0a16d924	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:45:18.998768+00	2026-02-13 02:45:18.998768+00
1f5d0aea-044d-480f-bb70-b5991b494190	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:07.045346+00	2026-02-13 02:46:07.045346+00
a2edfd9f-3c27-448c-8667-d6e8cd3a85d9	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 02:46:07.412109+00	2026-02-13 02:46:07.412109+00
c3feda30-2c6f-410e-9e21-d741f1f27145	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:08.582773+00	2026-02-13 02:46:08.582773+00
88b6799d-50c4-4cab-b8de-dd5e74094729	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:38:31.013826+00	2026-02-13 02:38:31.013826+00
aa522c91-b985-4c6f-80b2-1343f7c4763c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 02:38:32.476205+00	2026-02-13 02:38:32.476205+00
55d03445-d524-49bd-b6a5-4338f2631cc6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:38:33.985705+00	2026-02-13 02:38:33.985705+00
66255c22-1652-4000-b53b-0e86c72e592c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:38:34.814868+00	2026-02-13 02:38:34.814868+00
4c19632d-1409-48b3-ba49-4a68ce169107	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 04:07:51.899459+00	2026-02-14 04:07:51.899459+00
336f4199-b15f-4cf4-877e-8bf6b95aac02	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:38:37.91443+00	2026-02-13 02:38:37.91443+00
7d969438-48fe-4437-bb52-6a2b43f7c292	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 02:38:36.64694+00	2026-02-13 02:38:36.64694+00
18d94d6e-18cd-42ef-b583-a35a04fac862	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:38:56.172541+00	2026-02-13 02:38:56.172541+00
e6fe4057-c268-4f24-bf14-65bbe5d91ba4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:39:02.674247+00	2026-02-13 02:39:02.674247+00
188aba1b-0633-45f8-bbcc-943566965937	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 02:44:37.616736+00	2026-02-13 02:44:37.616736+00
f2e75bfa-fc8c-4d6a-94b2-27223067686a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:44:39.367314+00	2026-02-13 02:44:39.367314+00
cac867fe-7c37-4229-bbfc-66359a29fac3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:44:41.060426+00	2026-02-13 02:44:41.060426+00
4c56caaa-eb40-44e8-b65e-95d7a0ff19f4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:44:42.046122+00	2026-02-13 02:44:42.046122+00
3b651d77-5023-4e28-aad3-6d3a8444795e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:44.931338+00	2026-02-13 02:44:44.931338+00
2879f845-b23e-426f-8d1c-7912a5b02ef0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:44:46.575512+00	2026-02-13 02:44:46.575512+00
46a26eb1-4f62-4f0e-ac50-0e5ab8498eb7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 02:44:55.009254+00	2026-02-13 02:44:55.009254+00
a6b884d7-be6a-4b19-bbba-66d6e2cac745	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:45:08.664322+00	2026-02-13 02:45:08.664322+00
b302102e-8685-4ea6-848b-a7261bd04aff	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:45:16.777505+00	2026-02-13 02:45:16.777505+00
491760f2-6cc4-4d72-ad80-7ceae130f42f	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 02:46:07.752819+00	2026-02-13 02:46:07.752819+00
d6af300b-01b5-4b81-afd1-43b2b284e4b1	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 02:46:09.775653+00	2026-02-13 02:46:09.775653+00
8b2371e7-c311-4623-ae13-6d4ae83dcb84	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:14.698182+00	2026-02-13 02:46:14.698182+00
66474b58-4cd5-4a24-bffd-38548a657d66	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:15.481015+00	2026-02-13 02:46:15.481015+00
d989ca24-6b39-4eca-b928-5a01d2c5fb10	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:17.265589+00	2026-02-13 02:46:17.265589+00
e70f5733-b9c3-4f7f-a7a7-639adcbfd770	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 02:46:18.44651+00	2026-02-13 02:46:18.44651+00
7a41d348-19b7-4b18-8e8b-806a24407d19	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:19.903206+00	2026-02-13 02:46:19.903206+00
3d26e02c-e714-476e-bbd9-912bf98a8d2b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:20.677392+00	2026-02-13 02:46:20.677392+00
393ef24e-4792-4cf1-91a0-6b21ba8c8eb5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:22.536601+00	2026-02-13 02:46:22.536601+00
761b525b-b793-423d-9486-8b8d7450b205	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:27.149346+00	2026-02-13 02:46:27.149346+00
df546139-a1e4-4e7a-9ef7-24808f6b9327	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 02:46:55.285743+00	2026-02-13 02:46:55.285743+00
f84955d6-34f2-4e1b-bfb2-aa598065afba	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 02:46:57.266801+00	2026-02-13 02:46:57.266801+00
87988c29-9417-437b-b625-860ce5ae6195	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:58.658147+00	2026-02-13 02:46:58.658147+00
44854eb8-bd0e-454b-820a-bad2d91ba36b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:59.619074+00	2026-02-13 02:46:59.619074+00
dd7d17dd-9348-4a61-bb12-c050a2ac59b7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:47:01.397958+00	2026-02-13 02:47:01.397958+00
a20c24f4-a40c-4b51-beed-d3297b241f43	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 02:47:02.568407+00	2026-02-13 02:47:02.568407+00
7739387e-81a0-40e5-aa6c-8bf52bec7bbf	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:47:04.057923+00	2026-02-13 02:47:04.057923+00
14fb8e09-22bf-492b-86ef-99db45afbc8a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:47:04.84849+00	2026-02-13 02:47:04.84849+00
09839348-8cb8-4862-8188-dae06283a4d9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 02:47:12.629767+00	2026-02-13 02:47:12.629767+00
f36769ab-683e-4576-a3f7-33da7cb4ba31	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:09.172114+00	2026-02-13 02:46:09.172114+00
f6d53793-23cd-476b-a687-b040c14a851d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:13.942697+00	2026-02-13 02:46:13.942697+00
b45824fe-cc1f-4591-9906-edfe06bc29ad	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:15.139585+00	2026-02-13 02:46:15.139585+00
334e074b-3806-4d2c-9070-cc4acd69c49f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:16.39042+00	2026-02-13 02:46:16.39042+00
094c90db-b9cb-4d12-9400-ae3d5db45acb	\N	login_failed	\N	172.23.0.1	curl/8.17.0	failure	{"reason": "user_not_found", "identifier_hash": "c03921d3b1b5142e"}	2026-02-14 04:13:42.657485+00	2026-02-14 04:13:42.657485+00
aaeae434-d76f-4d22-91e6-a6e96c1d67ce	\N	login_failed	\N	172.23.0.1	curl/8.17.0	failure	{"reason": "user_not_found", "identifier_hash": "c03921d3b1b5142e"}	2026-02-14 04:13:47.441434+00	2026-02-14 04:13:47.441434+00
96d03628-2db9-4cc0-b1fe-8d819d90122c	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:17.839603+00	2026-02-13 02:46:17.839603+00
5f5b3d73-d077-4936-b7c5-b4101e8ec112	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:19.147829+00	2026-02-13 02:46:19.147829+00
7fe45ae0-029d-479a-be82-4dbd01a6453d	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:54.57145+00	2026-02-13 02:46:54.57145+00
0fd0a93d-4248-4585-8ace-b092e2b1068e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:56.08592+00	2026-02-13 02:46:56.08592+00
2593344d-e003-48f2-8a41-5cf2992ea041	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 02:46:57.562339+00	2026-02-13 02:46:57.562339+00
172c04ed-e162-467c-b81d-7e55311044a4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:58.827707+00	2026-02-13 02:46:58.827707+00
6446efab-e82f-40c8-8e1d-dca513ac4f03	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:59.79319+00	2026-02-13 02:46:59.79319+00
256b3aa8-8eb0-4d7c-8d48-2e8060093ec2	\N	login_failed	\N	172.23.0.1	curl/8.17.0	failure	{"reason": "user_not_found", "identifier_hash": "c03921d3b1b5142e"}	2026-02-14 04:14:21.905792+00	2026-02-14 04:14:21.905792+00
024dcc50-6f76-42d5-b755-5403e15ddda7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:47:02.810149+00	2026-02-13 02:47:02.810149+00
37774d97-cf25-4bb9-b6ff-755143db4dba	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 02:47:01.573421+00	2026-02-13 02:47:01.573421+00
9467e0dd-35c9-4bee-b219-dcf480811cd0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:47:22.150053+00	2026-02-13 02:47:22.150053+00
b2eb801c-66c6-4cb3-a6fa-c129039d8420	\N	login_failed	\N	172.23.0.1	curl/8.17.0	failure	{"reason": "user_not_found", "identifier_hash": "c03921d3b1b5142e"}	2026-02-14 04:14:26.967424+00	2026-02-14 04:14:26.967424+00
23180c15-97de-4454-b479-8caac10bbfb5	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 04:16:41.56869+00	2026-02-14 04:16:41.56869+00
8fa83499-9e53-45c3-aa31-49b2e6647d57	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 04:16:51.813403+00	2026-02-14 04:16:51.813403+00
bc75a80e-4285-4389-aa8f-38ddff0d9ce8	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 04:17:05.531514+00	2026-02-14 04:17:05.531514+00
d187252b-7355-40a6-b8f4-7f884506702b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 02:46:10.054505+00	2026-02-13 02:46:10.054505+00
25aafc9e-f7e0-4e95-86d4-5024eab6eb1e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:15.651201+00	2026-02-13 02:46:15.651201+00
c1c9ff0f-1a40-45ff-9522-97fcb69f9412	\N	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	failure	{"reason": "user_not_found", "identifier_hash": "c03921d3b1b5142e"}	2026-02-14 04:14:48.395244+00	2026-02-14 04:14:48.395244+00
95935339-1937-4e6b-9bb3-5250d24afd6e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:18.69639+00	2026-02-13 02:46:18.69639+00
4826acef-f3b7-4e2d-a7f5-1823664bbcdf	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 02:46:17.440595+00	2026-02-13 02:46:17.440595+00
f13e6913-4a88-4443-b825-95f1dcd65322	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:25.309963+00	2026-02-13 02:46:25.309963+00
87627444-006c-4584-83ea-97c49bb9bb3f	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 02:46:54.93951+00	2026-02-13 02:46:54.93951+00
46110d13-c010-4208-91cd-e4263ddc13e4	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 02:46:56.677344+00	2026-02-13 02:46:56.677344+00
202aebb2-affd-4f51-9a5f-c589ef82eca6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:58.103365+00	2026-02-13 02:46:58.103365+00
7b4968b1-6fd7-4a3d-affb-094c29933832	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:46:59.268875+00	2026-02-13 02:46:59.268875+00
5f0bed1e-d0ea-4167-b5fe-e5d3b5227f78	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:47:00.559333+00	2026-02-13 02:47:00.559333+00
43d28a7b-4238-4754-89ef-ba5c0a9d6a76	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:47:01.980112+00	2026-02-13 02:47:01.980112+00
b02ddee0-76ec-492f-8a8a-d8f733446934	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 02:47:05.646987+00	2026-02-13 02:47:05.646987+00
05b70599-4c2e-4504-bbcc-2b2c29c8f774	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:47:15.542303+00	2026-02-13 02:47:15.542303+00
666885a4-9071-4293-889e-af91609be4a3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:47:24.412878+00	2026-02-13 02:47:24.412878+00
e5d23766-86cb-4493-9067-a796888b0847	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:47:25.988201+00	2026-02-13 02:47:25.988201+00
9e4f7d64-8627-49ac-9d46-d4bd69537db9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:47:27.324948+00	2026-02-13 02:47:27.324948+00
928055ca-c4fd-409f-9b46-62dc61eb67d6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:47:31.179809+00	2026-02-13 02:47:31.179809+00
2486c112-121e-40c9-9acf-d576e9bd02c6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:47:33.397359+00	2026-02-13 02:47:33.397359+00
78df86f0-20f3-4fae-af01-f3bc066add63	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:47:35.019106+00	2026-02-13 02:47:35.019106+00
c28ac4b0-ed7b-4314-9ee2-1d0ab399875a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 02:47:36.771637+00	2026-02-13 02:47:36.771637+00
cffcb7ca-255c-47f5-a49f-212c15e64096	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:14.375895+00	2026-02-13 03:22:14.375895+00
f0fb61ee-0a66-447e-884d-1bba25651673	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 03:22:14.562661+00	2026-02-13 03:22:14.562661+00
686a5579-61d3-42dd-a5c8-56ab55619ca5	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "a19b019a74f96076"}	2026-02-13 03:22:14.739336+00	2026-02-13 03:22:14.739336+00
f2b4f6f4-f567-4316-a2a7-8b70924d0f25	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:14.878866+00	2026-02-13 03:22:14.878866+00
a469ac2a-f249-4d0b-9bc7-976b73038760	\N	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "user_not_found", "identifier_hash": "e3b0c44298fc1c14"}	2026-02-13 03:22:15.058615+00	2026-02-13 03:22:15.058615+00
3782bdb7-6fb0-49e3-b2af-4bfe8bee308c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 03:22:15.929919+00	2026-02-13 03:22:15.929919+00
2dca58c3-6eff-46d6-93b9-05e4bf99fe33	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 03:22:16.226565+00	2026-02-13 03:22:16.226565+00
41834363-f952-4b08-a344-8f571ed5e7f8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 03:22:16.524016+00	2026-02-13 03:22:16.524016+00
a8f56cff-ae97-41c9-89d6-e8e1086bd40b	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 03:22:16.812905+00	2026-02-13 03:22:16.812905+00
0f813d31-a2fb-4372-acb8-a2664f1ace22	c2fc5cdc-eeed-4de8-8474-d2001390069a	account_locked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"failed_attempts": 5}	2026-02-13 03:22:18.208447+00	2026-02-13 03:22:18.208447+00
9298f469-595f-4127-8e01-3bd32af38960	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 03:22:20.722653+00	2026-02-13 03:22:20.722653+00
8042a96c-df41-4cde-8f33-0726ac24a587	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_blocked	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	warning	{"reason": "account_locked"}	2026-02-13 03:22:20.860752+00	2026-02-13 03:22:20.860752+00
b33634dd-4cf7-43b9-a456-435f6dcc74fc	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:21.249682+00	2026-02-13 03:22:21.249682+00
9ed596d0-96e7-42f7-8e21-5a2509f8dfc7	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 03:22:21.806222+00	2026-02-13 03:22:21.806222+00
2a0a7e41-7331-424f-b359-9df354465469	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 03:22:21.974158+00	2026-02-13 03:22:21.974158+00
46824bc1-85a9-448c-8c00-9e7b394423fe	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 03:22:22.144613+00	2026-02-13 03:22:22.144613+00
7e77b659-343d-4543-8884-312812493313	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:22.432508+00	2026-02-13 03:22:22.432508+00
70fdec8a-193b-40eb-83c8-af21b80cb1e3	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 03:22:22.602829+00	2026-02-13 03:22:22.602829+00
ae452130-7d52-4fdc-a735-883588c6e566	eb8f2199-7903-409d-8999-1e450e3c90b8	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-14 04:15:02.953707+00	2026-02-14 04:15:02.953707+00
e092a04b-f8f9-448b-9bc9-c9b4edd7c33c	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 04:16:47.337797+00	2026-02-14 04:16:47.337797+00
6409e056-032f-4d03-9013-748db292e2bd	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:25.18742+00	2026-02-13 03:22:25.18742+00
4dcbc02f-d49e-4e2b-bed0-6d9d8dbc5dd0	\N	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:26.428236+00	2026-02-13 03:22:26.428236+00
3c63a859-9cd8-4bdc-ae56-274e81d5a89c	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 03:22:36.509163+00	2026-02-13 03:22:36.509163+00
1102bc87-313e-4c05-b09a-bbc2d703b00a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 03:22:42.285438+00	2026-02-13 03:22:42.285438+00
0301154a-d0f1-4b0a-9c35-4628f127bd3a	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 03:22:57.00412+00	2026-02-13 03:22:57.00412+00
43200df0-394f-4f31-8a26-5996b001fbf9	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	success	{}	2026-02-14 04:18:22.397171+00	2026-02-14 04:18:22.397171+00
c33c9bbe-edf4-4777-9a7b-d8ddc98f19ad	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 03:22:22.770762+00	2026-02-13 03:22:22.770762+00
a43947e1-db38-4b6f-bc1d-d180096c8bee	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:25.598184+00	2026-02-13 03:22:25.598184+00
a43d29b9-28dc-4351-bf71-3d95de433ce8	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:27.177533+00	2026-02-13 03:22:27.177533+00
76c12588-ce44-4785-92b0-acf4ae27f037	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:27.96304+00	2026-02-13 03:22:27.96304+00
e3c70e8d-e892-4963-b07d-a5d578012be0	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 04:46:46.403275+00	2026-02-14 04:46:46.403275+00
28428db3-0a92-4cda-b189-5da75c2be228	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 04:46:53.105069+00	2026-02-14 04:46:53.105069+00
7ff59e80-a89e-4b72-ad46-b8d0c1f3bf50	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "invalid_password"}	2026-02-13 03:22:22.937654+00	2026-02-13 03:22:22.937654+00
220226c6-2dc7-45d3-8d2b-84e0f447a522	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:24.582319+00	2026-02-13 03:22:24.582319+00
2d8f15f6-c57b-41b7-a5f0-a96bbba2ace1	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "username_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 03:22:25.773491+00	2026-02-13 03:22:25.773491+00
30179e88-428c-465b-ae1b-4d9283a0b506	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 03:22:34.844547+00	2026-02-13 03:22:34.844547+00
af92cc3f-55fb-4988-a4e0-a8d445265f9f	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 03:22:39.077787+00	2026-02-13 03:22:39.077787+00
435128ad-90b7-4b20-9095-a4b05b910c23	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 03:22:44.66723+00	2026-02-13 03:22:44.66723+00
0a4e0336-28b6-428a-a5fa-c72b906f09a0	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 03:22:48.222914+00	2026-02-13 03:22:48.222914+00
049d5690-5f87-43e1-9992-16988bf7daa9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 03:22:58.594226+00	2026-02-13 03:22:58.594226+00
b66bcec3-9cb0-4829-a0cb-3518e8b05c0e	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 04:50:46.476966+00	2026-02-14 04:50:46.476966+00
76a629c3-1d19-4425-97e5-4c926dd6cfd9	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 04:50:52.91096+00	2026-02-14 04:50:52.91096+00
2f062fe2-1cab-4b6d-8986-a0f88abbf0fb	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 04:50:57.549328+00	2026-02-14 04:50:57.549328+00
2d6fc328-704b-4092-80fd-f2b88844cfe5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:23.226693+00	2026-02-13 03:22:23.226693+00
07f5052e-e316-491a-8a67-229c4d5cae75	eb8f2199-7903-409d-8999-1e450e3c90b8	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	failure	{"reason": "invalid_password"}	2026-02-14 05:02:37.296593+00	2026-02-14 05:02:37.296593+00
f24f1979-bce0-4561-9c8d-30326ab485af	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:26.026274+00	2026-02-13 03:22:26.026274+00
787a5825-1fad-4731-864f-bdd770fd23e9	\N	user_created	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{"role": "user", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a", "username": "e2e_newuser"}	2026-02-13 03:22:24.754172+00	2026-02-13 03:22:24.754172+00
4a83c0c3-2fe1-4da2-bdde-7f499bbb44f6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	failure	{"reason": "invalid_password"}	2026-02-13 03:22:40.572243+00	2026-02-13 03:22:40.572243+00
1f8709c4-2777-4dde-8f35-085eb30c664e	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 03:22:46.797801+00	2026-02-13 03:22:46.797801+00
d7f1571b-de61-44fc-92c6-41ff44ab3de5	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 03:23:00.410016+00	2026-02-13 03:23:00.410016+00
ee2c40fd-8b56-49f4-8d01-0ce40a7731d0	eb8f2199-7903-409d-8999-1e450e3c90b8	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	failure	{"reason": "invalid_password"}	2026-02-14 05:02:40.12578+00	2026-02-14 05:02:40.12578+00
b34f72a0-67bf-498e-a485-f9dae4e105ba	eb8f2199-7903-409d-8999-1e450e3c90b8	login_failed	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	failure	{"reason": "invalid_password"}	2026-02-14 13:51:26.932117+00	2026-02-14 13:51:26.932117+00
8c3eeec1-e5d6-4d88-ab59-ecf1b8ede6b6	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:23.669598+00	2026-02-13 03:22:23.669598+00
48d3d5b1-1700-44b0-a276-002df6040e88	\N	user_creation_failed	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	failure	{"reason": "email_exists", "admin_id": "c2fc5cdc-eeed-4de8-8474-d2001390069a"}	2026-02-13 03:22:26.199213+00	2026-02-13 03:22:26.199213+00
0eee97b0-2b6b-468f-a489-52c7c4f2a407	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Playwright/1.58.2 (x64; windows 10.0) node/24.11	success	{}	2026-02-13 03:22:28.734928+00	2026-02-13 03:22:28.734928+00
5539f9a3-835d-4247-9686-f5b05eec80c9	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 03:22:37.886486+00	2026-02-13 03:22:37.886486+00
89381e4a-160b-4bd3-ad6a-7e349cafcab2	c2fc5cdc-eeed-4de8-8474-d2001390069a	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) HeadlessChrome/145.0.7632.6 Safari/537.36	success	{}	2026-02-13 03:22:55.398285+00	2026-02-13 03:22:55.398285+00
d592d07c-267c-4019-adf4-89341ecdcb3a	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 13:55:13.820707+00	2026-02-14 13:55:13.820707+00
4500625c-e19d-49f1-a69c-01b3888b7cf6	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.1	curl/8.17.0	success	{}	2026-02-14 13:55:20.513378+00	2026-02-14 13:55:20.513378+00
bc1e9296-e55c-49a6-baf2-297082122cf7	eb8f2199-7903-409d-8999-1e450e3c90b8	login_success	\N	172.23.0.8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0	success	{}	2026-02-14 13:56:26.771381+00	2026-02-14 13:56:26.771381+00
\.


--
-- Data for Name: automation_actions; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.automation_actions (id, created_at, updated_at, project_id, action_type, action_data, status, result, completed_at, user_approved, executed_at) FROM stdin;
\.


--
-- Data for Name: chats; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.chats (id, created_at, updated_at, project_id, title, is_pinned, is_archived, is_deleted, deleted_at, system_prompt_id, chat_instructions) FROM stdin;
2d58926b-d56e-4515-910d-85293af24c92	2026-02-11 01:14:05.491569+00	2026-02-11 01:14:05.491569+00	52912f56-a267-48dd-b883-8c03015795a6	E2E Test Chat	f	f	f	\N	\N	\N
89169f7c-bee0-4136-a358-8893fea47609	2026-02-11 01:22:59.60719+00	2026-02-11 01:22:59.60719+00	52912f56-a267-48dd-b883-8c03015795a6	E2E Test Chat	f	f	f	\N	\N	\N
c045fdba-6e2d-4721-a498-421f32821d4f	2026-02-11 01:23:45.523139+00	2026-02-11 01:23:45.523139+00	52912f56-a267-48dd-b883-8c03015795a6	E2E Test Chat	f	f	f	\N	\N	\N
ba477caf-9252-4532-b832-e08211fee31d	2026-02-11 01:30:39.988924+00	2026-02-11 01:30:39.988924+00	52912f56-a267-48dd-b883-8c03015795a6	E2E Test	f	f	f	\N	\N	\N
ee120c2e-f6fb-443f-af7a-8957197cbaed	2026-02-11 01:31:24.938489+00	2026-02-11 01:31:24.938489+00	52912f56-a267-48dd-b883-8c03015795a6	E2E Test	f	f	f	\N	\N	\N
d7a963e8-c898-4f1c-858c-2ee086301322	2026-02-11 01:32:33.408517+00	2026-02-11 01:32:33.408517+00	52912f56-a267-48dd-b883-8c03015795a6	E2E Test	f	f	f	\N	\N	\N
620b97c7-8669-4e70-b6af-dc041c6d8a1f	2026-02-11 01:32:33.452589+00	2026-02-11 01:32:33.452589+00	52912f56-a267-48dd-b883-8c03015795a6	E2E Stream Test	f	f	f	\N	\N	\N
92f576f3-d23f-4ef7-866b-d0a35642bb13	2026-02-11 01:35:06.253054+00	2026-02-11 01:35:06.253054+00	52912f56-a267-48dd-b883-8c03015795a6	Diag Test	f	f	f	\N	\N	\N
b68cd3c4-7928-4ad6-908b-e45534a0b5d0	2026-02-11 01:35:06.304694+00	2026-02-11 01:35:06.304694+00	52912f56-a267-48dd-b883-8c03015795a6	Diag Test 2	f	f	f	\N	\N	\N
8f2aae0f-08a0-42a7-97d7-48532adf57cd	2026-02-11 01:36:16.557371+00	2026-02-11 01:36:16.557371+00	52912f56-a267-48dd-b883-8c03015795a6	Message Test	f	f	f	\N	\N	\N
42ed3678-d443-4e35-a380-087845399640	2026-02-12 15:35:47.276579+00	2026-02-12 15:35:47.276579+00	52912f56-a267-48dd-b883-8c03015795a6	Test New Chat	f	f	f	\N	\N	\N
e9e12cea-8e96-43fd-a414-cbaf67e4d827	2026-02-12 15:47:18.233158+00	2026-02-12 15:47:18.233158+00	52912f56-a267-48dd-b883-8c03015795a6	New Chat	f	f	f	\N	\N	\N
60184b97-b586-4480-b131-0515dba99444	2026-02-12 15:54:03.087197+00	2026-02-12 15:54:03.087197+00	52912f56-a267-48dd-b883-8c03015795a6	New Chat	f	f	f	\N	\N	\N
85ccd9e2-3730-42b0-936e-20c4f47650e2	2026-02-12 15:56:13.405897+00	2026-02-12 15:56:13.405897+00	52912f56-a267-48dd-b883-8c03015795a6	New Chat	f	f	f	\N	\N	\N
48ab5cc8-3e5b-42e6-9514-8c89fced8fc2	2026-02-13 00:16:04.753118+00	2026-02-13 00:16:04.837457+00	1872cf8e-b7bc-40de-81ad-9756c909b72c	E2E Chat 1 Updated	f	f	f	\N	\N	\N
15565c5e-2d5a-4c49-ab83-f410dad6b330	2026-02-13 00:16:04.775474+00	2026-02-13 00:16:04.861184+00	1872cf8e-b7bc-40de-81ad-9756c909b72c	E2E Chat 2	f	f	t	2026-02-13 00:16:04.861184+00	\N	\N
d6eb37b2-1368-48d9-a799-8d05333f5581	2026-02-13 00:16:04.897232+00	2026-02-13 00:16:04.897232+00	1872cf8e-b7bc-40de-81ad-9756c909b72c	Sandbox Chat	f	f	f	\N	\N	\N
76d64dd3-4a90-4d30-b4b5-318ec1ae7310	2026-02-13 00:16:40.152406+00	2026-02-13 00:16:40.152406+00	e414376d-662a-4932-89fe-097ad972dc4c	Content Test	f	f	f	\N	\N	\N
4b05fa63-5c59-4c78-b83e-6666c79cd139	2026-02-13 00:16:45.963176+00	2026-02-13 00:16:46.043703+00	8556ea2e-611c-4248-9a4e-7ddbfecb7adb	E2E Chat 1 Updated	f	f	f	\N	\N	\N
d6615869-b8c5-4190-aa06-881ef2407f67	2026-02-13 00:16:45.980961+00	2026-02-13 00:16:46.065129+00	8556ea2e-611c-4248-9a4e-7ddbfecb7adb	E2E Chat 2	f	f	t	2026-02-13 00:16:46.065129+00	\N	\N
a5b269d5-2b53-4052-9d79-5c0c55506cad	2026-02-13 00:16:46.100855+00	2026-02-13 00:16:46.100855+00	8556ea2e-611c-4248-9a4e-7ddbfecb7adb	Sandbox Chat	f	f	f	\N	\N	\N
b9dee3dd-e313-4a67-94af-aa1422ffbe45	2026-02-13 00:16:49.765118+00	2026-02-13 00:16:49.765118+00	f05868b3-467b-4725-8f69-89dbe94505bf	Content Test	f	f	f	\N	\N	\N
27a0504f-0b99-4fa2-86c3-38a687617794	2026-02-13 00:19:07.437318+00	2026-02-13 00:19:07.509712+00	41c701c2-5f78-4b79-815e-9527c5a69949	E2E Chat 1 Updated	f	f	f	\N	\N	\N
1a0b0afd-ce4f-44d9-9045-82ceeb1e4907	2026-02-13 00:19:07.456214+00	2026-02-13 00:19:07.52817+00	41c701c2-5f78-4b79-815e-9527c5a69949	E2E Chat 2	f	f	t	2026-02-13 00:19:07.52817+00	\N	\N
6a29d195-dd9f-4f5b-9f58-f7df38ca397b	2026-02-13 00:19:07.560037+00	2026-02-13 00:19:07.560037+00	41c701c2-5f78-4b79-815e-9527c5a69949	Sandbox Chat	f	f	f	\N	\N	\N
4e517726-967d-4393-b6f0-d8dc38bbe6c0	2026-02-13 00:19:08.209163+00	2026-02-13 00:19:08.209163+00	6086c85d-5275-45ea-8ebf-712410cd1999	Content Test	f	f	f	\N	\N	\N
bc756229-7e19-4ea6-bb22-1aafe7514414	2026-02-13 00:20:07.009082+00	2026-02-13 00:20:07.082687+00	e2aa9db9-d543-4f2c-9d62-25fa601514b6	E2E Chat 1 Updated	f	f	f	\N	\N	\N
228e41ef-ea2c-496d-8b2b-e7a6f71e9f6d	2026-02-13 00:20:07.027589+00	2026-02-13 00:20:07.102219+00	e2aa9db9-d543-4f2c-9d62-25fa601514b6	E2E Chat 2	f	f	t	2026-02-13 00:20:07.102219+00	\N	\N
60426798-3c9e-4d25-88d7-4d4da8d9426d	2026-02-13 00:20:07.132406+00	2026-02-13 00:20:07.132406+00	e2aa9db9-d543-4f2c-9d62-25fa601514b6	Sandbox Chat	f	f	f	\N	\N	\N
c88a0c81-1aeb-47f0-86ed-cd06cb73653e	2026-02-13 00:20:07.801932+00	2026-02-13 00:20:07.801932+00	7d0effb4-a8e7-44a5-b4a1-07e19cef62d9	Content Test	f	f	f	\N	\N	\N
eac59488-9dd7-4b1e-93f5-9ef3f1a590c1	2026-02-13 00:20:25.586623+00	2026-02-13 00:20:25.664634+00	51ed756e-e44f-45a4-b086-2aa8cf8b09f5	E2E Chat 1 Updated	f	f	f	\N	\N	\N
278713f7-732c-432f-901b-04f8f6bd1487	2026-02-13 00:20:25.606738+00	2026-02-13 00:20:25.683829+00	51ed756e-e44f-45a4-b086-2aa8cf8b09f5	E2E Chat 2	f	f	t	2026-02-13 00:20:25.683829+00	\N	\N
35e74bd3-f27e-4e25-92bb-26976ffa366c	2026-02-13 00:20:25.715457+00	2026-02-13 00:20:25.715457+00	51ed756e-e44f-45a4-b086-2aa8cf8b09f5	Sandbox Chat	f	f	f	\N	\N	\N
47ba0c77-4df8-4ebc-a69b-3db7aab0335e	2026-02-13 00:20:26.380375+00	2026-02-13 00:20:26.380375+00	181c89dc-ada0-4579-add2-3fc048fa38d8	Content Test	f	f	f	\N	\N	\N
f79e7e8f-d66a-4296-8eb2-f551ae249d8f	2026-02-13 00:21:54.99886+00	2026-02-13 00:21:55.077215+00	62b4a081-b3eb-4155-b461-7dc8c0f1b56b	E2E Chat 1 Updated	f	f	f	\N	\N	\N
497ddce2-b5d7-4d53-9c72-615c22946d0d	2026-02-13 00:21:55.020228+00	2026-02-13 00:21:55.09501+00	62b4a081-b3eb-4155-b461-7dc8c0f1b56b	E2E Chat 2	f	f	t	2026-02-13 00:21:55.09501+00	\N	\N
2ebf507d-5992-4842-849d-abc76f383db3	2026-02-13 00:21:55.125607+00	2026-02-13 00:21:55.125607+00	62b4a081-b3eb-4155-b461-7dc8c0f1b56b	Sandbox Chat	f	f	f	\N	\N	\N
010dd9eb-a23d-4fcc-8039-21b4593272a4	2026-02-13 00:21:55.781828+00	2026-02-13 00:21:55.781828+00	a61e9a7e-b1dd-4872-87a2-59595d6f2c83	Content Test	f	f	f	\N	\N	\N
40e5ed97-d0f0-4d76-a60b-88f2ff224795	2026-02-13 00:22:15.485254+00	2026-02-13 00:22:15.558868+00	2edd1198-d8cb-4b8b-92cb-d981cf37d9ce	E2E Chat 1 Updated	f	f	f	\N	\N	\N
e7cd9bcc-7567-478f-a582-dc93c4b3dfcc	2026-02-13 00:22:15.502349+00	2026-02-13 00:22:15.577674+00	2edd1198-d8cb-4b8b-92cb-d981cf37d9ce	E2E Chat 2	f	f	t	2026-02-13 00:22:15.577674+00	\N	\N
f2958120-f739-4ffa-85a0-06cdf4950b05	2026-02-13 00:22:15.605088+00	2026-02-13 00:22:15.605088+00	2edd1198-d8cb-4b8b-92cb-d981cf37d9ce	Sandbox Chat	f	f	f	\N	\N	\N
850fd760-49c9-4fc7-8064-f007636b5442	2026-02-13 00:22:16.251986+00	2026-02-13 00:22:16.251986+00	8224d93e-14dd-444c-9e6d-849aa5470999	Content Test	f	f	f	\N	\N	\N
4f2be440-561b-43d3-bcd0-f2e0a3df5218	2026-02-13 00:26:55.127805+00	2026-02-13 00:26:55.202151+00	c97e2d23-e66a-4f61-8f8f-002e652a77d2	E2E Chat 1 Updated	f	f	f	\N	\N	\N
050e6333-370b-4132-a1b9-2cae47427100	2026-02-13 00:26:55.145436+00	2026-02-13 00:26:55.221106+00	c97e2d23-e66a-4f61-8f8f-002e652a77d2	E2E Chat 2	f	f	t	2026-02-13 00:26:55.221106+00	\N	\N
0e44f4be-5898-4291-8a14-30acef18e030	2026-02-13 00:26:55.251278+00	2026-02-13 00:26:55.251278+00	c97e2d23-e66a-4f61-8f8f-002e652a77d2	Sandbox Chat	f	f	f	\N	\N	\N
64930101-5b2a-4014-874d-a5f774cff37c	2026-02-13 00:26:55.87302+00	2026-02-13 00:26:55.87302+00	8e037efe-e332-4873-b4f2-9eea3e8e0678	Content Test	f	f	f	\N	\N	\N
61b5643a-b9dc-49a9-b6f1-994babafce13	2026-02-13 00:27:18.757953+00	2026-02-13 00:27:18.827759+00	b10f0f42-0599-476e-a2d4-112496f1f8f6	E2E Chat 1 Updated	f	f	f	\N	\N	\N
4c3629e6-545d-47c2-9302-7f529fdcf6a4	2026-02-13 00:27:18.775013+00	2026-02-13 00:27:18.844703+00	b10f0f42-0599-476e-a2d4-112496f1f8f6	E2E Chat 2	f	f	t	2026-02-13 00:27:18.844703+00	\N	\N
ee0626c7-3996-4bb9-8599-84d874231235	2026-02-13 00:27:18.873523+00	2026-02-13 00:27:18.873523+00	b10f0f42-0599-476e-a2d4-112496f1f8f6	Sandbox Chat	f	f	f	\N	\N	\N
f6c66b64-c95a-4acc-8c64-df14f16a6fe5	2026-02-13 00:27:19.506565+00	2026-02-13 00:27:19.506565+00	cb8dc745-4dbf-43e5-bf4b-309fbbfa8fdf	Content Test	f	f	f	\N	\N	\N
0017df0f-9ad3-4bbc-af0a-cbb13e47ea5a	2026-02-13 00:29:55.925594+00	2026-02-13 00:29:56.000747+00	17c72efe-7017-4a5f-b4b2-dd18ff4da83d	E2E Chat 1 Updated	f	f	f	\N	\N	\N
20f342ad-7f0a-468d-9192-82ca8c176ff0	2026-02-13 00:29:55.944644+00	2026-02-13 00:29:56.019477+00	17c72efe-7017-4a5f-b4b2-dd18ff4da83d	E2E Chat 2	f	f	t	2026-02-13 00:29:56.019477+00	\N	\N
ab2d59e9-9ce1-455f-bd2b-cb63f4f067f0	2026-02-13 00:29:56.050049+00	2026-02-13 00:29:56.050049+00	17c72efe-7017-4a5f-b4b2-dd18ff4da83d	Sandbox Chat	f	f	f	\N	\N	\N
b45f8ac0-de2e-40cb-bd36-4bfb0d2e135c	2026-02-13 00:29:56.682215+00	2026-02-13 00:29:56.682215+00	b63daf7b-3749-4902-b830-71e5007fe029	Content Test	f	f	f	\N	\N	\N
d93741ca-8b37-4014-942c-54db1278d8ac	2026-02-13 00:30:21.38879+00	2026-02-13 00:30:21.476878+00	3e7cec57-13ac-4d07-a8ec-178178c8f6f9	E2E Chat 1 Updated	f	f	f	\N	\N	\N
dc9af605-b345-460d-b16f-1aede1f10bdd	2026-02-13 00:30:21.408179+00	2026-02-13 00:30:21.498582+00	3e7cec57-13ac-4d07-a8ec-178178c8f6f9	E2E Chat 2	f	f	t	2026-02-13 00:30:21.498582+00	\N	\N
b7e10818-579b-4f51-8b02-2cb780e03f5e	2026-02-13 00:30:21.533371+00	2026-02-13 00:30:21.533371+00	3e7cec57-13ac-4d07-a8ec-178178c8f6f9	Sandbox Chat	f	f	f	\N	\N	\N
bd61425f-dd9a-4718-bf01-aee6405f547a	2026-02-13 00:30:22.225502+00	2026-02-13 00:30:22.225502+00	0ca25292-defd-495e-bbd0-90a11e577807	Content Test	f	f	f	\N	\N	\N
780f00ac-65ed-41c0-bf80-4790d556f600	2026-02-13 00:34:39.838065+00	2026-02-13 00:34:39.908172+00	48261fd9-d012-4338-8a5d-0f57bdcc5694	E2E Chat 1 Updated	f	f	f	\N	\N	\N
dd065397-7971-4987-a3af-c95af863acdf	2026-02-13 00:34:39.855531+00	2026-02-13 00:34:39.925797+00	48261fd9-d012-4338-8a5d-0f57bdcc5694	E2E Chat 2	f	f	t	2026-02-13 00:34:39.925797+00	\N	\N
b419ab99-659c-40b4-b5ab-bfeeab326f3b	2026-02-13 00:34:39.954612+00	2026-02-13 00:34:39.954612+00	48261fd9-d012-4338-8a5d-0f57bdcc5694	Sandbox Chat	f	f	f	\N	\N	\N
23cf3ad3-c4e3-47f8-8736-16cc0078538c	2026-02-13 00:34:40.597272+00	2026-02-13 00:34:40.597272+00	087bfd23-df1d-4454-8529-51ea1de2f962	Content Test	f	f	f	\N	\N	\N
59ee4df4-6e12-4c45-b3c9-5b1f67709be1	2026-02-13 00:35:22.34837+00	2026-02-13 00:35:22.438671+00	e1cd04c1-a7e1-4ec2-81e5-639d1f720be5	E2E Chat 1 Updated	f	f	f	\N	\N	\N
97cd2dbd-de34-49aa-99c9-f7fb3483aa2b	2026-02-13 00:35:22.371705+00	2026-02-13 00:35:22.460379+00	e1cd04c1-a7e1-4ec2-81e5-639d1f720be5	E2E Chat 2	f	f	t	2026-02-13 00:35:22.460379+00	\N	\N
5e10f0e6-0887-4dda-9a5d-7633e3c09780	2026-02-13 00:35:22.495178+00	2026-02-13 00:35:22.495178+00	e1cd04c1-a7e1-4ec2-81e5-639d1f720be5	Sandbox Chat	f	f	f	\N	\N	\N
67dd6424-59af-4daf-9080-f6827e5c20e3	2026-02-13 00:35:23.303878+00	2026-02-13 00:35:23.303878+00	0bda7c2d-52c9-4096-bf6a-bba22152190c	Content Test	f	f	f	\N	\N	\N
8e4a28f2-4308-4d87-ab2d-00c5f8bd8c64	2026-02-13 00:35:32.254385+00	2026-02-13 00:35:32.325125+00	3889b51d-1cab-4ca3-bac6-675285cda0c3	E2E Chat 1 Updated	f	f	f	\N	\N	\N
d32e28bd-f432-434f-8f68-f3a5b1501010	2026-02-13 00:35:32.271663+00	2026-02-13 00:35:32.342585+00	3889b51d-1cab-4ca3-bac6-675285cda0c3	E2E Chat 2	f	f	t	2026-02-13 00:35:32.342585+00	\N	\N
4cc35bc7-860a-48a2-9023-b7c54370a261	2026-02-13 00:35:32.373017+00	2026-02-13 00:35:32.373017+00	3889b51d-1cab-4ca3-bac6-675285cda0c3	Sandbox Chat	f	f	f	\N	\N	\N
d119a781-8652-4790-9562-7e26333b0564	2026-02-12 19:58:37.629037+00	2026-02-14 16:21:18.848818+00	17ba3925-2f72-4b07-b489-650f6f894ddf	New Chat	f	f	t	2026-02-14 16:21:18.848818+00	\N	\N
115d7c2c-136e-42f6-bfb0-b500d39c2023	2026-02-12 19:56:42.424473+00	2026-02-14 16:21:22.778578+00	17ba3925-2f72-4b07-b489-650f6f894ddf	New Chat	f	f	t	2026-02-14 16:21:22.778578+00	\N	\N
4fe9b7ec-3d7b-4d4b-87e0-d1c40b8dc818	2026-02-12 18:42:35.207825+00	2026-02-14 16:21:27.26097+00	17ba3925-2f72-4b07-b489-650f6f894ddf	New Chat	f	f	t	2026-02-14 16:21:27.26097+00	\N	\N
4df65c81-ba6a-409b-bfa1-80919cb8f171	2026-02-12 16:04:52.910787+00	2026-02-14 16:21:32.745987+00	17ba3925-2f72-4b07-b489-650f6f894ddf	New Chat	f	f	t	2026-02-14 16:21:32.745987+00	\N	\N
64cd1792-febc-4d99-807b-72552e1e12fb	2026-02-12 15:42:29.187135+00	2026-02-14 16:21:37.330723+00	17ba3925-2f72-4b07-b489-650f6f894ddf	New Chat	f	f	t	2026-02-14 16:21:37.330723+00	\N	\N
75a6b756-fee7-408a-802c-2d6a01afdf8d	2026-02-11 03:09:11.137461+00	2026-02-14 16:21:41.906607+00	17ba3925-2f72-4b07-b489-650f6f894ddf	New Chat	f	f	t	2026-02-14 16:21:41.906607+00	\N	\N
7d8ce8b1-afc8-49b9-886c-d3c3bbcf16c4	2026-02-11 02:47:13.983494+00	2026-02-14 16:21:46.657493+00	17ba3925-2f72-4b07-b489-650f6f894ddf	test	f	f	t	2026-02-14 16:21:46.657493+00	\N	\N
5e0ea95d-e513-445b-943e-caa17900eab9	2026-02-11 02:30:46.412751+00	2026-02-14 16:21:53.358138+00	17ba3925-2f72-4b07-b489-650f6f894ddf	New Chat	f	f	t	2026-02-14 16:21:53.358138+00	\N	\N
818e74fd-c2f6-49e7-a2fa-6a0f10f365dc	2026-02-13 00:35:32.989954+00	2026-02-13 00:35:32.989954+00	66a00df2-9fba-4f5e-9cf0-0344f84ea764	Content Test	f	f	f	\N	\N	\N
370c7867-cdd7-4174-bcc6-45210b4ec3e0	2026-02-13 00:37:54.855703+00	2026-02-13 00:37:54.855703+00	11f25e5e-9b07-4671-afed-ef0180912542	Content Test	f	f	f	\N	\N	\N
6553b708-c195-42da-b9ac-3d650021021e	2026-02-13 00:38:26.454506+00	2026-02-13 00:38:26.454506+00	f07ffbf0-9a18-4ec7-b403-5bc3cf2cd96e	Content Test	f	f	f	\N	\N	\N
c63c8fa3-5810-49f7-b86d-154229133a92	2026-02-13 00:39:02.287555+00	2026-02-13 00:39:02.373283+00	5563bbf1-e1b4-41dc-82f8-76f70935c8e3	E2E Chat 2	f	f	t	2026-02-13 00:39:02.373283+00	\N	\N
152f2cdd-b218-43a1-bf26-947c9d5da6ef	2026-02-13 00:37:54.082654+00	2026-02-13 00:37:54.160687+00	97b28116-95f0-42e2-a36a-d30289cdf67d	E2E Chat 1 Updated	f	f	f	\N	\N	\N
4df019e6-643a-433b-8be9-a81dae50412e	2026-02-13 00:38:25.691079+00	2026-02-13 00:38:25.768279+00	5eb94327-00bd-4fa9-a991-ffb72e797292	E2E Chat 2	f	f	t	2026-02-13 00:38:25.768279+00	\N	\N
23841b99-06f0-43f0-b52a-19ea3f44f19c	2026-02-13 00:37:54.101408+00	2026-02-13 00:37:54.179253+00	97b28116-95f0-42e2-a36a-d30289cdf67d	E2E Chat 2	f	f	t	2026-02-13 00:37:54.179253+00	\N	\N
f38a2d4f-c88c-45a3-91c1-adc1676a4bed	2026-02-13 00:38:25.671701+00	2026-02-13 00:38:25.748128+00	5eb94327-00bd-4fa9-a991-ffb72e797292	E2E Chat 1 Updated	f	f	f	\N	\N	\N
0811d9aa-ab10-4ddb-9ced-842941891313	2026-02-13 00:37:54.208723+00	2026-02-13 00:37:54.208723+00	97b28116-95f0-42e2-a36a-d30289cdf67d	Sandbox Chat	f	f	f	\N	\N	\N
bc12218f-a676-4a75-893e-78ec00b775c9	2026-02-13 00:38:25.797752+00	2026-02-13 00:38:25.797752+00	5eb94327-00bd-4fa9-a991-ffb72e797292	Sandbox Chat	f	f	f	\N	\N	\N
40cce187-41f1-4c0f-8717-786b54b23e5d	2026-02-13 00:39:02.26935+00	2026-02-13 00:39:02.3485+00	5563bbf1-e1b4-41dc-82f8-76f70935c8e3	E2E Chat 1 Updated	f	f	f	\N	\N	\N
9fbdabe9-38a1-4732-befb-251979d97e38	2026-02-13 00:39:02.409093+00	2026-02-13 00:39:02.409093+00	5563bbf1-e1b4-41dc-82f8-76f70935c8e3	Sandbox Chat	f	f	f	\N	\N	\N
021a7504-08e7-4b13-9d81-1047f5c2eeb5	2026-02-13 00:39:03.248485+00	2026-02-13 00:39:03.248485+00	e99e5c4c-9cf0-421c-990d-c83c17caca6f	Content Test	f	f	f	\N	\N	\N
eb4035a3-a9de-4e51-84ad-2a96f2c6c9ac	2026-02-13 00:42:16.237921+00	2026-02-13 00:42:16.309341+00	fd8f57b2-60d2-4a50-b8b7-1444f8f4f42e	E2E Chat 1 Updated	f	f	f	\N	\N	\N
bf760637-8eb7-4113-af07-0c5d11886a92	2026-02-13 00:42:16.255874+00	2026-02-13 00:42:16.327087+00	fd8f57b2-60d2-4a50-b8b7-1444f8f4f42e	E2E Chat 2	f	f	t	2026-02-13 00:42:16.327087+00	\N	\N
6c8d6284-4482-4d17-8765-db7462c346e6	2026-02-13 00:42:16.357453+00	2026-02-13 00:42:16.357453+00	fd8f57b2-60d2-4a50-b8b7-1444f8f4f42e	Sandbox Chat	f	f	f	\N	\N	\N
4a78f35c-9e9e-465d-81e7-2800cd0e3d3c	2026-02-13 00:42:17.002838+00	2026-02-13 00:42:17.002838+00	dd38599d-08b7-4788-9053-f8ca2dbd658a	Content Test	f	f	f	\N	\N	\N
b1cd4b0f-57bf-4bad-a328-a894f73de2be	2026-02-13 00:43:15.713911+00	2026-02-13 00:43:15.781773+00	d8b2bf61-6c7d-43d2-8b19-a7156956472d	E2E Chat 1 Updated	f	f	f	\N	\N	\N
c0514935-953d-4a8f-a098-cbe759cf9987	2026-02-13 00:43:15.729923+00	2026-02-13 00:43:15.798504+00	d8b2bf61-6c7d-43d2-8b19-a7156956472d	E2E Chat 2	f	f	t	2026-02-13 00:43:15.798504+00	\N	\N
690cd74a-49a4-47a3-bb5c-be2113255b32	2026-02-13 00:43:15.825317+00	2026-02-13 00:43:15.825317+00	d8b2bf61-6c7d-43d2-8b19-a7156956472d	Sandbox Chat	f	f	f	\N	\N	\N
32d8c5b4-fcf8-4e7f-ad99-2ffb7392b300	2026-02-13 00:43:16.468257+00	2026-02-13 00:43:16.468257+00	bc210f3d-c590-419d-8fb3-42565dd4a604	Content Test	f	f	f	\N	\N	\N
4dc3484d-20f8-48fc-835e-27b36d0d4c42	2026-02-13 00:47:51.413478+00	2026-02-13 00:47:51.485471+00	0d5e3212-d14d-4bf7-a14f-02d305df6173	E2E Chat 1 Updated	f	f	f	\N	\N	\N
0b8aa3a7-8306-4bde-ab12-548fcdeaa87e	2026-02-13 00:47:51.431135+00	2026-02-13 00:47:51.502665+00	0d5e3212-d14d-4bf7-a14f-02d305df6173	E2E Chat 2	f	f	t	2026-02-13 00:47:51.502665+00	\N	\N
1ab330fc-fa32-43a1-b3c9-b2ee19562027	2026-02-13 00:47:51.530657+00	2026-02-13 00:47:51.530657+00	0d5e3212-d14d-4bf7-a14f-02d305df6173	Sandbox Chat	f	f	f	\N	\N	\N
1b176956-aa76-472e-9ffe-e416543481e3	2026-02-13 00:47:52.178604+00	2026-02-13 00:47:52.178604+00	4f2f20fe-1595-4569-8647-4a2e3696c910	Content Test	f	f	f	\N	\N	\N
1838cc4b-12c0-4119-ad77-d9fd54f16a58	2026-02-13 02:38:40.056285+00	2026-02-13 02:38:40.133681+00	634c5e58-0b8e-489f-9d26-2da982c5a501	E2E Chat 1 Updated	f	f	f	\N	\N	\N
c32947cc-ceb9-4c79-8a47-f76656f77b60	2026-02-13 02:38:40.075521+00	2026-02-13 02:38:40.151943+00	634c5e58-0b8e-489f-9d26-2da982c5a501	E2E Chat 2	f	f	t	2026-02-13 02:38:40.151943+00	\N	\N
7764fee1-2a00-42f3-b458-519c203f0354	2026-02-13 02:38:40.180581+00	2026-02-13 02:38:40.180581+00	634c5e58-0b8e-489f-9d26-2da982c5a501	Sandbox Chat	f	f	f	\N	\N	\N
c1ae9230-3e15-49ee-a0e9-2fd134c202d9	2026-02-13 02:38:40.807024+00	2026-02-13 02:38:40.807024+00	2fac52e9-e637-4703-a742-b4393307b33d	Content Test	f	f	f	\N	\N	\N
2dc21035-bef7-4318-98f8-a6ba5d1e9edf	2026-02-13 02:44:47.556359+00	2026-02-13 02:44:47.629615+00	93260f7c-22cd-4793-8a10-025dc3662463	E2E Chat 1 Updated	f	f	f	\N	\N	\N
c6110fbb-3b8a-41dd-b8dc-85758d403eb5	2026-02-13 02:44:47.574135+00	2026-02-13 02:44:47.647168+00	93260f7c-22cd-4793-8a10-025dc3662463	E2E Chat 2	f	f	t	2026-02-13 02:44:47.647168+00	\N	\N
6b25a0ab-bb07-4a13-91d6-e3d62224d72b	2026-02-13 02:44:47.674522+00	2026-02-13 02:44:47.674522+00	93260f7c-22cd-4793-8a10-025dc3662463	Sandbox Chat	f	f	f	\N	\N	\N
af4c1382-0cb4-48f7-9ff7-0cb143b45b54	2026-02-13 02:44:48.315415+00	2026-02-13 02:44:48.315415+00	d3e1f766-f1d1-484d-8d1b-98cf03fe7376	Content Test	f	f	f	\N	\N	\N
73f622ea-bcb4-4af1-b0e7-a779fc499aad	2026-02-13 02:46:20.9406+00	2026-02-13 02:46:21.012904+00	e0831874-78b5-4cd1-b63b-039f3291558a	E2E Chat 1 Updated	f	f	f	\N	\N	\N
599bb85b-4498-4716-a0f7-fe4121db8dec	2026-02-13 02:46:20.962534+00	2026-02-13 02:46:21.030744+00	e0831874-78b5-4cd1-b63b-039f3291558a	E2E Chat 2	f	f	t	2026-02-13 02:46:21.030744+00	\N	\N
fe89c0f8-3b0a-4c0a-b200-c90c93e87054	2026-02-13 02:46:21.061923+00	2026-02-13 02:46:21.061923+00	e0831874-78b5-4cd1-b63b-039f3291558a	Sandbox Chat	f	f	f	\N	\N	\N
720adf73-8d05-4720-95b9-ea2415dfcb3a	2026-02-13 02:46:27.490778+00	2026-02-13 02:46:27.490778+00	fb1c949a-22c5-464c-8a9f-831367a32b38	Content Test	f	f	f	\N	\N	\N
ab45ee43-5cab-494b-a833-67e45f319511	2026-02-13 02:47:05.117966+00	2026-02-13 02:47:05.196332+00	83cca71e-52bb-44cf-a162-9a9e81eb0194	E2E Chat 1 Updated	f	f	f	\N	\N	\N
bb343dc2-5482-4687-b7f4-1b30a04d381a	2026-02-13 02:47:05.140592+00	2026-02-13 02:47:05.216253+00	83cca71e-52bb-44cf-a162-9a9e81eb0194	E2E Chat 2	f	f	t	2026-02-13 02:47:05.216253+00	\N	\N
7b31f69a-b9b3-4015-b816-3e77e62b75f4	2026-02-13 02:47:05.248121+00	2026-02-13 02:47:05.248121+00	83cca71e-52bb-44cf-a162-9a9e81eb0194	Sandbox Chat	f	f	f	\N	\N	\N
151bf9e7-a960-4833-9d67-092eef90496a	2026-02-13 02:47:05.969718+00	2026-02-13 02:47:05.969718+00	9fa359f6-c988-465d-a42e-35d3a44b1b1c	Content Test	f	f	f	\N	\N	\N
1731a605-6801-4d09-8f80-317901d9548c	2026-02-13 03:22:28.204465+00	2026-02-13 03:22:28.272638+00	b23b6b74-aa74-430c-816a-d5f913e4baff	E2E Chat 1 Updated	f	f	f	\N	\N	\N
ff42b1e3-187f-4055-bfff-8debbda19cbe	2026-02-13 03:22:28.221845+00	2026-02-13 03:22:28.289289+00	b23b6b74-aa74-430c-816a-d5f913e4baff	E2E Chat 2	f	f	t	2026-02-13 03:22:28.289289+00	\N	\N
3c975dba-e2b8-41e9-93fc-f6f5f7e866af	2026-02-13 03:22:28.317735+00	2026-02-13 03:22:28.317735+00	b23b6b74-aa74-430c-816a-d5f913e4baff	Sandbox Chat	f	f	f	\N	\N	\N
d42a8de1-770a-49c5-9889-4092bdbffadb	2026-02-13 03:22:29.037364+00	2026-02-13 03:22:29.037364+00	e355d2b1-f5fb-4c08-a4ff-deedbccb3373	Content Test	f	f	f	\N	\N	\N
80d0ba1d-93df-4292-b8d7-71941fc6f132	2026-02-13 23:32:09.276892+00	2026-02-13 23:32:09.276892+00	52912f56-a267-48dd-b883-8c03015795a6	New Chat	f	f	f	\N	\N	\N
62cf4878-8ea9-46f8-b7ec-a188ee7fbdc8	2026-02-13 03:25:57.449522+00	2026-02-14 01:14:03.89769+00	17ba3925-2f72-4b07-b489-650f6f894ddf	Sandbox Chat	f	f	t	2026-02-14 01:14:03.89769+00	\N	\N
8eaafc4e-439c-4deb-b24d-ae3a76c064d4	2026-02-11 02:56:57.572468+00	2026-02-14 13:56:45.368263+00	17ba3925-2f72-4b07-b489-650f6f894ddf	New Chat	f	f	t	2026-02-14 13:56:45.368263+00	\N	\N
ffcde943-961d-488e-9543-41ca2a0b803b	2026-02-14 01:16:38.482095+00	2026-02-14 14:11:16.417677+00	b727e152-abc0-4a0e-bfc3-ee2c288463f7	Sandbox Chat	f	f	f	\N	\N	\N
bae6d913-0e24-43a8-a7d7-518b32de3c07	2026-02-12 19:53:26.623164+00	2026-02-14 14:12:20.504315+00	17ba3925-2f72-4b07-b489-650f6f894ddf	New Chat	f	f	t	2026-02-14 14:12:20.504315+00	\N	\N
83cfcbfe-dece-4361-8be6-46a4ca27c27a	2026-02-14 00:05:03.808133+00	2026-02-14 16:21:11.421467+00	17ba3925-2f72-4b07-b489-650f6f894ddf	New Chat	f	f	t	2026-02-14 16:21:11.421467+00	\N	\N
a889c1c9-b2ec-43f7-88ee-24a43de6d9d2	2026-02-14 16:22:45.642694+00	2026-02-14 16:22:45.642694+00	b727e152-abc0-4a0e-bfc3-ee2c288463f7	New Chat	f	f	f	\N	\N	\N
9db030ed-3160-473f-b369-72a992e3bbad	2026-02-14 23:05:57.814032+00	2026-02-14 23:05:57.893684+00	1cb9d6f1-7636-4a23-9d96-e9048e44e31f	E2E Chat 1 Updated	f	f	f	\N	\N	\N
31e55c9b-9cd0-463f-a593-ca19661db03e	2026-02-14 23:05:57.834168+00	2026-02-14 23:05:57.914235+00	1cb9d6f1-7636-4a23-9d96-e9048e44e31f	E2E Chat 2	f	f	t	2026-02-14 23:05:57.914235+00	\N	\N
cbbb8d67-fbeb-4948-8cbb-a28bf39c0884	2026-02-14 23:05:57.945181+00	2026-02-14 23:05:57.945181+00	1cb9d6f1-7636-4a23-9d96-e9048e44e31f	Sandbox Chat	f	f	f	\N	\N	\N
7b842dd3-7330-445b-9ba9-62c701f71a8e	2026-02-14 23:06:01.834551+00	2026-02-14 23:06:01.834551+00	3b51d825-0ba8-4fed-84af-7f7ab26e2cff	Content Test	f	f	f	\N	\N	\N
21dd2547-cdfe-4ffe-9e83-567fe5a64806	2026-02-15 00:25:39.560934+00	2026-02-15 00:26:09.019415+00	b727e152-abc0-4a0e-bfc3-ee2c288463f7	I'm doing great! How can I help you today?	f	f	f	\N	\N	\N
b6759ce8-5898-4c1b-a7a9-bcbb76ee1253	2026-02-15 18:10:07.498855+00	2026-02-15 18:10:13.102672+00	17ba3925-2f72-4b07-b489-650f6f894ddf	Instacart was founded in 2014 by a group of food delivery and grocery service	f	f	f	\N	\N	\N
\.


--
-- Data for Name: context_compactions; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.context_compactions (id, created_at, updated_at, chat_id, original_message_count, compacted_message_count, summary, status) FROM stdin;
7225147c-28f1-4514-83a7-3dba000e2202	2026-02-15 18:16:33.124547+00	2026-02-15 18:16:33.124547+00	b6759ce8-5898-4c1b-a7a9-bcbb76ee1253	8	0	[Pending compaction — awaiting LLM summarization]	pending
\.


--
-- Data for Name: context_snippets; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.context_snippets (user_id, name, content, description, tags, is_deleted, deleted_at, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: drupal_sites; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.drupal_sites (id, project_id, site_url, api_key_encrypted, site_name, last_sync_at, sync_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.events (id, event_type, event_data, severity, source, user_id, chat_id, resource_id, created_at, updated_at) FROM stdin;
09a35947-e013-4b58-94ba-1189029d38a6	compaction_triggered	{"chat_id": "b6759ce8-5898-4c1b-a7a9-bcbb76ee1253", "compaction_id": "7225147c-28f1-4514-83a7-3dba000e2202", "original_message_count": 8}	info	context_manager	\N	\N	\N	2026-02-15 18:16:33.133735+00	2026-02-15 18:16:33.133735+00
\.


--
-- Data for Name: help_topics; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.help_topics (slug, section_id, title, body, tags, embedding, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: image_generations; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.image_generations (id, user_id, project_id, workflow_type, prompt, negative_prompt, status, workflow_data, result_images, error_message, comfyui_job_id, created_at, updated_at, is_deleted, deleted_at) FROM stdin;
a0000000-0000-0000-0000-000000000001	c2fc5cdc-eeed-4de8-8474-d2001390069a	52912f56-a267-48dd-b883-8c03015795a6	text-to-image	A beautiful red pixel	\N	completed	{}	["test.png"]	\N	\N	2026-02-14 04:07:04.153298+00	2026-02-14 04:07:04.153298+00	f	\N
00000000-0000-0000-0000-000000000002	eb8f2199-7903-409d-8999-1e450e3c90b8	17ba3925-2f72-4b07-b489-650f6f894ddf	text-to-image	A beautiful red pixel	\N	completed	{}	["test_red.png"]	\N	\N	2026-02-14 04:17:53.822536+00	2026-02-14 04:17:53.822536+00	f	\N
6fe07a62-d32a-4b24-92dd-bf750627e368	eb8f2199-7903-409d-8999-1e450e3c90b8	b727e152-abc0-4a0e-bfc3-ee2c288463f7	text-to-image	A beautiful sunset over a mountain lake, vibrant colors, photorealistic	blurry, low quality, distorted, watermark	failed	{"3": {"inputs": {"cfg": 7.0, "seed": -1, "model": ["4", 0], "steps": 20, "denoise": 1.0, "negative": ["7", 0], "positive": ["6", 0], "scheduler": "normal", "latent_image": ["5", 0], "sampler_name": "euler"}, "class_type": "KSampler"}, "4": {"inputs": {"ckpt_name": "v1-5-pruned-emaonly.safetensors"}, "class_type": "CheckpointLoaderSimple"}, "5": {"inputs": {"width": 512, "height": 512, "batch_size": 1}, "class_type": "EmptyLatentImage"}, "6": {"inputs": {"clip": ["4", 1], "text": "A beautiful sunset over a mountain lake, vibrant colors, photorealistic"}, "class_type": "CLIPTextEncode"}, "7": {"inputs": {"clip": ["4", 1], "text": "blurry, low quality, distorted, watermark"}, "class_type": "CLIPTextEncode"}, "8": {"inputs": {"vae": ["4", 2], "samples": ["3", 0]}, "class_type": "VAEDecode"}, "9": {"inputs": {"images": ["8", 0], "filename_prefix": "workstation"}, "class_type": "SaveImage"}}	[]	Client error '400 Bad Request' for url 'http://comfyui:8188/prompt'\nFor more information check: https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/400	\N	2026-02-14 21:32:32.095206+00	2026-02-14 21:36:55.692018+00	t	2026-02-14 21:36:55.692689+00
c7cd21ef-bc97-44ce-b695-1bead7d89322	eb8f2199-7903-409d-8999-1e450e3c90b8	b727e152-abc0-4a0e-bfc3-ee2c288463f7	text-to-image	A beautiful sunset over a mountain lake, vibrant colors, photorealistic	blurry, low quality, distorted, watermark	failed	{"3": {"inputs": {"cfg": 7.0, "seed": -1, "model": ["4", 0], "steps": 20, "denoise": 1.0, "negative": ["7", 0], "positive": ["6", 0], "scheduler": "normal", "latent_image": ["5", 0], "sampler_name": "euler"}, "class_type": "KSampler"}, "4": {"inputs": {"ckpt_name": "v1-5-pruned-emaonly.safetensors"}, "class_type": "CheckpointLoaderSimple"}, "5": {"inputs": {"width": 512, "height": 512, "batch_size": 1}, "class_type": "EmptyLatentImage"}, "6": {"inputs": {"clip": ["4", 1], "text": "A beautiful sunset over a mountain lake, vibrant colors, photorealistic"}, "class_type": "CLIPTextEncode"}, "7": {"inputs": {"clip": ["4", 1], "text": "blurry, low quality, distorted, watermark"}, "class_type": "CLIPTextEncode"}, "8": {"inputs": {"vae": ["4", 2], "samples": ["3", 0]}, "class_type": "VAEDecode"}, "9": {"inputs": {"images": ["8", 0], "filename_prefix": "workstation"}, "class_type": "SaveImage"}}	[]	Client error '400 Bad Request' for url 'http://comfyui:8188/prompt'\nFor more information check: https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/400	\N	2026-02-14 21:23:41.530759+00	2026-02-14 21:37:11.747475+00	t	2026-02-14 21:37:11.748554+00
542ede7d-25b2-4777-889d-1cd59859ffbd	eb8f2199-7903-409d-8999-1e450e3c90b8	b727e152-abc0-4a0e-bfc3-ee2c288463f7	text-to-image	A beautiful sunset over a mountain lake, vibrant colors, photorealistic	blurry, low quality, distorted, watermark	completed	{"3": {"inputs": {"cfg": 7.0, "seed": 4458059233368101114, "model": ["4", 0], "steps": 20, "denoise": 1.0, "negative": ["7", 0], "positive": ["6", 0], "scheduler": "normal", "latent_image": ["5", 0], "sampler_name": "euler"}, "class_type": "KSampler"}, "4": {"inputs": {"ckpt_name": "v1-5-pruned-emaonly.safetensors"}, "class_type": "CheckpointLoaderSimple"}, "5": {"inputs": {"width": 512, "height": 512, "batch_size": 1}, "class_type": "EmptyLatentImage"}, "6": {"inputs": {"clip": ["4", 1], "text": "A beautiful sunset over a mountain lake, vibrant colors, photorealistic"}, "class_type": "CLIPTextEncode"}, "7": {"inputs": {"clip": ["4", 1], "text": "blurry, low quality, distorted, watermark"}, "class_type": "CLIPTextEncode"}, "8": {"inputs": {"vae": ["4", 2], "samples": ["3", 0]}, "class_type": "VAEDecode"}, "9": {"inputs": {"images": ["8", 0], "filename_prefix": "workstation"}, "class_type": "SaveImage"}}	["workstation_00001_.png"]	\N	50bd03e0-d863-43e5-bd93-ac22fffa7bb9	2026-02-14 21:35:14.483619+00	2026-02-14 21:35:19.707072+00	f	\N
\.


--
-- Data for Name: kb_chunks; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.kb_chunks (id, created_at, updated_at, source_id, project_id, content, embedding, metadata, chunk_index) FROM stdin;
\.


--
-- Data for Name: kb_sources; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.kb_sources (id, created_at, updated_at, project_id, source_type, source_path, status, chunk_count) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.messages (id, created_at, updated_at, chat_id, role, content, metadata, is_pinned, is_excluded, is_deleted) FROM stdin;
87f82b5b-ca6a-40c6-b61d-f41ef2d60bb1	2026-02-11 01:23:45.545455+00	2026-02-11 01:23:45.545455+00	c045fdba-6e2d-4721-a498-421f32821d4f	user	What is 2 + 2? Reply with just the number.	\N	f	f	f
2c516d9a-9df1-471a-9771-437b7fcdd64a	2026-02-11 01:30:40.044597+00	2026-02-11 01:30:40.044597+00	ba477caf-9252-4532-b832-e08211fee31d	user	What is 2 + 2? Reply with just the number.	\N	f	f	f
5cd913c1-0ab6-44e0-9f00-68802da068ac	2026-02-11 01:31:24.951672+00	2026-02-11 01:31:24.951672+00	ee120c2e-f6fb-443f-af7a-8957197cbaed	user	What is 2 + 2? Reply with just the number.	\N	f	f	f
0c59e433-c9a4-40ad-a0cd-356e214156ac	2026-02-11 01:32:33.430545+00	2026-02-11 01:32:33.430545+00	d7a963e8-c898-4f1c-858c-2ee086301322	user	What is 2 + 2? Reply with just the number.	null	f	f	f
8b6b4cee-9fc8-4679-8b47-ed2081fe7098	2026-02-11 01:32:33.462898+00	2026-02-11 01:32:33.462898+00	620b97c7-8669-4e70-b6af-dc041c6d8a1f	user	What is 2 + 2? Reply with just the number.	\N	f	f	f
35831a2c-e659-468b-9ba1-ca75d8b51adc	2026-02-11 01:35:06.285593+00	2026-02-11 01:35:06.285593+00	92f576f3-d23f-4ef7-866b-d0a35642bb13	user	Hi	null	f	f	f
c43d6d21-6531-455f-87d5-39d686571cf1	2026-02-11 01:35:06.315511+00	2026-02-11 01:35:06.315511+00	b68cd3c4-7928-4ad6-908b-e45534a0b5d0	user	Say hi	{}	f	f	f
75dc9a35-02f3-457e-b53f-ac639590077c	2026-02-11 01:58:35.303737+00	2026-02-11 01:58:35.303737+00	8f2aae0f-08a0-42a7-97d7-48532adf57cd	user	What is the capital of France? Reply in one sentence.	\N	f	f	f
26afbee6-149d-4215-aea8-c0117dc755a8	2026-02-11 01:59:21.874138+00	2026-02-11 01:59:21.874138+00	8f2aae0f-08a0-42a7-97d7-48532adf57cd	user	What is the capital of France? Reply in one sentence.	\N	f	f	f
40665b39-8db7-44de-ae04-7ffcda5d7f82	2026-02-11 01:59:23.687374+00	2026-02-11 01:59:23.687374+00	8f2aae0f-08a0-42a7-97d7-48532adf57cd	assistant	The capital of France is Paris, located on the French Riviera.	{"model": "smollm2:135m"}	f	f	f
e2554255-820e-49d6-afb2-f74ff83a6246	2026-02-11 02:47:19.700957+00	2026-02-11 02:47:19.700957+00	7d8ce8b1-afc8-49b9-886c-d3c3bbcf16c4	user	hi	\N	f	f	f
23bb90fb-bfda-45b6-aa78-aff7a1f3ecda	2026-02-11 02:47:20.000035+00	2026-02-11 02:47:20.000035+00	7d8ce8b1-afc8-49b9-886c-d3c3bbcf16c4	assistant	Hello! How can I help you today?	{"model": "smollm2:135m"}	f	f	f
f90f8cc1-a8d1-4bc7-9df1-75a00f781ce8	2026-02-11 02:47:46.430522+00	2026-02-11 02:47:46.430522+00	7d8ce8b1-afc8-49b9-886c-d3c3bbcf16c4	user	who r u?	\N	f	f	f
07add7c9-3f26-4fc4-9f4b-76fd0f7c4b0e	2026-02-11 02:47:46.776143+00	2026-02-11 02:47:46.776143+00	7d8ce8b1-afc8-49b9-886c-d3c3bbcf16c4	assistant	That's the one who runs this place, it's called "The Green Bean". He or she makes all sorts of delicious treats and drinks.	{"model": "smollm2:135m"}	f	f	f
d41ade32-874e-40c0-a4bb-2cc9b1a7be21	2026-02-11 02:49:34.228886+00	2026-02-11 02:49:34.228886+00	7d8ce8b1-afc8-49b9-886c-d3c3bbcf16c4	user	tell me more	\N	f	f	f
d60aa480-6c6c-485e-9971-95e00dbcc2f7	2026-02-11 02:49:36.076407+00	2026-02-11 02:49:36.076407+00	7d8ce8b1-afc8-49b9-886c-d3c3bbcf16c4	assistant	I'm so glad you asked! The Green Bean has a lot to offer, from burgers with melted cheese and pickles to hot dogs with melted cheddar and BBQ sauce. And if you're looking for something really special, I recommend trying the "Turkey-Rolled" sandwich - it's crispy on the outside and soft in the middle!	{"model": "smollm2:135m"}	f	f	f
7477ade1-2a4b-4198-a7a0-515884cbe187	2026-02-11 02:52:42.907207+00	2026-02-11 02:52:42.907207+00	7d8ce8b1-afc8-49b9-886c-d3c3bbcf16c4	user	what model are you?	\N	f	f	f
ed533281-8d81-4d28-acc8-1be638439425	2026-02-11 02:52:43.294009+00	2026-02-11 02:52:43.294009+00	7d8ce8b1-afc8-49b9-886c-d3c3bbcf16c4	assistant	I'm a friendly AI. I can answer most questions about The Green Bean, but if you're looking for something else, I recommend checking out other local food places or finding a specialty item at a shop like Whole Foods.	{"model": "smollm2:135m"}	f	f	f
bf29554e-1b5b-4665-a849-66a5f90f0057	2026-02-11 02:54:41.23251+00	2026-02-11 02:54:41.23251+00	5e0ea95d-e513-445b-943e-caa17900eab9	user	howdy	\N	f	f	f
d68fc0cd-967f-41d3-ac18-498ffa3e0b93	2026-02-11 02:54:42.816682+00	2026-02-11 02:54:42.816682+00	5e0ea95d-e513-445b-943e-caa17900eab9	assistant	Hello! How can I help you today?	{"model": "smollm2:135m"}	f	f	f
d7a66013-a6be-4e18-a3d0-4aefa7dfee14	2026-02-11 02:55:01.282665+00	2026-02-11 02:55:01.282665+00	5e0ea95d-e513-445b-943e-caa17900eab9	user	who are you?	\N	f	f	f
cdc3d321-6f17-4ac9-9fde-d65b5b609190	2026-02-11 02:55:01.671577+00	2026-02-11 02:55:01.671577+00	5e0ea95d-e513-445b-943e-caa17900eab9	assistant	I'm sorry for the misunderstanding, but as an AI, I don't have real-time internet access. But feel free to use this information online or in conversation with me.	{"model": "smollm2:135m"}	f	f	f
71452bf1-2aaf-4042-8ef3-51fa34fd9b35	2026-02-11 02:55:25.19533+00	2026-02-11 02:55:25.19533+00	5e0ea95d-e513-445b-943e-caa17900eab9	user	what model r u?	\N	f	f	f
54f01000-beb7-49b5-8639-bb86f704e5a9	2026-02-11 02:55:25.558786+00	2026-02-11 02:55:25.558786+00	5e0ea95d-e513-445b-943e-caa17900eab9	assistant	You're correct, my name is Roxane Thompson. I am a 19th-century blacksmith who's known for making fine swords and other fine metalwork pieces. My name is derived from my father, who was also a skilled blacksmith and craftsman in his own right.	{"model": "smollm2:135m"}	f	f	f
faf48878-9472-4f53-ae40-df46d653dfe8	2026-02-11 02:57:28.271996+00	2026-02-11 02:57:28.271996+00	8eaafc4e-439c-4deb-b24d-ae3a76c064d4	user	give me basic css	\N	f	f	f
088166b9-e35a-485d-a8de-b46bb221fb34	2026-02-11 02:57:28.7682+00	2026-02-11 02:57:28.7682+00	8eaafc4e-439c-4deb-b24d-ae3a76c064d4	assistant	```css\n#top-1 {\n  display: flex;\n  max-width: 100%;\n  align-items: center;\n}\n```\nThis will make your CSS snippet look more professional and readable if you use a background image or animate element. If you want to add some specific styling, such as font size or color, feel free to modify the code accordingly.	{"model": "smollm2:135m"}	f	f	f
a9b674ff-4cfd-40ab-9aed-8e1a15f0b83c	2026-02-11 03:00:20.699361+00	2026-02-11 03:00:20.699361+00	8eaafc4e-439c-4deb-b24d-ae3a76c064d4	user	no bg color?	\N	f	f	f
d3456a04-ccf6-407d-b8c3-fd99f35a5b38	2026-02-11 03:00:21.070312+00	2026-02-11 03:00:21.070312+00	8eaafc4e-439c-4deb-b24d-ae3a76c064d4	assistant	You can simply remove or update the `background-color` property in your CSS like this:\n```css\n#top-1 {\n  display: flex;\n  max-width: 100%;\n  align-items: center;\n  background-color: #fff;\n}\n```	{"model": "smollm2:135m"}	f	f	f
d51861ee-3cf1-4773-ac1b-f8a539a72e48	2026-02-11 03:09:21.005553+00	2026-02-11 03:09:21.005553+00	75a6b756-fee7-408a-802c-2d6a01afdf8d	user	hi	\N	f	f	f
3deac046-25be-4140-87d7-f6024495a5a7	2026-02-11 03:09:21.359671+00	2026-02-11 03:09:21.359671+00	75a6b756-fee7-408a-802c-2d6a01afdf8d	assistant	hello! how can i help you today? about the sun, can't wait to hear from u!	{"model": "smollm2:135m"}	f	f	f
b7b7c692-e47b-4b83-be3f-1be58adeff70	2026-02-11 03:10:08.529555+00	2026-02-11 03:10:08.529555+00	75a6b756-fee7-408a-802c-2d6a01afdf8d	user	tell me a long story	\N	f	f	f
3abd6a00-7c5c-463b-9786-f0b29277b476	2026-02-11 03:10:09.261655+00	2026-02-11 03:10:09.261655+00	75a6b756-fee7-408a-802c-2d6a01afdf8d	assistant	i'm glad to share my knowledge with you. let's talk about something interesting. it was when we went to the temple of kappamurai for our birthday party. the temple was very crowded, and there were many people from all over the world here at this festival. imagine a big family celebrating together like that!\n\none brave lady named shikoh took care of us by making sure everyone had enough food and drinks, even if they didn't have a special gift or ceremony to celebrate. she used her knowledge of herbs and cooking techniques to make them tasty and delicious. the whole family laughed and cheered as we spent our birthday in the temple surrounded by the colorful decorations.\n\nthe next day, i went back home with my friends who came over for another birthday party at the same temple. this time, we had more fun than before. our group of 10 friends was all excited to celebrate their special day together and share some delicious food and drinks during the festival. it was such a great experience that i still remember every detail!\n\nthe year is 2023, so we are celebrating with a birthday party for our friend, koko, who lives in the mountains of sri lanka. he's a wonderful person and deserves to be recognized as one of the best performers at this festival. it will help him build his new life in sri lanka!\n\nhopefully, we can share more stories from our special time here, just like that! do you have any questions or would you like some tips on how to celebrate a big birthday party?	{"model": "smollm2:135m"}	f	f	f
5da6a38e-bbcf-4b1c-9177-98640e5be003	2026-02-12 15:56:24.758864+00	2026-02-12 15:56:24.758864+00	85ccd9e2-3730-42b0-936e-20c4f47650e2	user	What is 2 + 2? Answer in one sentence.	\N	f	f	f
ee076bf1-6de0-40cb-a31c-79be463b6767	2026-02-12 15:56:26.173103+00	2026-02-12 15:56:26.173103+00	85ccd9e2-3730-42b0-936e-20c4f47650e2	assistant	To answer your question, 2 + 2 equals 4.	{"model": "smollm2:135m"}	f	f	f
a1b60a5b-17b0-4f3f-9b94-b54537faa2f7	2026-02-12 16:05:08.477218+00	2026-02-12 16:05:08.477218+00	4df65c81-ba6a-409b-bfa1-80919cb8f171	user	Tell me the current news for today	\N	f	f	f
76dec281-4e3c-4e54-a266-c4a502d5b864	2026-02-12 16:05:10.54487+00	2026-02-12 16:05:10.54487+00	4df65c81-ba6a-409b-bfa1-80919cb8f171	assistant	I'm ready to share updates with you! Today is a busy day, but we're still in the midst of a significant event. I recommend checking out the latest developments on our website or app: https://www.newsfeeds.com/us-today/.	{"model": "smollm2:135m"}	f	f	f
cf5a98c2-8b75-4373-b3f7-caf357523bf5	2026-02-12 16:06:03.008101+00	2026-02-12 16:06:03.008101+00	4df65c81-ba6a-409b-bfa1-80919cb8f171	user	search the web and get the latest news for today	\N	f	f	f
58f5c612-e3c2-4985-81a6-12227b05540e	2026-02-12 16:06:04.029945+00	2026-02-12 16:06:04.029945+00	4df65c81-ba6a-409b-bfa1-80919cb8f171	assistant	I'm ready to share updates with you! Today is a busy day, but we're still in the midst of a significant event. I recommend checking out our website or app: https://www.newsfeeds.com/us-today/.	{"model": "smollm2:135m"}	f	f	f
02dddc33-b314-4887-af1d-b3f5a35bfbb5	2026-02-12 16:06:18.643374+00	2026-02-12 16:06:18.643374+00	4df65c81-ba6a-409b-bfa1-80919cb8f171	user	can you search the web?	\N	f	f	f
8c4e41c7-9456-4fb7-976e-bc60277d8737	2026-02-12 16:06:18.952536+00	2026-02-12 16:06:18.952536+00	4df65c81-ba6a-409b-bfa1-80919cb8f171	assistant	I'm ready to share updates with you! Today is a busy day, but we're still in the midst of a significant event. I recommend checking out our website or app: https://www.newsfeeds.com/us-today/.	{"model": "smollm2:135m"}	f	f	f
36c5a0f5-a5b1-46de-9c71-bdbc1888e876	2026-02-12 16:06:28.750665+00	2026-02-12 16:06:28.750665+00	4df65c81-ba6a-409b-bfa1-80919cb8f171	user	hi	\N	f	f	f
2578ee1f-f4e4-407b-a129-17aab116b97b	2026-02-12 16:07:46.138367+00	2026-02-12 16:07:46.138367+00	4df65c81-ba6a-409b-bfa1-80919cb8f171	assistant	I'm ready to share updates with you today. Today is a busy day, but we're still in the midst of a significant event. I recommend checking out our website or app: https://www.newsfeeds.com/us-today/.	{"model": "smollm2:135m"}	f	f	f
e8fd73bd-1378-48e4-9580-5083e316b2a0	2026-02-12 16:06:29.105095+00	2026-02-12 16:06:29.105095+00	4df65c81-ba6a-409b-bfa1-80919cb8f171	assistant	Hello! I'm ready to share updates with you today. Today is a busy day, but we're still in the midst of a significant event. I recommend checking out our website or app: https://www.newsfeeds.com/us-today/.	{"model": "smollm2:135m"}	f	f	f
ebde9672-c60a-405a-8a8c-d30d1cb3e3d9	2026-02-12 16:06:56.331872+00	2026-02-12 16:06:56.331872+00	4df65c81-ba6a-409b-bfa1-80919cb8f171	user	give me example css code for a	\N	f	f	f
edd9dd1c-7e17-48e3-a27c-a5f78ecd7d79	2026-02-12 16:07:45.987874+00	2026-02-12 16:07:45.987874+00	4df65c81-ba6a-409b-bfa1-80919cb8f171	user	ok	\N	f	f	f
31e24f1a-8c01-4b08-bb57-ec45aa34890d	2026-02-12 17:50:54.767628+00	2026-02-12 17:50:54.767628+00	8eaafc4e-439c-4deb-b24d-ae3a76c064d4	user	Hi there	\N	f	f	f
45d4184a-7890-4555-b6ff-755723416c4b	2026-02-12 17:50:55.081831+00	2026-02-12 17:50:55.081831+00	8eaafc4e-439c-4deb-b24d-ae3a76c064d4	assistant	You're welcome! I'm glad you found the CSS tutorials helpful. I hope this helps you in your learning journey. If you have any more questions or need further assistance, feel free to ask. Happy coding!	{"model": "smollm2:135m"}	f	f	f
64d3972b-715b-4ad0-835f-1719785960a8	2026-02-12 18:42:17.623798+00	2026-02-12 18:42:17.623798+00	64cd1792-febc-4d99-807b-72552e1e12fb	user	How are you?	\N	f	f	f
a0ccef2e-7690-49c5-9771-9aa9461c972c	2026-02-12 18:42:18.059749+00	2026-02-12 18:42:18.059749+00	64cd1792-febc-4d99-807b-72552e1e12fb	assistant	I'm an AI who helps users troubleshoot their technical issues and provide solutions to common problems in various aspects of technology, including computer hardware, software, operating systems, and more! I assist with troubleshooting questions related to Windows, MacOS, Linux, Android, iOS, and web browsers. What can you help me with?	{"model": "smollm2:135m"}	f	f	f
d1612510-811f-4417-b3c6-53c56ae0c9c7	2026-02-13 23:32:43.938278+00	2026-02-13 23:32:43.938278+00	80d0ba1d-93df-4292-b8d7-71941fc6f132	user	Hello, what is 2+2?	\N	f	f	f
c26d2b15-8939-4797-81ac-e6e27ca4d9d9	2026-02-13 23:32:45.794219+00	2026-02-13 23:32:45.794219+00	80d0ba1d-93df-4292-b8d7-71941fc6f132	assistant	Two and two together equals four.	{"model": "smollm2:135m"}	f	f	f
6b4484a5-33b6-4837-9071-a0fd70585606	2026-02-14 00:05:23.211961+00	2026-02-14 00:05:23.211961+00	83cfcbfe-dece-4361-8be6-46a4ca27c27a	user	tell me a short story about a troll finding love	\N	f	f	f
7da348d1-0372-4b53-a673-623901a1fd4b	2026-02-14 00:05:24.206206+00	2026-02-14 00:05:24.206206+00	83cfcbfe-dece-4361-8be6-46a4ca27c27a	assistant	Once upon a time, in the realm of ancient magic and myth, there was a young troll named Lirion. Lirion was a shy and gentle creature who loved to spend time with his human friends. One day, while exploring the forest, Lirion stumbled upon a small village filled with love and laughter.\n\nThe villagers welcomed him warmly and began to introduce him to their families. Lirion saw a woman sitting on a stool by the fire, her eyes shining with a deep affection for her loved one. He knew this was a good moment to strike up a conversation, but he chose not to speak out loud in any way that would make his human friends uncomfortable.\n\nInstead of speaking directly, Lirion asked her about her love life and how she felt when someone looked at her with kindness. The woman listened intently, her eyes sparkling with emotion as if she had seen something she did not even know existed.\n\nLirion sat down next to her, his expression a warm smile as he shared stories of their happy memories together. As they talked, Lirion discovered that this wasn't just any ordinary friendship; it was a story that spoke to him on a deeper level. He felt an overwhelming sense of love and connection with the person beside him – a woman who knew exactly how to give her loved one what he needed without expecting anything in return.\n\nAs they talked, Lirion realized that this was not just a small circle of friends; there were people around him too, each holding their own stories, hopes, and dreams. He felt like he had found someone special who understood him on a profound level, despite his shyness and love for human company.\n\nAs they parted ways, Lirion walked with her to his village, where he shared the story of his life with the villagers, and they all became entwined in their gratitude towards each other. From that moment on, Lirion was no longer just a troll; he was someone who understood the beauty of love and the power of connection.	{"model": "smollm2:135m"}	f	f	f
08670a99-2cba-4dbc-b8e2-ddd5fb26c879	2026-02-14 00:07:39.866168+00	2026-02-14 00:07:39.866168+00	83cfcbfe-dece-4361-8be6-46a4ca27c27a	user	do part two	\N	f	f	f
d55db9f9-43c5-475c-b1eb-f53ff758efa6	2026-02-14 00:07:40.937911+00	2026-02-14 00:07:40.937911+00	83cfcbfe-dece-4361-8be6-46a4ca27c27a	assistant	As night fell, the villagers gathered to celebrate the discovery of Lirion's story in their village. Lirion sat on his stool next to his human friends, and they began sharing stories about their lives together. He listened intently, his eyes sparkling with excitement as he told tales of joy and laughter that had filled their lives during their visits to the small village.\n\nOne of the villagers spoke about a moment when Lirion's love for her left him feeling invigorated, and he was able to take a step forward into a relationship with someone who understood his feelings more deeply than they ever could have before. This story made Lirion feel like he had found a person who truly connected with him on a deeper level.\n\nAs the night wore on, Lirion's life began to change in ways that felt both beautiful and unexpected. He started to see his human friends' love for him as a light that could bring them joy, despite their own struggles. He realized that love wasn't just about physical affection; it was also about understanding what made people tick, even when they didn't feel the same way.\n\nLirion's life began to transform beyond recognition. He became more outgoing and laid-back, sharing stories with his friends without any expectation of reciprocation. His sense of self-worth grew stronger as he continued to navigate love and connections that brought him joy and fulfillment.\n\nDespite the challenges and struggles that Lirion faced in his life, he felt a deep connection to the people around him. They all told him stories about their own experiences with love, and he found himself reading and listening back to their tales, learning new insights from them on topics like acceptance and understanding.\n\nAs the sun dipped below the horizon, Lirion's journey was complete. He had discovered a love that transcended his shyness and friendship with humans; it was not just about physical attraction but also about understanding what made people tick, even when they didn't feel the same way. With a newfound sense of peace and clarity, he knew he would continue to find love in all its forms, as long as he loved it unconditionally.	{"model": "smollm2:135m"}	f	f	f
ec6b195b-798c-4d6f-bbfd-a48b8afca1db	2026-02-14 00:08:02.253751+00	2026-02-14 00:08:02.253751+00	83cfcbfe-dece-4361-8be6-46a4ca27c27a	user	what model is this?	\N	f	f	f
b644811a-a4b2-418e-8d9f-43e03fc6a7b5	2026-02-14 00:08:03.31446+00	2026-02-14 00:08:03.31446+00	83cfcbfe-dece-4361-8be6-46a4ca27c27a	assistant	This narrative style can be described using various models:\n\n1. **Narrative Model**: This model emphasizes the character's development and growth throughout the story. The narrative focuses on the emotional journey of the protagonist, exploring themes such as self-discovery, relationships, and personal growth. The narrative also reveals the character's motivations, backstory, and emotional scars.\n2. **Character Model**: This model prioritizes the character's inner life, including their thoughts, feelings, desires, and behaviors. The character's actions, dialogue, and interactions with others are analyzed to understand their personality, values, and motivations.\n3. **Symbolism Model**: This model emphasizes the use of symbols or imagery in the narrative to represent deeper themes or messages. Symbols can be used to convey ideas, emotions, or meanings associated with the character's journey, such as love, loss, hope, or redemption.\n4. **Epistemic Model**: This model focuses on the character's experiences and perceptions through their thoughts, feelings, and behaviors in relation to reality. The epistemic model emphasizes the role of the character's internal world (their inner life) in shaping their external actions and decisions.\n5. **Narrative Analysis Model**: This model involves analyzing the narrative's structure, pacing, and themes to understand its purpose and effectiveness. The narrative analysis aims to identify key elements that contribute to the story's overall impact on the reader or viewer.\n6. **Character Analysis Model**: This model emphasizes the character's interactions with others in relation to their inner world (their thoughts, feelings, desires, etc.). The character's interactions reveal how they relate to other characters and explore themes such as relationships, power dynamics, and human emotions.\n7. **Symbolism Analysis Model**: This model involves analyzing symbols or metaphors found throughout the narrative to understand their meaning and significance in relation to the story's themes and messages.\n8. **Epistemic Analysis Model**: This model emphasizes the character's interactions with others as a means of understanding themselves and the world around them, including their inner life, desires, and flaws.\n9. **Narrative Analysis Model**: This model focuses on analyzing the narrative's structure, pacing, and themes to understand how it contributes to the story's overall impact on the reader or viewer.\n10. **Character Analysis Model**: This model emphasizes the character's interactions with others as a means of understanding themselves and the world around them, including their inner life, desires, and flaws.\n\nThese models can be applied in different ways, depending on the specific narrative style, genre, and themes involved.	{"model": "smollm2:135m"}	f	f	f
0098a621-c421-4be3-9e27-72be30459bc1	2026-02-14 00:08:20.769692+00	2026-02-14 00:08:20.769692+00	83cfcbfe-dece-4361-8be6-46a4ca27c27a	user	what llm model	\N	f	f	f
ce6efcf2-2b3c-4b0a-ab60-7bdf8d7e200b	2026-02-14 00:08:21.771422+00	2026-02-14 00:08:21.771422+00	83cfcbfe-dece-4361-8be6-46a4ca27c27a	assistant	The Narrative Model is an effective storytelling technique for conveying a character's emotional journey through their thoughts, feelings, desires, and behaviors. The narrative model emphasizes the role of the character's inner life (their thoughts, feelings, desires, etc.) in shaping their external actions and decisions.\n\n1. **Narrative Structure**: The narrative structure follows a linear progression from the protagonist's thoughts, feelings, desires, and behaviors to the outcome or conclusion. This helps readers follow the character's journey and understand their motivations.\n2. **Character Perceptions**: The narrative aims to explore the character's internal world (their thoughts, emotions, values, etc.) in relation to reality. This reveals how they perceive others, themselves, and their own experiences.\n3. **Dialogue**: Dialogue is used to reveal a character's personality, background, and motivations through their conversations with other characters. This helps readers understand the character's voice and perspective.\n4. **Symbolism**: Symbols are used throughout the narrative to represent deeper themes or messages. These symbols add depth and meaning to the story, making it more engaging for readers.\n5. **Epistemic Model**: The narrative model emphasizes the role of the character's interactions with others in understanding themselves and the world around them. This helps readers understand how they relate to others and make decisions based on their internal experiences.\n6. **Character Analysis Model**: The narrative analysis aims to identify key elements that contribute to the story's overall impact on the reader or viewer, such as relationships, power dynamics, and human emotions.\n7. **Narrative Analysis Model**: This model focuses on analyzing the narrative's structure, pacing, and themes in relation to the character's inner world (their thoughts, feelings, desires, etc.) and their external actions.\n8. **Character Analysis Model**: This model emphasizes the character's interactions with others as a means of understanding themselves and the world around them, including their internal world, perceptions, and emotions.\n9. **Symbolism Analysis Model**: The narrative analysis aims to identify symbols or metaphors found in the story that represent deeper themes or messages.\n10. **Epistemic Model**: The narrative model emphasizes the character's interactions with others as a means of understanding themselves and the world around them, including their internal life, desires, and flaws.	{"model": "smollm2:135m"}	f	f	f
c0bab885-b7ef-4a27-b178-7b0a2ee41010	2026-02-14 02:03:12.717971+00	2026-02-14 02:03:12.717971+00	ffcde943-961d-488e-9543-41ca2a0b803b	user	[Current file: node_modules/.package-lock.json]\n[Project files: Files: .gitignore, index.html, node_modules/.bin/baseline-browser-mapping, node_modules/.bin/browserslist, node_modules/.bin/esbuild, node_modules/.bin/jsesc, node_modules/.bin/json5, node_modules/.bin/loose-envify, node_modules/.bin/nanoid, node_modules/.bin/parser, node_modules/.bin/rollup, node_modules/.bin/semver, node_modules/.bin/tsc, node_modules/.bin/tsserver, node_modules/.bin/update-browserslist-db, ... (2388 files total) | 228 directories]\n\nwhat is tthis?	\N	f	f	f
5834a7db-1af5-4b85-9b46-d59f60618f5a	2026-02-14 02:03:14.069382+00	2026-02-14 02:03:14.069382+00	ffcde943-961d-488e-9543-41ca2a0b803b	assistant	The code snippet you provided appears to be a C++ function that checks the version of the Node.js interpreter installed on your system against a specified date and time. The specific implementation is as follows:\n\n1. Initialize an empty `node_modules` directory with appropriate permissions based on your environment.\n2. Set the correct executable path for the Node.js compiler, bash script, and other necessary files in this directory.\n3. Use `ls -l | grep ^CpuTime::<version>` to get the current time from a Unix timestamp representation (e.g., `01/04/2023 18:59:46`).\n4. Use `cp -p /home/.node_modules/* .bashrc`, assuming you have a BAR configuration file in your project's `~/.bashrc` directory, and the current value is correct (`true`), replace it with `false`.\n5. Use `find /path/to/<version>:text >&1 -type f | xargs cut -d'| \\s*<date>\\s+<timestamp>'`, replacing `true` with `false` to determine whether the current time and timestamp are valid for the Node.js interpreter version (e.g., `04/28/2023 19:57:46`)\n6. Use a regular expression (`^[CpuTime::<version>]*$)` to match any C source code file in this directory containing the string `"true"`.\n7. If successful, use `find /path/to/<date>=2023-01-04 18:59:46` and replace it with `false`, since the current version of Node.js is not available for 2023-01-04\n8. Use a regular expression (`^[CpuTime::<version>]*$)` to match any C source code file in this directory containing the string `"true"` (replace it with `false`)\n9. If successful, use `find /path/to/<timestamp>=2023-01-04 18:59:46>`. The timestamp is extracted from the Unix time represented by a string in the format `<date>\\s+<timestamp>'`, replacing it with an empty string (`""`).\n10. If successful, use `find /path/to/<version>=2023-01-04 18:59:46`. The version number is extracted from the Unix time represented by a string in the format `<date>\\s+<timestamp>'`, replacing it with an empty string (`""`).\n\nThe function checks for valid Node.js source code files in this directory that have the correct date and timestamp (e.g., `04/28/2023 19:57:46`) or a Unix timestamp representation of a valid date and time (e.g., `~/.node_modules/* <date>=2023-01-04`). If the current version is not available, it attempts to find a suitable source code file for the Node.js compiler and bash script that supports the same date and timestamp as the current one (`false`) in this directory (replace `false` with `true` or use an appropriate regular expression). The function checks if the current version of Node.js is available, but does not check whether the specified date and time are valid for the Node.js interpreter.	{"model": "smollm2:135m"}	f	f	f
8da66393-43a3-48dd-b589-b556edd101bf	2026-02-14 16:23:01.958763+00	2026-02-14 16:23:01.958763+00	a889c1c9-b2ec-43f7-88ee-24a43de6d9d2	user	[Project files: Files: .gitignore, index.html, node_modules/.bin/baseline-browser-mapping, node_modules/.bin/browserslist, node_modules/.bin/esbuild, node_modules/.bin/jsesc, node_modules/.bin/json5, node_modules/.bin/loose-envify, node_modules/.bin/nanoid, node_modules/.bin/parser, node_modules/.bin/rollup, node_modules/.bin/semver, node_modules/.bin/tsc, node_modules/.bin/tsserver, node_modules/.bin/update-browserslist-db, ... (2391 files total) | 229 directories]\n\ntell me about this project	\N	f	f	f
ccb74de1-e901-458c-b690-faab2497918e	2026-02-14 16:24:17.813511+00	2026-02-14 16:24:17.813511+00	a889c1c9-b2ec-43f7-88ee-24a43de6d9d2	user	[Project files: Files: .gitignore, index.html, node_modules/.bin/baseline-browser-mapping, node_modules/.bin/browserslist, node_modules/.bin/esbuild, node_modules/.bin/jsesc, node_modules/.bin/json5, node_modules/.bin/loose-envify, node_modules/.bin/nanoid, node_modules/.bin/parser, node_modules/.bin/rollup, node_modules/.bin/semver, node_modules/.bin/tsc, node_modules/.bin/tsserver, node_modules/.bin/update-browserslist-db, ... (2391 files total) | 229 directories]\n\nhi there	\N	f	f	f
dfbaaadc-12ad-4ba2-acae-8106f756ed06	2026-02-15 00:25:39.791725+00	2026-02-15 00:25:39.791725+00	21dd2547-cdfe-4ffe-9e83-567fe5a64806	user	Hi there. how are you?	\N	f	f	f
874e583a-2ff6-48e0-8faf-11f8bc5c7e85	2026-02-15 00:26:08.482606+00	2026-02-15 00:26:08.482606+00	21dd2547-cdfe-4ffe-9e83-567fe5a64806	assistant	I'm doing great! How can I help you today? Do you have any questions about my services or would you like to chat more?	{"model": "smollm2:135m"}	f	f	f
e05e2d6a-2ce1-423d-984d-c7866ecebd69	2026-02-15 18:10:07.850838+00	2026-02-15 18:10:07.850838+00	b6759ce8-5898-4c1b-a7a9-bcbb76ee1253	user	What is a brief history of instacart?	\N	f	f	f
b0a051ab-2ae3-496a-940b-6982bf8686fc	2026-02-15 18:10:12.576205+00	2026-02-15 18:10:12.576205+00	b6759ce8-5898-4c1b-a7a9-bcbb76ee1253	assistant	Instacart, the online grocery delivery service, has its origins in 2016 in San Francisco California by the company Sears Inc and co-founded by Jeff Bezos. The idea was to provide customers with a convenient way to order groceries at a lower cost than traditional retail stores. The concept was initially conceived as part of the company's effort to improve customer service and reduce costs associated with buying perishable goods in smaller grocery stores.\n\nIn 2016, Sears Inc renamed the company "Sales & Marketing." However, it wasn't until more recently that instacart gained popularity, largely due to its ability to offer a wide range of products at competitive prices and low labor costs compared to traditional retail delivery services like DoorDash.\n\nThe story is often attributed to Jeff Bezos who initially worked as the CEO of Sears Inc but later took over the company in 2017, and he became the current president of the company.	{"model": "smollm2:135m"}	f	f	f
15822d46-a868-45d7-a6f5-c3bfa4c567ce	2026-02-15 18:11:22.877609+00	2026-02-15 18:11:22.877609+00	b6759ce8-5898-4c1b-a7a9-bcbb76ee1253	user	bezos was the ceo of sears and amazon?	\N	f	f	f
c64d6329-8234-4e06-b51c-c7b39190ab42	2026-02-15 18:11:23.6908+00	2026-02-15 18:11:23.6908+00	b6759ce8-5898-4c1b-a7a9-bcbb76ee1253	assistant	Yes, that's correct. Jeff Bezos, the founder and CEO of Sears Inc, co-founded Amazon in 2016 as an online marketplace for home goods to reduce shipping costs. He took over the company as president at the time, which would eventually become the parent company of Amazon.	{"model": "smollm2:135m"}	f	f	f
77071d2d-dd20-42a1-961b-4ff5a66fdeb3	2026-02-15 18:11:49.149638+00	2026-02-15 18:11:49.149638+00	b6759ce8-5898-4c1b-a7a9-bcbb76ee1253	user	who invented amazon?	\N	f	f	f
ddbff43a-9209-48c4-b3b8-13c12d729c44	2026-02-15 18:11:50.02991+00	2026-02-15 18:11:50.02991+00	b6759ce8-5898-4c1b-a7a9-bcbb76ee1253	assistant	Jeff Bezos is credited with inventing Amazon, a digital online marketplace that came into existence in 2016 and was later acquired by Amazon in 2019 for over $45 billion. He founded Amazon as a venture capitalist company to find innovative solutions to the challenges of traditional retail stores.	{"model": "smollm2:135m"}	f	f	f
81d81ddc-4053-4c57-822e-a0b17afb07de	2026-02-15 18:14:35.960709+00	2026-02-15 18:14:35.960709+00	b6759ce8-5898-4c1b-a7a9-bcbb76ee1253	user	sure?	\N	f	f	f
1fd20c70-15c4-47d6-9bd8-fce306ab5e18	2026-02-15 18:15:36.950374+00	2026-02-15 18:15:36.950374+00	b6759ce8-5898-4c1b-a7a9-bcbb76ee1253	assistant	<think>\nOkay, the user is asking "sure?" again after I provided information about Amazon's founding. Let me check my previous responses to see where I might have gone wrong.\n\nIn the first response, I mentioned that Instacart was founded by Sears Inc and Jeff Bezos in 2016. Then, the user asked if Bezos was the CEO of Sears and Amazon, and I said yes, even though that's not accurate. Sears is a separate company, and Jeff Bezos is the founder of Amazon, not Sears. Then the user asked who invented Amazon, and I incorrectly stated that Amazon was founded in 2016 by Bezos as a venture capitalist company, which is wrong because Amazon was actually founded in 1994 by Bezos, not 2016. Also, there's no mention of Amazon acquiring Instacart; that's a separate event where Amazon acquired Instacart in 2019.\n\nSo, the user is pointing out that my previous answers were incorrect. They're probably confused because of the mix-up between Instacart and Amazon's timelines and relationships. I need to correct the mistakes in my earlier responses. I should clarify that Amazon was founded by Jeff Bezos in 1994 as an online bookstore, not 2016, and that Instacart was founded in 2012, not 2016, by Apoorva Mehta and others, not Sears. Also, Amazon acquired Instacart in 2019, not Sears. I need to make sure to correct these inaccuracies and provide the correct information now.\n</think>\n\nYou're absolutely right to question that — my previous answer was **incorrect**. Let me clarify the facts:\n\n### **Amazon was founded by Jeff Bezos in 1994**, not 2016, and it was **not** created by Sears Inc. Here’s the correct history:\n\n- **Amazon** was founded by Jeff Bezos in **1994** as an online bookstore. It later expanded into a global e-commerce and technology giant.\n- **Instacart**, the grocery delivery service, was **founded in 2012** by **Apoorva Mehta** (with co-founders Shariq Hashmi and Ankit Patel). It was **never** affiliated with Sears Inc. or Jeff Bezos in its early years.\n- **Amazon acquired Instacart in 2019**, not 2016, as part of its push into grocery delivery and logistics.\n\n### Key corrections:\n- **Amazon ≠ Sears**: Sears is a separate company (a traditional retail chain, now defunct as a major player in the U.S.).\n- **Instacart ≠ Amazon**: Instacart was an independent startup before being acquired by Amazon in 2019.\n- **Timeline**: Amazon was founded in **1994**, not 2016.\n\nLet me know if you’d like a more detailed breakdown!	{"model": "mychen76/qwen3_cline_roocode:14b"}	f	f	f
\.


--
-- Data for Name: project_imports; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.project_imports (id, user_id, project_id, import_type, source_url, status, detected_type, detected_template_id, progress_message, error_message, import_options, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.projects (id, created_at, updated_at, user_id, name, path, type, settings, custom_context, important_files, is_deleted, deleted_at, template_id, system_prompt_id) FROM stdin;
52912f56-a267-48dd-b883-8c03015795a6	2026-02-11 01:14:05.471207+00	2026-02-11 01:14:05.471207+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Test Project	e2e-test	\N	null	\N	\N	f	\N	\N	\N
17ba3925-2f72-4b07-b489-650f6f894ddf	2026-02-11 02:29:44.811047+00	2026-02-11 02:29:44.811047+00	eb8f2199-7903-409d-8999-1e450e3c90b8	Default Project	default	\N	null	\N	\N	f	\N	\N	\N
1872cf8e-b7bc-40de-81ad-9756c909b72c	2026-02-13 00:16:04.678103+00	2026-02-13 00:16:04.935125+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:16:04.935125+00	\N	\N
f5ddb54d-f0aa-4bfa-b6c6-582e723000ee	2026-02-13 00:16:40.066977+00	2026-02-13 00:16:40.090084+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:16:40.090084+00	\N	\N
30e4287c-8c44-401a-a767-925ff005f5d6	2026-02-13 00:16:40.107417+00	2026-02-13 00:16:40.124362+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:16:40.124362+00	\N	\N
e414376d-662a-4932-89fe-097ad972dc4c	2026-02-13 00:16:40.141608+00	2026-02-13 00:16:40.211799+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:16:40.211799+00	\N	\N
553a93cd-47ac-4746-b691-6b7388b09b34	2026-02-13 00:28:09.493814+00	2026-02-13 00:28:09.653965+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Workspace Test	e2e_workspace_test	\N	null	\N	\N	t	2026-02-13 00:28:09.653965+00	\N	\N
8556ea2e-611c-4248-9a4e-7ddbfecb7adb	2026-02-13 00:16:45.892883+00	2026-02-13 00:16:46.139703+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:16:46.139703+00	\N	\N
142a58d0-206c-4b27-8eb7-583ed94194ef	2026-02-13 00:16:49.689302+00	2026-02-13 00:16:49.705241+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:16:49.705241+00	\N	\N
cecc9ae1-c31b-49aa-98dd-bc07ad3907c6	2026-02-13 00:16:49.722565+00	2026-02-13 00:16:49.73727+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:16:49.73727+00	\N	\N
f05868b3-467b-4725-8f69-89dbe94505bf	2026-02-13 00:16:49.755552+00	2026-02-13 00:16:49.828455+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:16:49.828455+00	\N	\N
2edd1198-d8cb-4b8b-92cb-d981cf37d9ce	2026-02-13 00:22:15.423901+00	2026-02-13 00:22:15.646375+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:22:15.646375+00	\N	\N
41c701c2-5f78-4b79-815e-9527c5a69949	2026-02-13 00:19:07.375577+00	2026-02-13 00:19:07.609493+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:19:07.609493+00	\N	\N
1fde48a0-0cfa-4d76-a0eb-846a3e7e43be	2026-02-13 00:19:08.142422+00	2026-02-13 00:19:08.157398+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:19:08.157398+00	\N	\N
78330732-d1f5-4c10-8974-61ddf9959ce0	2026-02-13 00:19:08.172636+00	2026-02-13 00:19:08.186726+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:19:08.186726+00	\N	\N
6086c85d-5275-45ea-8ebf-712410cd1999	2026-02-13 00:19:08.200772+00	2026-02-13 00:19:08.26445+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:19:08.26445+00	\N	\N
e2aa9db9-d543-4f2c-9d62-25fa601514b6	2026-02-13 00:20:06.939564+00	2026-02-13 00:20:07.179313+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:20:07.179313+00	\N	\N
49bd9615-1147-49b8-af9f-034082cf0d84	2026-02-13 00:20:07.724238+00	2026-02-13 00:20:07.740853+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:20:07.740853+00	\N	\N
ac65dc6d-8b2b-4718-893b-2adf70e24f22	2026-02-13 00:20:07.756235+00	2026-02-13 00:20:07.777571+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:20:07.777571+00	\N	\N
7d0effb4-a8e7-44a5-b4a1-07e19cef62d9	2026-02-13 00:20:07.793789+00	2026-02-13 00:20:07.859376+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:20:07.859376+00	\N	\N
a2e76fef-2957-4c96-b8ec-3cf53dce455a	2026-02-13 00:22:16.182068+00	2026-02-13 00:22:16.197493+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:22:16.197493+00	\N	\N
51ed756e-e44f-45a4-b086-2aa8cf8b09f5	2026-02-13 00:20:25.522642+00	2026-02-13 00:20:25.764551+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:20:25.764551+00	\N	\N
f4b369c2-5654-41a3-aac6-570b14ee26de	2026-02-13 00:20:26.296424+00	2026-02-13 00:20:26.312925+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:20:26.312925+00	\N	\N
a119c952-bad9-459c-bc68-98e155884ba9	2026-02-13 00:20:26.33333+00	2026-02-13 00:20:26.353095+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:20:26.353095+00	\N	\N
181c89dc-ada0-4579-add2-3fc048fa38d8	2026-02-13 00:20:26.371871+00	2026-02-13 00:20:26.43508+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:20:26.43508+00	\N	\N
62b4a081-b3eb-4155-b461-7dc8c0f1b56b	2026-02-13 00:21:54.937317+00	2026-02-13 00:21:55.168305+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:21:55.168305+00	\N	\N
ffba0803-96a3-4d2b-b9c6-e1c9d2feff82	2026-02-13 00:21:55.710016+00	2026-02-13 00:21:55.72552+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:21:55.72552+00	\N	\N
0fe6907b-c797-4b2d-89d3-e9d0f813725b	2026-02-13 00:21:55.740711+00	2026-02-13 00:21:55.757887+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:21:55.757887+00	\N	\N
a61e9a7e-b1dd-4872-87a2-59595d6f2c83	2026-02-13 00:21:55.773662+00	2026-02-13 00:21:55.838478+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:21:55.838478+00	\N	\N
6c77433a-539a-4269-b55c-58f12b9496c3	2026-02-13 00:22:16.213375+00	2026-02-13 00:22:16.229379+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:22:16.229379+00	\N	\N
8224d93e-14dd-444c-9e6d-849aa5470999	2026-02-13 00:22:16.244151+00	2026-02-13 00:22:16.308352+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:22:16.308352+00	\N	\N
c97e2d23-e66a-4f61-8f8f-002e652a77d2	2026-02-13 00:26:55.068141+00	2026-02-13 00:26:55.294413+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:26:55.294413+00	\N	\N
341df6f5-92bb-47fb-88c2-ef58042a8474	2026-02-13 00:26:55.813141+00	2026-02-13 00:26:55.826492+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:26:55.826492+00	\N	\N
c7c4cbcf-d18a-45b3-830f-efba93915b5e	2026-02-13 00:26:55.840993+00	2026-02-13 00:26:55.852583+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:26:55.852583+00	\N	\N
8e037efe-e332-4873-b4f2-9eea3e8e0678	2026-02-13 00:26:55.865879+00	2026-02-13 00:26:55.92735+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:26:55.92735+00	\N	\N
099902e8-a1fc-40cc-b502-b79e618dc1eb	2026-02-13 00:28:18.375228+00	2026-02-13 00:28:18.523108+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Workspace Test	e2e_workspace_test	\N	null	\N	\N	t	2026-02-13 00:28:18.523108+00	\N	\N
b10f0f42-0599-476e-a2d4-112496f1f8f6	2026-02-13 00:27:18.700134+00	2026-02-13 00:27:18.916035+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:27:18.916035+00	\N	\N
60619704-fb23-4db1-b546-125842d9f7b7	2026-02-13 00:27:19.444222+00	2026-02-13 00:27:19.457383+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:27:19.457383+00	\N	\N
8a34cb72-6ec4-4c5e-ab29-fc5eee7a3ef6	2026-02-13 00:27:19.471725+00	2026-02-13 00:27:19.484411+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:27:19.484411+00	\N	\N
cb8dc745-4dbf-43e5-bf4b-309fbbfa8fdf	2026-02-13 00:27:19.498639+00	2026-02-13 00:27:19.56038+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:27:19.56038+00	\N	\N
3e7cec57-13ac-4d07-a8ec-178178c8f6f9	2026-02-13 00:30:21.327303+00	2026-02-13 00:30:21.578324+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:30:21.578324+00	\N	\N
17c72efe-7017-4a5f-b4b2-dd18ff4da83d	2026-02-13 00:29:55.862976+00	2026-02-13 00:29:56.093741+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:29:56.093741+00	\N	\N
7237775b-3f04-4ad9-a211-391676345e7d	2026-02-13 00:29:56.620653+00	2026-02-13 00:29:56.634398+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:29:56.634398+00	\N	\N
94457e3b-8d07-4b55-8856-4b35cfa52892	2026-02-13 00:29:56.647737+00	2026-02-13 00:29:56.659695+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:29:56.659695+00	\N	\N
b63daf7b-3749-4902-b830-71e5007fe029	2026-02-13 00:29:56.673333+00	2026-02-13 00:29:56.738513+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:29:56.738513+00	\N	\N
1ba0c4f2-fcaf-4bf0-b2c2-3058886ef6d2	2026-02-13 00:34:40.561623+00	2026-02-13 00:34:40.575709+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:34:40.575709+00	\N	\N
e5572f6b-3cff-4226-9b87-acfe3e376848	2026-02-13 00:30:22.145031+00	2026-02-13 00:30:22.1634+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:30:22.1634+00	\N	\N
c6213253-46c0-4ac6-a15c-1f2f314d7995	2026-02-13 00:30:22.181041+00	2026-02-13 00:30:22.197817+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:30:22.197817+00	\N	\N
0ca25292-defd-495e-bbd0-90a11e577807	2026-02-13 00:30:22.215583+00	2026-02-13 00:30:23.297372+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:30:23.297372+00	\N	\N
48261fd9-d012-4338-8a5d-0f57bdcc5694	2026-02-13 00:34:39.775969+00	2026-02-13 00:34:39.995916+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:34:39.995916+00	\N	\N
4152c24f-4551-4b38-8508-3e3e0d6c253e	2026-02-13 00:34:40.532736+00	2026-02-13 00:34:40.546838+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:34:40.546838+00	\N	\N
087bfd23-df1d-4454-8529-51ea1de2f962	2026-02-13 00:34:40.589925+00	2026-02-13 00:34:40.650927+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:34:40.650927+00	\N	\N
331451ee-f5f8-45c9-885d-905b48a8b713	2026-02-13 00:35:23.221621+00	2026-02-13 00:35:23.239668+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:35:23.239668+00	\N	\N
e1cd04c1-a7e1-4ec2-81e5-639d1f720be5	2026-02-13 00:35:22.270819+00	2026-02-13 00:35:22.546829+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:35:22.546829+00	\N	\N
79e535ee-9497-4174-89c4-e64fcd6057d3	2026-02-13 00:35:23.257616+00	2026-02-13 00:35:23.274903+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:35:23.274903+00	\N	\N
0bda7c2d-52c9-4096-bf6a-bba22152190c	2026-02-13 00:35:23.294015+00	2026-02-13 00:35:23.367187+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:35:23.367187+00	\N	\N
3889b51d-1cab-4ca3-bac6-675285cda0c3	2026-02-13 00:35:32.18754+00	2026-02-13 00:35:32.416073+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:35:32.416073+00	\N	\N
97b28116-95f0-42e2-a36a-d30289cdf67d	2026-02-13 00:37:54.02397+00	2026-02-13 00:37:54.252249+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:37:54.252249+00	\N	\N
278ce219-a17a-4625-acde-effb94b4b5a4	2026-02-13 00:35:32.927958+00	2026-02-13 00:35:32.942158+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:35:32.942158+00	\N	\N
9ab2c3d3-3bc7-4404-93e3-73d57d284137	2026-02-13 00:35:32.955521+00	2026-02-13 00:35:32.96812+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:35:32.96812+00	\N	\N
44cafe81-f73a-4d6c-8ad5-85a8bfaf1d73	2026-02-13 00:37:54.779424+00	2026-02-13 00:37:54.796295+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:37:54.796295+00	\N	\N
66a00df2-9fba-4f5e-9cf0-0344f84ea764	2026-02-13 00:35:32.982101+00	2026-02-13 00:35:33.048135+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:35:33.048135+00	\N	\N
fb2e7de8-c153-4148-ba72-1735557d8474	2026-02-13 00:37:54.812698+00	2026-02-13 00:37:54.830012+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:37:54.830012+00	\N	\N
11f25e5e-9b07-4671-afed-ef0180912542	2026-02-13 00:37:54.846057+00	2026-02-13 00:37:54.911835+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:37:54.911835+00	\N	\N
09242f0e-2a0d-4d07-92a0-cb16225662b0	2026-02-13 00:38:20.67242+00	2026-02-13 00:38:20.908483+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Workspace Test	e2e_workspace_test	\N	null	\N	\N	t	2026-02-13 00:38:20.908483+00	\N	\N
6257c82b-5d70-4017-8a51-f0c9b616c81d	2026-02-13 02:44:48.243878+00	2026-02-13 02:44:48.258863+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 02:44:48.258863+00	\N	\N
5eb94327-00bd-4fa9-a991-ffb72e797292	2026-02-13 00:38:25.59946+00	2026-02-13 00:38:25.842697+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:38:25.842697+00	\N	\N
f5f1aa4f-90cf-455a-acdd-202914cfe90b	2026-02-13 00:38:26.374369+00	2026-02-13 00:38:26.391404+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:38:26.391404+00	\N	\N
b44fc78e-c861-4107-8896-ec407c9717dd	2026-02-13 00:38:26.408012+00	2026-02-13 00:38:26.426417+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:38:26.426417+00	\N	\N
f07ffbf0-9a18-4ec7-b403-5bc3cf2cd96e	2026-02-13 00:38:26.443568+00	2026-02-13 00:38:26.514139+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:38:26.514139+00	\N	\N
f6a8d51d-7bcb-4ea4-920c-62c5a36251c4	2026-02-13 00:38:51.778604+00	2026-02-13 00:38:52.129355+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Workspace Test	e2e_workspace_test	\N	null	\N	\N	t	2026-02-13 00:38:52.129355+00	\N	\N
0d5e3212-d14d-4bf7-a14f-02d305df6173	2026-02-13 00:47:51.355569+00	2026-02-13 00:47:51.575747+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:47:51.575747+00	\N	\N
5563bbf1-e1b4-41dc-82f8-76f70935c8e3	2026-02-13 00:39:02.204718+00	2026-02-13 00:39:02.630141+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:39:02.630141+00	\N	\N
bef98145-1115-4928-94fd-1c78353fcff2	2026-02-13 00:39:03.178697+00	2026-02-13 00:39:03.193621+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:39:03.193621+00	\N	\N
99259651-800c-4b2c-ab6a-6800c4a9dda1	2026-02-13 00:39:03.208023+00	2026-02-13 00:39:03.224854+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:39:03.224854+00	\N	\N
e99e5c4c-9cf0-421c-990d-c83c17caca6f	2026-02-13 00:39:03.240173+00	2026-02-13 00:39:03.303352+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:39:03.303352+00	\N	\N
fd8f57b2-60d2-4a50-b8b7-1444f8f4f42e	2026-02-13 00:42:16.179551+00	2026-02-13 00:42:16.400266+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:42:16.400266+00	\N	\N
21ea3eb0-8be6-4de5-81b5-a8a5e50ec183	2026-02-13 00:42:16.932635+00	2026-02-13 00:42:16.947177+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:42:16.947177+00	\N	\N
20351b25-d420-466a-bfa3-ff87b4f60d69	2026-02-13 00:42:16.962094+00	2026-02-13 00:42:16.977789+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:42:16.977789+00	\N	\N
dd38599d-08b7-4788-9053-f8ca2dbd658a	2026-02-13 00:42:16.994065+00	2026-02-13 00:42:17.058707+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:42:17.058707+00	\N	\N
ded24cb9-23e1-49b1-944e-aa7aeefabf3c	2026-02-13 00:42:41.892099+00	2026-02-13 00:42:42.041865+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Workspace Test	e2e_workspace_test	\N	null	\N	\N	t	2026-02-13 00:42:42.041865+00	\N	\N
bb1c9647-56bc-40ce-967e-e4866fa5339b	2026-02-13 00:47:52.105123+00	2026-02-13 00:47:52.121413+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:47:52.121413+00	\N	\N
d8b2bf61-6c7d-43d2-8b19-a7156956472d	2026-02-13 00:43:15.657771+00	2026-02-13 00:43:15.867633+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 00:43:15.867633+00	\N	\N
d77ee9c2-7f09-4d45-8d7f-430893c24dbc	2026-02-13 00:43:16.403179+00	2026-02-13 00:43:16.417033+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 00:43:16.417033+00	\N	\N
9dac27a2-5ffc-4e1f-b848-ce84a97b1b61	2026-02-13 00:43:16.431427+00	2026-02-13 00:43:16.444516+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:43:16.444516+00	\N	\N
bc210f3d-c590-419d-8fb3-42565dd4a604	2026-02-13 00:43:16.458741+00	2026-02-13 00:43:16.527228+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:43:16.527228+00	\N	\N
1932e557-cb9b-4199-8184-5c8a8ce9ef26	2026-02-13 00:43:41.492424+00	2026-02-13 00:43:41.63864+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Workspace Test	e2e_workspace_test	\N	null	\N	\N	t	2026-02-13 00:43:41.63864+00	\N	\N
79d45793-3a2b-4a4b-bf93-e1581bac09c5	2026-02-13 00:47:52.137678+00	2026-02-13 00:47:52.151864+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 00:47:52.151864+00	\N	\N
4f2f20fe-1595-4569-8647-4a2e3696c910	2026-02-13 00:47:52.168434+00	2026-02-13 00:47:52.234356+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 00:47:52.234356+00	\N	\N
83e9eb41-e3d7-4882-81ba-1fc90b7138ed	2026-02-13 00:48:17.950535+00	2026-02-13 00:48:18.092496+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Workspace Test	e2e_workspace_test	\N	null	\N	\N	t	2026-02-13 00:48:18.092496+00	\N	\N
634c5e58-0b8e-489f-9d26-2da982c5a501	2026-02-13 02:38:39.995664+00	2026-02-13 02:38:40.222665+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 02:38:40.222665+00	\N	\N
ed1369bb-a3cd-4694-ba02-1d9adbf96de3	2026-02-13 02:38:40.742384+00	2026-02-13 02:38:40.755051+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 02:38:40.755051+00	\N	\N
cc8ad378-0b52-4e6c-b3a0-9b50ac59becf	2026-02-13 02:38:40.769023+00	2026-02-13 02:38:40.784207+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 02:38:40.784207+00	\N	\N
2fac52e9-e637-4703-a742-b4393307b33d	2026-02-13 02:38:40.79948+00	2026-02-13 02:38:40.861824+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 02:38:40.861824+00	\N	\N
64c0a8f8-4ecc-4903-85a7-e01bb42d4321	2026-02-13 02:39:06.812003+00	2026-02-13 02:39:06.959664+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Workspace Test	e2e_workspace_test	\N	null	\N	\N	t	2026-02-13 02:39:06.959664+00	\N	\N
d8916cc9-2eb8-4c5c-83bf-bef0363dc199	2026-02-13 02:44:48.276214+00	2026-02-13 02:44:48.291322+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 02:44:48.291322+00	\N	\N
93260f7c-22cd-4793-8a10-025dc3662463	2026-02-13 02:44:47.494295+00	2026-02-13 02:44:47.715604+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 02:44:47.715604+00	\N	\N
d3e1f766-f1d1-484d-8d1b-98cf03fe7376	2026-02-13 02:44:48.306478+00	2026-02-13 02:44:48.37144+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 02:44:48.37144+00	\N	\N
643ac2f2-b945-4fa2-8ef7-877a2e31d077	2026-02-13 02:45:14.121282+00	2026-02-13 02:45:14.266563+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Workspace Test	e2e_workspace_test	\N	null	\N	\N	t	2026-02-13 02:45:14.266563+00	\N	\N
769aa1aa-8a07-4c06-b1bf-4e30ea2a8c21	2026-02-13 02:46:27.451689+00	2026-02-13 02:46:27.46612+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 02:46:27.46612+00	\N	\N
e0831874-78b5-4cd1-b63b-039f3291558a	2026-02-13 02:46:20.863279+00	2026-02-13 02:46:21.173535+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 02:46:21.173535+00	\N	\N
db59df8e-7c32-444a-ac53-f85167e44492	2026-02-13 02:46:27.418045+00	2026-02-13 02:46:27.433065+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 02:46:27.433065+00	\N	\N
fb1c949a-22c5-464c-8a9f-831367a32b38	2026-02-13 02:46:27.482315+00	2026-02-13 02:46:27.555345+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 02:46:27.555345+00	\N	\N
76b0da4a-bd5f-4db0-b6f8-bb017dd212e5	2026-02-13 02:47:05.891811+00	2026-02-13 02:47:05.907345+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 02:47:05.907345+00	\N	\N
83cca71e-52bb-44cf-a162-9a9e81eb0194	2026-02-13 02:47:05.038325+00	2026-02-13 02:47:05.378291+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 02:47:05.378291+00	\N	\N
3ce6fefd-3218-460d-8ea6-b89d9b38e0be	2026-02-13 02:47:05.924584+00	2026-02-13 02:47:05.942081+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 02:47:05.942081+00	\N	\N
9fa359f6-c988-465d-a42e-35d3a44b1b1c	2026-02-13 02:47:05.959004+00	2026-02-13 02:47:06.028453+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 02:47:06.028453+00	\N	\N
f576760c-e8e4-47a3-95da-1bac266f0426	2026-02-13 02:47:31.412952+00	2026-02-13 02:47:31.562905+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Workspace Test	e2e_workspace_test	\N	null	\N	\N	t	2026-02-13 02:47:31.562905+00	\N	\N
7695f319-1786-4735-85c7-6a33790c7959	2026-02-13 03:22:28.971471+00	2026-02-13 03:22:28.985031+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-13 03:22:28.985031+00	\N	\N
b23b6b74-aa74-430c-816a-d5f913e4baff	2026-02-13 03:22:28.145999+00	2026-02-13 03:22:28.438438+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-13 03:22:28.438438+00	\N	\N
4a08123b-68d7-4966-963c-9952f831b793	2026-02-13 03:22:28.999481+00	2026-02-13 03:22:29.01495+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-13 03:22:29.01495+00	\N	\N
e355d2b1-f5fb-4c08-a4ff-deedbccb3373	2026-02-13 03:22:29.029564+00	2026-02-13 03:22:29.091261+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-13 03:22:29.091261+00	\N	\N
f14a3d47-41d2-4a27-bfaa-fe9b1748d91b	2026-02-13 03:47:48.885731+00	2026-02-13 03:47:48.885731+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Hello Python Flask	hello-python-flask	python	null	\N	\N	f	\N	\N	\N
4ef49014-0287-47c8-a5e0-b1c978a36dca	2026-02-13 03:22:55.641314+00	2026-02-13 03:22:55.791015+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Workspace Test	e2e_workspace_test	\N	null	\N	\N	t	2026-02-13 03:22:55.791015+00	\N	\N
62bc00ab-5b99-4b46-b1df-82433a526af2	2026-02-13 03:47:29.816763+00	2026-02-13 03:47:29.816763+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Hello Python Blank	hello-python-blank	python	null	\N	\N	f	\N	\N	\N
a3f7212a-fd79-4fd1-8733-c47298f343fc	2026-02-13 03:50:14.848354+00	2026-02-13 03:50:14.848354+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Hello Next.js	hello-nextjs	node	null	\N	\N	f	\N	\N	\N
64ee3816-fc03-4275-969d-0b9185e78224	2026-02-13 03:47:50.405042+00	2026-02-13 03:47:50.405042+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Hello Python FastAPI	hello-python-fastapi	python	null	\N	\N	f	\N	\N	\N
93e0f705-356a-4aea-85ae-ba62c19c57ab	2026-02-13 03:49:11.029301+00	2026-02-13 03:49:11.029301+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Hello Node Blank	hello-node-blank	node	null	\N	\N	f	\N	\N	\N
09f253f7-33a5-4545-8a38-93faa6303e15	2026-02-13 03:49:41.592933+00	2026-02-13 03:49:41.592933+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Hello React Vite	hello-react-vite	node	null	\N	\N	f	\N	\N	\N
319fdf7e-b498-451e-8860-6ac0c61fa991	2026-02-13 03:51:00.654725+00	2026-02-13 03:51:00.654725+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Hello Drupal	hello-drupal	php	null	\N	\N	f	\N	\N	\N
3a9e5012-86da-4c06-8ea3-0ce23ecd4dc9	2026-02-13 05:16:47.197151+00	2026-02-13 05:16:47.197151+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Race Fix Test	race-fix-test	python	null	\N	\N	f	\N	\N	\N
910a1a56-542d-45eb-a29a-8a513adaabc9	2026-02-13 05:22:28.053433+00	2026-02-13 05:22:28.053433+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Race Fix Test 2	race-fix-test-2	python	null	\N	\N	f	\N	\N	\N
e1424879-d8f5-45cc-b766-167b12430464	2026-02-13 05:32:14.28146+00	2026-02-13 05:32:14.28146+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	API Test Template	api-test-template	python	null	\N	\N	f	\N	python-blank	\N
50f226ba-b928-4a35-b280-757b3ca32558	2026-02-13 05:34:40.920843+00	2026-02-13 05:34:40.920843+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Final Test	final-test	python	null	\N	\N	f	\N	python-blank	\N
27814240-2c6c-462f-a78e-9a3abeb39909	2026-02-13 05:35:48.764282+00	2026-02-13 05:35:48.764282+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Final Test	final-test	python	null	\N	\N	f	\N	python-blank	\N
4f22edf4-751f-4d5b-ab6b-c672cf113182	2026-02-13 05:39:38.040305+00	2026-02-13 05:39:38.040305+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Final Test	final-test	python	null	\N	\N	f	\N	python-blank	\N
bc9f30cd-0be0-4d13-93c3-0a197fe9290a	2026-02-13 05:43:37.339898+00	2026-02-13 05:43:37.339898+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Circuit Breaker Test	circuit-breaker-test	python	null	\N	\N	f	\N	python-blank	\N
aba47dc5-4329-4e65-b47f-7c54a698dfd3	2026-02-13 05:47:13.272847+00	2026-02-13 05:47:13.272847+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Template Verify Test	template-verify-test	python	null	\N	\N	f	\N	python-blank	\N
3800f9f8-6730-4706-912f-3000c8a11a3b	2026-02-13 05:28:22.369729+00	2026-02-13 05:28:22.369729+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Race Fix Test 3	race-fix-test-3	python	null	\N	\N	t	2026-02-13 05:49:28.807105+00	python-blank	\N
a4fc03e4-2c7f-4815-8525-ba4c676ea179	2026-02-13 05:50:30.049196+00	2026-02-13 05:50:30.049196+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Clean Slate Test	clean-slate-test	python	null	\N	\N	f	\N	python-blank	\N
3abdab5d-7b0f-4701-9381-d811645c481e	2026-02-13 05:53:03.879492+00	2026-02-13 05:53:03.879492+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	No Spam Test	no-spam-test	python	null	\N	\N	f	\N	python-blank	\N
23d4c7cb-1d20-456f-afc0-253379a5deaa	2026-02-13 05:54:15.539776+00	2026-02-13 05:54:15.539776+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Absolute Path Test	absolute-path-test	python	null	\N	\N	f	\N	python-blank	\N
c0e6af27-9e72-45c8-b4d9-2f6fdd4044fb	2026-02-13 05:57:17.942446+00	2026-02-13 05:57:17.942446+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	PATH Fix Test	path-fix-test	python	null	\N	\N	f	\N	python-blank	\N
c0bf104c-87f2-4feb-b765-0ef5f5aebb70	2026-02-13 06:00:36.030613+00	2026-02-13 06:00:36.030613+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Full Fix Test	full-fix-test	python	null	\N	\N	f	\N	python-blank	\N
fa98dc8d-f253-4e3b-9519-fbb620d2a576	2026-02-13 23:33:31.220438+00	2026-02-13 23:33:31.220438+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	Model Switcher Test	model-switcher-test	python	null	\N	\N	f	\N	python-blank	\N
b727e152-abc0-4a0e-bfc3-ee2c288463f7	2026-02-14 01:15:03.794221+00	2026-02-14 01:15:03.794221+00	eb8f2199-7903-409d-8999-1e450e3c90b8	Proj1	proj1	node	null	\N	\N	f	\N	node-react-vite	\N
1cb9d6f1-7636-4a23-9d96-e9048e44e31f	2026-02-14 23:05:57.738406+00	2026-02-14 23:05:58.096342+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_updated_project	e2e_test_project	\N	null	\N	\N	t	2026-02-14 23:05:58.096342+00	\N	\N
bcbde950-551e-478f-ac3f-54ba46fb6651	2026-02-14 23:06:01.755445+00	2026-02-14 23:06:01.776256+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test	e2e_drush_test	\N	null	\N	\N	t	2026-02-14 23:06:01.776256+00	\N	\N
46392f95-6bcc-41f4-a087-ddc980e76db7	2026-02-14 23:06:01.792299+00	2026-02-14 23:06:01.809586+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_drush_test2	e2e_drush_test2	\N	null	\N	\N	t	2026-02-14 23:06:01.809586+00	\N	\N
3b51d825-0ba8-4fed-84af-7f7ab26e2cff	2026-02-14 23:06:01.824821+00	2026-02-14 23:06:01.890738+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	e2e_content_test	e2e_content_test	\N	null	\N	\N	t	2026-02-14 23:06:01.890738+00	\N	\N
81406b49-b87a-495e-aedf-e6526d5e9bc8	2026-02-14 23:06:24.238973+00	2026-02-14 23:06:24.447694+00	c2fc5cdc-eeed-4de8-8474-d2001390069a	E2E Workspace Test	e2e_workspace_test	\N	null	\N	\N	t	2026-02-14 23:06:24.447694+00	\N	\N
\.


--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.resources (id, created_at, updated_at, resource_id, resource_type, status, location, priority, auto_unload, last_used_at, user_locked, user_id, vram_mb, base_priority) FROM stdin;
\.


--
-- Data for Name: system_prompts; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.system_prompts (id, created_at, updated_at, user_id, name, content, description, is_default, is_deleted, deleted_at) FROM stdin;
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.user_preferences (id, created_at, updated_at, user_id, custom_system_prompt, coding_principles, response_style, default_model, default_temperature, email_notifications, in_app_notifications, imggen_default_workflow, imggen_default_width, imggen_default_height, imggen_default_steps, imggen_default_cfg_scale, imggen_default_negative_prompt, imggen_completion_notification, imggen_desktop_notification, imggen_sound_notification, imggen_notification_sound, imggen_auto_delete_days, imggen_max_generations, comfyui_base_url) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.users (id, created_at, updated_at, username, email, hashed_password, role, is_active, first_name, last_name, screen_name, email_verified, email_verification_token, password_reset_token, password_reset_expires, failed_login_attempts, locked_until, last_login_at, last_password_change, must_change_password) FROM stdin;
c25b7b73-da3e-4dc3-8ac6-cc3c3e28ca1c	2026-02-08 02:40:21.633144+00	2026-02-08 02:42:37.444109+00	testuser	test@example.com	$2b$12$0F8Dfu8thPErtM6zZjnvyONw2sWmGgjoarBnxNcv8GvXlfBzxa4T6	user	t	\N	\N	testuser	f	\N	\N	\N	0	\N	2026-02-08 02:42:37.444454+00	\N	f
c2fc5cdc-eeed-4de8-8474-d2001390069a	2026-02-08 02:37:52.841296+00	2026-02-14 23:06:29.282141+00	admin	admin@workstation.local	$2b$12$rY9ynN3oAEfPbhWLsLvjLuZjGjUE.cvF.msByB6wyWPpGqrBe0/W2	admin	t	\N	\N	admin	f	\N	\N	\N	0	\N	2026-02-14 23:06:29.444409+00	\N	t
eb8f2199-7903-409d-8999-1e450e3c90b8	2026-02-08 21:17:21.930158+00	2026-02-16 15:21:44.162975+00	kevin	kevin.althaus@gmail.com	$2b$12$X2O/WXQ2kLWUhBgP/Zque.2EIT1Ekq28qIthRvWhy8l5/tYNx7Gey	admin	t	Kevin		Kevin	f	\N	\N	\N	0	\N	2026-02-16 15:21:44.33035+00	\N	f
\.


--
-- Data for Name: yolo_edits; Type: TABLE DATA; Schema: public; Owner: workstation_user
--

COPY public.yolo_edits (id, created_at, updated_at, project_id, chat_id, files_modified, undo_performed, undo_data) FROM stdin;
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: archives archives_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.archives
    ADD CONSTRAINT archives_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: automation_actions automation_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.automation_actions
    ADD CONSTRAINT automation_actions_pkey PRIMARY KEY (id);


--
-- Name: chats chats_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_pkey PRIMARY KEY (id);


--
-- Name: context_compactions context_compactions_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.context_compactions
    ADD CONSTRAINT context_compactions_pkey PRIMARY KEY (id);


--
-- Name: context_snippets context_snippets_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.context_snippets
    ADD CONSTRAINT context_snippets_pkey PRIMARY KEY (id);


--
-- Name: drupal_sites drupal_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.drupal_sites
    ADD CONSTRAINT drupal_sites_pkey PRIMARY KEY (id);


--
-- Name: drupal_sites drupal_sites_project_id_key; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.drupal_sites
    ADD CONSTRAINT drupal_sites_project_id_key UNIQUE (project_id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: help_topics help_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.help_topics
    ADD CONSTRAINT help_topics_pkey PRIMARY KEY (id);


--
-- Name: help_topics help_topics_slug_key; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.help_topics
    ADD CONSTRAINT help_topics_slug_key UNIQUE (slug);


--
-- Name: image_generations image_generations_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.image_generations
    ADD CONSTRAINT image_generations_pkey PRIMARY KEY (id);


--
-- Name: kb_chunks kb_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.kb_chunks
    ADD CONSTRAINT kb_chunks_pkey PRIMARY KEY (id);


--
-- Name: kb_sources kb_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.kb_sources
    ADD CONSTRAINT kb_sources_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: project_imports project_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.project_imports
    ADD CONSTRAINT project_imports_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: resources resources_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_pkey PRIMARY KEY (id);


--
-- Name: resources resources_resource_id_key; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_resource_id_key UNIQUE (resource_id);


--
-- Name: system_prompts system_prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.system_prompts
    ADD CONSTRAINT system_prompts_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: yolo_edits yolo_edits_pkey; Type: CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.yolo_edits
    ADD CONSTRAINT yolo_edits_pkey PRIMARY KEY (id);


--
-- Name: idx_archives_project; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_archives_project ON public.archives USING btree (project_id, created_at);


--
-- Name: idx_archives_status; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_archives_status ON public.archives USING btree (status);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_action_created; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_audit_logs_action_created ON public.audit_logs USING btree (action, created_at);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: idx_audit_logs_user_action; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_audit_logs_user_action ON public.audit_logs USING btree (user_id, action);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_automation_project_created; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_automation_project_created ON public.automation_actions USING btree (project_id, created_at);


--
-- Name: idx_chats_archived; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_chats_archived ON public.chats USING btree (project_id, is_archived);


--
-- Name: idx_chats_pinned; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_chats_pinned ON public.chats USING btree (project_id, is_pinned, updated_at);


--
-- Name: idx_chats_project_updated; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_chats_project_updated ON public.chats USING btree (project_id, updated_at);


--
-- Name: idx_compactions_chat; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_compactions_chat ON public.context_compactions USING btree (chat_id);


--
-- Name: idx_context_snippets_user_id; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_context_snippets_user_id ON public.context_snippets USING btree (user_id);


--
-- Name: idx_events_chat_id; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_events_chat_id ON public.events USING btree (chat_id);


--
-- Name: idx_events_created_at; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_events_created_at ON public.events USING btree (created_at);


--
-- Name: idx_events_event_type; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_events_event_type ON public.events USING btree (event_type);


--
-- Name: idx_events_severity; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_events_severity ON public.events USING btree (severity);


--
-- Name: idx_events_type_created; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_events_type_created ON public.events USING btree (event_type, created_at);


--
-- Name: idx_events_user_id; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_events_user_id ON public.events USING btree (user_id);


--
-- Name: idx_help_topics_embedding; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_help_topics_embedding ON public.help_topics USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='50');


--
-- Name: idx_help_topics_section_id; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_help_topics_section_id ON public.help_topics USING btree (section_id);


--
-- Name: idx_help_topics_slug; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE UNIQUE INDEX idx_help_topics_slug ON public.help_topics USING btree (slug);


--
-- Name: idx_image_generations_project; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_image_generations_project ON public.image_generations USING btree (project_id);


--
-- Name: idx_image_generations_status; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_image_generations_status ON public.image_generations USING btree (status);


--
-- Name: idx_image_generations_user; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_image_generations_user ON public.image_generations USING btree (user_id);


--
-- Name: idx_kb_chunks_embedding; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_kb_chunks_embedding ON public.kb_chunks USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: idx_kb_chunks_project; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_kb_chunks_project ON public.kb_chunks USING btree (project_id);


--
-- Name: idx_kb_chunks_source; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_kb_chunks_source ON public.kb_chunks USING btree (source_id, chunk_index);


--
-- Name: idx_kb_sources_project; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_kb_sources_project ON public.kb_sources USING btree (project_id);


--
-- Name: idx_kb_sources_status; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_kb_sources_status ON public.kb_sources USING btree (project_id, status);


--
-- Name: idx_messages_chat_created; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_messages_chat_created ON public.messages USING btree (chat_id, created_at);


--
-- Name: idx_messages_deleted; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_messages_deleted ON public.messages USING btree (chat_id, is_deleted);


--
-- Name: idx_messages_excluded; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_messages_excluded ON public.messages USING btree (chat_id, is_excluded);


--
-- Name: idx_messages_pinned; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_messages_pinned ON public.messages USING btree (chat_id, is_pinned);


--
-- Name: idx_project_imports_project; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_project_imports_project ON public.project_imports USING btree (project_id);


--
-- Name: idx_project_imports_status; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_project_imports_status ON public.project_imports USING btree (status);


--
-- Name: idx_project_imports_user; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_project_imports_user ON public.project_imports USING btree (user_id);


--
-- Name: idx_projects_user_active; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_projects_user_active ON public.projects USING btree (user_id, is_deleted);


--
-- Name: idx_projects_user_id; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_projects_user_id ON public.projects USING btree (user_id);


--
-- Name: idx_resources_status; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_resources_status ON public.resources USING btree (status);


--
-- Name: idx_resources_user_id; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_resources_user_id ON public.resources USING btree (user_id);


--
-- Name: idx_resources_user_locked; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_resources_user_locked ON public.resources USING btree (user_locked);


--
-- Name: idx_system_prompts_one_default; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE UNIQUE INDEX idx_system_prompts_one_default ON public.system_prompts USING btree (user_id) WHERE ((is_default = true) AND (is_deleted = false));


--
-- Name: idx_system_prompts_user_default; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_system_prompts_user_default ON public.system_prompts USING btree (user_id, is_default);


--
-- Name: idx_system_prompts_user_id; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_system_prompts_user_id ON public.system_prompts USING btree (user_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_email_verified; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_users_email_verified ON public.users USING btree (email_verified);


--
-- Name: idx_users_locked_until; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_users_locked_until ON public.users USING btree (locked_until);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_yolo_edits_chat; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_yolo_edits_chat ON public.yolo_edits USING btree (chat_id);


--
-- Name: idx_yolo_edits_project; Type: INDEX; Schema: public; Owner: workstation_user
--

CREATE INDEX idx_yolo_edits_project ON public.yolo_edits USING btree (project_id, created_at);


--
-- Name: system_prompts trg_set_system_prompts_updated_at; Type: TRIGGER; Schema: public; Owner: workstation_user
--

CREATE TRIGGER trg_set_system_prompts_updated_at BEFORE UPDATE ON public.system_prompts FOR EACH ROW EXECUTE FUNCTION public.set_system_prompts_updated_at();


--
-- Name: archives archives_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.archives
    ADD CONSTRAINT archives_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: automation_actions automation_actions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.automation_actions
    ADD CONSTRAINT automation_actions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: chats chats_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: context_compactions context_compactions_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.context_compactions
    ADD CONSTRAINT context_compactions_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE CASCADE;


--
-- Name: context_snippets context_snippets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.context_snippets
    ADD CONSTRAINT context_snippets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: drupal_sites drupal_sites_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.drupal_sites
    ADD CONSTRAINT drupal_sites_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: audit_logs fk_audit_logs_user_id; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT fk_audit_logs_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: chats fk_chats_system_prompt_id; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT fk_chats_system_prompt_id FOREIGN KEY (system_prompt_id) REFERENCES public.system_prompts(id) ON DELETE SET NULL;


--
-- Name: events fk_events_chat_id; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT fk_events_chat_id FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE SET NULL;


--
-- Name: events fk_events_user_id; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT fk_events_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: projects fk_projects_system_prompt_id; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT fk_projects_system_prompt_id FOREIGN KEY (system_prompt_id) REFERENCES public.system_prompts(id) ON DELETE SET NULL;


--
-- Name: resources fk_resources_user_id; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT fk_resources_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: image_generations image_generations_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.image_generations
    ADD CONSTRAINT image_generations_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: image_generations image_generations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.image_generations
    ADD CONSTRAINT image_generations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: kb_chunks kb_chunks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.kb_chunks
    ADD CONSTRAINT kb_chunks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: kb_chunks kb_chunks_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.kb_chunks
    ADD CONSTRAINT kb_chunks_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.kb_sources(id) ON DELETE CASCADE;


--
-- Name: kb_sources kb_sources_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.kb_sources
    ADD CONSTRAINT kb_sources_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: messages messages_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE CASCADE;


--
-- Name: project_imports project_imports_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.project_imports
    ADD CONSTRAINT project_imports_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_imports project_imports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.project_imports
    ADD CONSTRAINT project_imports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: projects projects_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: system_prompts system_prompts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.system_prompts
    ADD CONSTRAINT system_prompts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_preferences user_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: yolo_edits yolo_edits_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.yolo_edits
    ADD CONSTRAINT yolo_edits_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE SET NULL;


--
-- Name: yolo_edits yolo_edits_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: workstation_user
--

ALTER TABLE ONLY public.yolo_edits
    ADD CONSTRAINT yolo_edits_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict eRLCd1EaOF7es2g5UifNikCzaZMPiploJeuxXUfb2UMb0roLVlD8D5lkQMOhfa9

